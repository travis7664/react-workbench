const express = require("express");
const connection = require("../config/sqlConnection");

const showProjUsers = async (req, res) => {
  try {
    const { did } = req.params;

    if (!did) {
      return res.status(400).json({ error: "Demo ID is required" });
    }

    const sqlQuery = `
      SELECT
        u.uid,
        u.name AS user_name,
        r.rid,
        r.name AS role_name,
        IFNULL(upd.contributed_percentage, 0) AS contributed_percentage,
        IFNULL(upd.status, '') AS user_project_status
      FROM
        users_projects up
      JOIN
        users u ON up.uid = u.uid
      JOIN
        role r ON up.rid = r.rid
      LEFT JOIN
        users_projects_details upd ON up.uid = upd.uid AND up.did = upd.pid
      WHERE
        up.did = ?
    `
    ;

    // Execute the query
    connection.query(sqlQuery, [did], (err, results) => {
      if (err) {
        console.error("Error querying database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.length === 0) {
        return res
          .status(404)
          .json({ error: "No users found for the given Demo ID" });
      }

      // Format and return the results
      const users = results.map((row) => ({
        uid: row.uid,
        user_name: row.user_name,
        role: {
          rid: row.rid,
          name: row.role_name,
        },
        contributed_percentage: row.contributed_percentage
          ? Number(row.contributed_percentage)
          : null,
        user_project_status: row.user_project_status,
      }));

      res.json({ demo_id: did, users });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const assignProj = async (req, res) => {
  try {
    const { did } = req.params;
    const users = req.body; 
    if (!Array.isArray(users) || users.length === 0) {
      return res
        .status(400)
        .json({ error: "Request body must be an array of user-role pairs" });
    }
  
    if (!did) {
      return res.status(400).json({ error: "did is required" });
    }

    const checkDemoQuery = "SELECT COUNT(*) AS count FROM demos WHERE did = ?";
    connection.query(checkDemoQuery, [did], (checkErr, checkResults) => {
      if (checkErr) {
        console.error("Error checking demo ID in database:", checkErr);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      const demoExists = checkResults[0].count > 0;

      if (!demoExists) {
        return res.status(404).json({ error: "Demo ID not found" });
      }

      const sqlQuery =
        "INSERT INTO users_projects (uid, did, rid) VALUES (?, ?, ?)";

      const insertPromises = users.map((user) => {
        return new Promise((resolve, reject) => {
          const { uid, rid } = user;
          if (!uid || !rid) {
            return reject(`uid and rid are required for each user`);
          }

          connection.query(sqlQuery, [uid, did, rid], (err, results) => {
            if (err) {
              console.error("Error inserting into database:", err);
              return reject(err);
            }
            resolve(results.insertId);
          });
        });
      });

      Promise.all(insertPromises)
        .then((insertIds) => {
          res
            .status(201)
            .json({ message: "Projects assigned successfully", insertIds });
        })
        .catch((insertErr) => {
          console.error("Error inserting users:", insertErr);
          res.status(500).json({ error: "Internal Server Error" });
        });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};


const deleteProj = async (req, res) => {
  try {
    const { did } = req.params;
    const users = req.body;

    if (!Array.isArray(users) || users.length === 0) {
      return res
        .status(400)
        .json({ error: "Request body must be an array of user-role pairs" });
    }

    if (!did) {
      return res.status(400).json({ error: "did is required" });
    }

    const checkDemoQuery = "SELECT COUNT(*) AS count FROM demos WHERE did = ?";
    connection.query(checkDemoQuery, [did], (checkErr, checkResults) => {
      if (checkErr) {
        console.error("Error checking demo ID in database:", checkErr);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      const demoExists = checkResults[0].count > 0;
      if (!demoExists) {
        return res.status(404).json({ error: "Demo ID not found" });
      }

      const sqlQuery =
        "DELETE FROM users_projects WHERE did = ? AND uid = ? AND rid = ?";

      const deletePromises = users.map((user) => {
        return new Promise((resolve, reject) => {
          const { uid, rid } = user;

          if (!uid || !rid) {
            return reject("uid and rid are required for each user");
          }

          connection.query(sqlQuery, [did, uid, rid], (err, results) => {
            if (err) {
              console.error("Error deleting from database:", err);
              return reject(err);
            }

            if (results.affectedRows === 0) {
              return reject("Project not found for the given user and role");
            }
            resolve(results);
          });
        });
      });

      Promise.all(deletePromises)
        .then(() => {
          res.json({ message: "Projects removed successfully" });
        })
        .catch((deleteErr) => {
          console.error("Error deleting users:", deleteErr);
          res
            .status(500)
            .json({ error: "Internal Server Error", details: deleteErr });
        });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const updateRoles = async (req, res) => {
  try {
    const { did } = req.params;
    const users = req.body; 

    if (!Array.isArray(users) || users.length === 0) {
      return res
        .status(400)
        .json({ error: "Request body must be an array of user-role pairs" });
    }

    if (!did) {
      return res.status(400).json({ error: "did is required" });
    }

    const checkDemoQuery = "SELECT COUNT(*) AS count FROM demos WHERE did = ?";
    connection.query(checkDemoQuery, [did], (checkErr, checkResults) => {
      if (checkErr) {
        console.error("Error checking demo ID in database:", checkErr);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      const demoExists = checkResults[0].count > 0;
      if (!demoExists) {
        return res.status(404).json({ error: `Demo ID ${did} not found` });
      }

      const updateRoleQuery =
        "UPDATE users_projects SET rid = ? WHERE did = ? AND uid = ?";

      const updatePromises = users.map((user) => {
        return new Promise((resolve, reject) => {
          const { uid, rid } = user;

          if (!uid || !rid) {
            return reject(new Error("uid and rid are required for each user"));
          }

          connection.query(updateRoleQuery, [rid, did, uid], (err, results) => {
            if (err) {
              console.error("Error updating database:", err);
              return reject(err);
            }

            if (results.affectedRows === 0) {
              return reject(
                new Error(
                  `No matching record found for uid ${uid} in demo ${did}`
                )
              );
            }
            resolve(results);
          });
        });
      });

      Promise.all(updatePromises)
        .then(() => {
          res.json({ message: "Roles updated successfully" });
        })
        .catch((updateErr) => {
          console.error("Error updating roles:", updateErr);
          res.status(500).json({
            error: "Internal Server Error",
            details: updateErr.message,
          });
        });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

function processDemoDetails(row) {
  const users = row.user_details
    ? row.user_details.split(";").map((detail) => {
        const [uid, user_name, , role_name] = detail.split(":");
        return {
          uid: Number(uid),
          user_name,
          role: role_name,
        };
      })
    : [];

  return {
    did: row.did,
    project_name: row.project_name,
    users: users,
  };
}

// const showProjDetailsOfUsers = async (req, res) => {
//   try {
//     const userQuery = `SELECT
//     u.uid,
//     u.name AS user_name,
//     u.mail,
//     r1.rid AS role_id1,
//     r1.name AS role_name1,
//     r2.rid AS role_id2,
//     r2.name AS role_name2,
//     e.profile_img,
//     d.did,
//     d.project_name,
//     IFNULL(upd.contributed_percentage, 0) AS contributed_percentage,
//     IFNULL(upd.status, '') AS user_project_status,
//     d.estimated_end_date,
//     d.actual_end_date
// FROM
//     users u
// LEFT JOIN
//     users_projects up ON u.uid = up.uid
// LEFT JOIN
//     demos d ON up.did = d.did AND d.current_status = 'progress'
// LEFT JOIN
//     users_roles ur ON u.uid = ur.uid
// LEFT JOIN
//     role r2 ON ur.rid = r2.rid
// LEFT JOIN
//     role r1 ON up.rid = r1.rid
// LEFT JOIN
//     users_projects_details upd ON up.uid = upd.uid AND up.did = upd.pid
// LEFT JOIN
//     employee e ON u.uid = e.uid
// WHERE
//     u.team = 'presales & demo' AND u.isactive = true;`;
//     connection.query(userQuery, (err, results) => {
//       if (err) {
//         console.error("Error querying database:", err);
//         return res.status(500).json({ error: "Internal Server Error" });
//       }

//       if (results.length === 0) {
//         return res
//           .status(404)
//           .json({ error: "No users found for demos in progress" });
//       }

//       // Process the results to format roles and demos
//       const usersMap = new Map();

//       results.forEach((row) => {
//         if (!usersMap.has(row.uid)) {
//           usersMap.set(row.uid, {
//             uid: row.uid,
//             user_name: row.user_name,
//             mail: row.mail,
//             profile_img:row.profile_img,
//             roles: [],
//             demos: [],
//           });
//         }

//         const user = usersMap.get(row.uid);

//         if (
//           row.role_id1 &&
//           !user.roles.some((role) => role.rid === row.role_id1)
//         ) {
//           user.roles.push({
//             rid: row.role_id1,
//             name: row.role_name1,
//           });
//         }

//         if (
//           row.role_id2 &&
//           !user.roles.some((role) => role.rid === row.role_id2)
//         ) {
//           user.roles.push({
//             rid: row.role_id2,
//             name: row.role_name2,
//           });
//         }

//         if (row.did && !user.demos.some((demo) => demo.did === row.did)) {
//           user.demos.push({
//             did: row.did,
//             project_name: row.project_name,
//             contributed_percentage: row.contributed_percentage
//               ? Number(row.contributed_percentage)
//               : null,
//             user_project_status: row.user_project_status,
//             estimated_end_date: row.estimated_end_date,
//             actual_end_date: row.actual_end_date,
//           });
//         }
//       });

//       const users = Array.from(usersMap.values());

//       res.json(users);
//     });
//   } catch (error) {
//     console.error("Error:", error.message);
//     res.status(500).json({ error: "Internal Server Error" });
//   }
// };



const showProjDetailsOfUsers = async (req, res) => {
  try {
    const userQuery = `
      SELECT
        u.uid,
        u.name AS user_name,
        u.mail,
        r1.rid AS role_id1,
        r1.name AS role_name1,
        r2.rid AS role_id2,
        r2.name AS role_name2,
        e.profile_img,
        d.did,
        d.project_name,
        IFNULL(upd.contributed_percentage, 0) AS contributed_percentage,
        IFNULL(upd.status, '') AS user_project_status,
        d.estimated_end_date,
        d.actual_end_date,
        (
          SELECT SUM(upd2.contributed_percentage)
          FROM users_projects_details upd2
          INNER JOIN demos d2 ON upd2.pid = d2.did
          WHERE upd2.uid = u.uid 
            AND d2.current_status = 'progress'
            AND upd2.status = 1
        ) AS workload
      FROM
        users u
      LEFT JOIN
        users_projects up ON u.uid = up.uid
      LEFT JOIN
        demos d ON up.did = d.did AND d.current_status = 'progress'
      LEFT JOIN
        users_roles ur ON u.uid = ur.uid
      LEFT JOIN
        role r2 ON ur.rid = r2.rid
      LEFT JOIN
        role r1 ON up.rid = r1.rid
      LEFT JOIN
        users_projects_details upd ON up.uid = upd.uid AND up.did = upd.pid
      LEFT JOIN
        employee e ON u.uid = e.uid
      WHERE
        u.team = 'presales & demo' AND u.isactive = true;
    `;

    connection.query(userQuery, (err, results) => {
      if (err) {
        console.error("Error querying database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.length === 0) {
        return res
          .status(404)
          .json({ error: "No users found for demos in progress" });
      }

      const usersMap = new Map();

      results.forEach((row) => {
        if (!usersMap.has(row.uid)) {
          usersMap.set(row.uid, {
            uid: row.uid,
            user_name: row.user_name,
            mail: row.mail,
            profile_img: row.profile_img,
            workload: row.workload || 0,
            roles: [],
            demos: [],
          });
        }

        const user = usersMap.get(row.uid);

        if (
          row.role_id1 &&
          !user.roles.some((role) => role.rid === row.role_id1)
        ) {
          user.roles.push({
            rid: row.role_id1,
            name: row.role_name1,
          });
        }

        if (
          row.role_id2 &&
          !user.roles.some((role) => role.rid === row.role_id2)
        ) {
          user.roles.push({
            rid: row.role_id2,
            name: row.role_name2,
          });
        }

        // Add unique demos
        if (row.did && !user.demos.some((demo) => demo.did === row.did)) {
          user.demos.push({
            did: row.did,
            project_name: row.project_name,
            contributed_percentage: row.contributed_percentage
              ? Number(row.contributed_percentage)
              : null,
            user_project_status: row.user_project_status,
            estimated_end_date: row.estimated_end_date,
            actual_end_date: row.actual_end_date,
          });
        }
      });

      const users = Array.from(usersMap.values());

      res.json(users);
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

module.exports = { showProjDetailsOfUsers };



// const editUser = async (req, res) => {
//   try {
//     const { did } = req.params;
//     const users = req.body;

//     if (!Array.isArray(users) || users.length === 0) {
//       return res
//         .status(400)
//         .json({ error: "Request body must be an array of user-role pairs" });
//     }

//     const deleteQuery = "DELETE FROM users_projects WHERE did = ?";
//     connection.query(deleteQuery, [did], (deleteErr, deleteResults) => {
//       if (deleteErr) {
//         console.error("Error deleting from database:", deleteErr);
//         return res
//           .status(500)
//           .json({ error: "Internal Server Error during deletion" });
//       }

//       if (deleteResults.affectedRows === 0) {
//         return res
//           .status(404)
//           .json({ error: "No users found for the given did" });
//       }

//       const insertQuery =
//         "INSERT INTO users_projects (uid, did, rid) VALUES (?, ?, ?)";

//       const insertPromises = users.map((user) => {
//         return new Promise((resolve, reject) => {
//           const { uid, rid } = user;
//           if (!uid || !rid) {
//             return reject(new Error("uid and rid are required for each user"));
//           }

//           connection.query(
//             insertQuery,
//             [uid, did, rid],
//             (insertErr, insertResults) => {
//               if (insertErr) {
//                 console.error("Error inserting into database:", insertErr);
//                 return reject(insertErr);
//               }
//               resolve(insertResults.insertId);
//             }
//           );
//         });
//       });

//       Promise.all(insertPromises)
//         .then((insertIds) => {
//           res.status(201).json({
//             message: "Users deleted and new users added successfully",
//             insertIds,
//           });
//         })
//         .catch((insertErr) => {
//           console.error("Error inserting users:", insertErr);
//           res
//             .status(500)
//             .json({ error: "Internal Server Error during insertion" });
//         });
//     });
//   } catch (error) {
//     console.error("Error:", error.message);
//     res.status(500).json({ error: "Internal Server Error" });
//   }
// };



const editUser = async (req, res) => {
  try {
    const { did } = req.params;
    const users = req.body;

    if (!Array.isArray(users) || users.length === 0) {
      return res
        .status(400)
        .json({ error: "Request body must be an array of user-role pairs" });
    }

    const deleteQuery = "DELETE FROM users_projects WHERE did = ?";
    connection.query(deleteQuery, [did], (deleteErr, deleteResults) => {
      if (deleteErr) {
        console.warn(
          "Deletion failed, assuming no data exists for the given did. Proceeding to add new data."
        );
      }

      // Proceed with adding data even if deletion fails or no rows are affected
      const insertQuery =
        "INSERT   INTO users_projects (uid, did, rid) VALUES (?, ?, ?)";

      const insertPromises = users.map((user) => {
        return new Promise((resolve, reject) => {
          const { uid, rid } = user;
          if (!uid || !rid) {
            return reject(new Error("uid and rid are required for each user"));
          }

          connection.query(
            insertQuery,
            [uid, did, rid],
            (insertErr, insertResults) => {
              if (insertErr) {
                console.error("Error inserting into database:", insertErr);
                return reject(insertErr);
              }
              resolve(insertResults.insertId);
            }
          );
        });
      });

      Promise.all(insertPromises)
        .then((insertIds) => {
          res.status(201).json({
            message:
              "Users added successfully (deletion ignored if it failed or no rows were deleted)",
            insertIds,
          });
        })
        .catch((insertErr) => {
          console.error("Error inserting users:", insertErr);
          res
            .status(500)
            .json({ error: "Internal Server Error during insertion" });
        });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const getUserUID = async (req, res) => {
  try {
    const { mail } = req.body;

    if (!mail) {
      return res.status(400).json({ error: "Email is required" });
    }

    const sqlQuery = `SELECT uid FROM users WHERE mail = ?`;

    connection.query(sqlQuery, [mail], (err, results) => {
      if (err) {
        console.error("Error querying database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.length === 0) {
        return res.status(404).json({ error: "User not found" });
      }

      const uid = results[0].uid;

      res.json({ uid });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// module.exports = getUserUID;




module.exports = {
  showProjUsers,
  assignProj,
  updateRoles,
  deleteProj,
  showProjDetailsOfUsers,
  editUser,
  getUserUID
};
