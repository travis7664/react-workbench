const { User, Role } = require('../model/associations');

exports.getAllUsers = async (req, res) => {
  try {
    const { name, mail  } = req.query;

    const whereClause = {};
    if (name) whereClause.name = name;
    if (mail) whereClause.mail = mail;


    const users = await User.findAll({
      where: whereClause,
      include: [{
        model: Role,
        through: { attributes: [] }, 
            }],
    });

    const formattedUsers = users.map(user => {
      const roles = user.Roles.map(role => ({
        rid: role.rid,
        name: role.name,
      }));

      return {
        uid: user.uid,
        user_name: user.name,
        mail: user.mail,
        team: user.team,
        isactive: user.isactive,

        roles: roles,
      };
    });

    res.json(formattedUsers);
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.getUserById = async (req, res) => {
  try {
    const userId = req.params.uid;
    const { roleName } = req.query;

    const user = await User.findOne({
      where: { uid: userId },
      include: [{
        model: Role,
        where: roleName ? { name: roleName } : undefined,
        through: { attributes: [] },
      }],
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const roles = user.Roles.map(role => ({
      rid: role.rid,
      name: role.name,
    }));

    const formattedUser = {
      uid: user.uid,
      user_name: user.name,
      mail: user.mail,
      team: user.team,
      isactive: user.isactive,
      roles: roles,
    };

    res.json(formattedUser);
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

