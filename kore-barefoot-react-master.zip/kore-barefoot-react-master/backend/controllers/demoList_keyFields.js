const connection = require('../config/sqlConnection');

function processDemoDetails(row) {
  const users = row.user_details ? row.user_details.split(';').map(detail => {
    const [uid, user_name, , role_name] = detail.split(':');
    return {
      uid: Number(uid),
      user_name,
      role: role_name
    };
  }) : [];

  return {
    did: row.did,
    project_name: row.project_name,
    users: users
  };
}

async function getTotalDemosCount(filterClauses, filterValues) {
  return new Promise((resolve, reject) => {
    const countQuery = `SELECT COUNT(DISTINCT d.did) AS total
                        FROM demos d
                        LEFT JOIN users_projects up ON d.did = up.did
                        LEFT JOIN users u ON up.uid = u.uid
                        ${filterClauses}`;
    connection.query(countQuery, filterValues, (err, results) => {
      if (err) {
        reject(err);
      } else {
        resolve(results[0].total);
      }
    });
  });
}

function buildFiltersAndSort(query) {
  const filterClauses = [];
  const filterValues = [];

  if (query.client_name) {
    filterClauses.push('d.client_name LIKE ?');
    filterValues.push(`%${query.client_name}%`);
  }
  if (query.project_name) {
    filterClauses.push('d.project_name LIKE ?');
    filterValues.push(`%${query.project_name}%`);
  }
  if (query.current_status) {
    filterClauses.push('d.current_status = ?');
    filterValues.push(query.current_status);
  }
  if (query.owner) {
    filterClauses.push('d.owner LIKE ?');
    filterValues.push(`%${query.owner}%`);
  }
  if (query.user_name) {
    filterClauses.push('u.name LIKE ?');
    filterValues.push(`%${query.user_name}%`);
  }

  const sortClause = query.sortBy
    ? `${query.sortBy} ${query.sortOrder === 'desc' ? 'DESC' : 'ASC'}`
    : 'd.did DESC';

  const whereClause = filterClauses.length > 0
    ? `WHERE ${filterClauses.join(' AND ')}`
    : '';

  return { filterClauses: whereClause, filterValues, sortClause };
}

module.exports = {
  getDemos: async (req, res) => {
    try {
      const limit = parseInt(req.query.limit) || 10;
      const offset = parseInt(req.query.offset) || 0;

      const { filterClauses, filterValues, sortClause } = buildFiltersAndSort(req.query);

      const sqlQuery = `
      SELECT
        d.did,
        d.project_name,
        GROUP_CONCAT(
          DISTINCT CONCAT(
            u.uid, ':', u.name, ':', r.rid, ':', r.name
          ) SEPARATOR ';'
        ) AS user_details
      FROM
        demos d
      LEFT JOIN
        users_projects up ON d.did = up.did
      LEFT JOIN
        users u ON up.uid = u.uid
      LEFT JOIN
        role r ON up.rid = r.rid
      ${filterClauses}
      GROUP BY
        d.did
      ORDER BY 
        ${sortClause}
      LIMIT ? OFFSET ?;
      `;

      connection.query(sqlQuery, [...filterValues, limit, offset], async (err, results) => {
        if (err) {
          console.error('Error querying database:', err);
          res.status(500).json({ error: 'Internal Server Error' });
          return;
        }

        const demos = results.map(processDemoDetails);
        try {
          const totalDemos = await getTotalDemosCount(filterClauses, filterValues);
          res.json({
            demos,
            pagination: {
              limit,
              offset,
              total: totalDemos
            }
          });
        } catch (countError) {
          console.error('Error querying total demos count:', countError);
          res.status(500).json({ error: 'Internal Server Error' });
        }
      });
    } catch (error) {
      console.error('Error:', error.message);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  },

};
