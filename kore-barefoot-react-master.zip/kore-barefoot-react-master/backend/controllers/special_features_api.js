const express = require('express');
const connection = require('../config/sqlConnection');

const getFeatures = async (req, res) => {
  try {
    const sqlQuery = `SELECT * FROM special_features order by id`;

    connection.query(sqlQuery, (err, results) => {
      if (err) {
        console.error('Error querying database:', err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      const features = results.map(row => ({
        id: row.id,
        category_name	: row.category_name,
        feature_name	: row.feature_name
      }));

      res.json(features);
    });
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
module.exports = {
    getFeatures
    
  };
  