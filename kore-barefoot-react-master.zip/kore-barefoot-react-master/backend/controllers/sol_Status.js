const mysql = require('mysql2/promise');
const dbConfig = require('../config/dbConfig');

function createPool(config) {
    return mysql.createPool(config);
}

const pool = createPool(dbConfig);

exports.GetStatusCnt=async (req,res) =>{
    try{
        const account_id=(req.query.id);
        console.log(account_id);
        if(account_id){
       
            const [status_info] = await pool.execute(
                "SELECT * FROM solution_usecase where account_id=?;",[account_id]
                
            );
            const [Sol_Username] = await pool.execute(
                "SELECT username FROM reserve_demos where id=?;",[account_id]
                
            );
            const [tot_cnt]=await pool.execute("SELECT COUNT(*) AS total_entries FROM solution_usecase WHERE account_id = ?;",[account_id])
            // console.log(sol_id)
            const [cnt_info]=await pool.execute(`SELECT
    SUM(CASE WHEN websdk_working = 'working' THEN 1 ELSE 0 END) AS websdk_working_count,
    SUM(CASE WHEN ivr_working = 'working' THEN 1 ELSE 0 END) AS ivr_working_count,
    SUM(CASE WHEN ms_working = 'working' THEN 1 ELSE 0 END) AS ms_working_count,
    SUM(CASE WHEN slack_working = 'working' THEN 1 ELSE 0 END) AS slack_working_count,
    SUM(CASE WHEN workbench_working = 'working' THEN 1 ELSE 0 END) AS workbench_working_count,

    -- Not applicable counts
    SUM(CASE WHEN websdk_working = 'not applicable' THEN 1 ELSE 0 END) AS websdk_not_applicable_count,
    SUM(CASE WHEN ivr_working = 'not applicable' THEN 1 ELSE 0 END) AS ivr_not_applicable_count,
    SUM(CASE WHEN ms_working = 'not applicable' THEN 1 ELSE 0 END) AS ms_not_applicable_count,
    SUM(CASE WHEN slack_working = 'not applicable' THEN 1 ELSE 0 END) AS slack_not_applicable_count,
    SUM(CASE WHEN workbench_working = 'not applicable' THEN 1 ELSE 0 END) AS workbench_not_applicable_count,

    -- Not working counts
    SUM(CASE WHEN websdk_working = 'not working' THEN 1 ELSE 0 END) AS websdk_not_working_count,
    SUM(CASE WHEN ivr_working = 'not working' THEN 1 ELSE 0 END) AS ivr_not_working_count,
    SUM(CASE WHEN ms_working = 'not working' THEN 1 ELSE 0 END) AS ms_not_working_count,
    SUM(CASE WHEN slack_working = 'not working' THEN 1 ELSE 0 END) AS slack_not_working_count,
    SUM(CASE WHEN workbench_working = 'not working' THEN 1 ELSE 0 END) AS workbench_not_working_count

FROM solution_usecase
WHERE account_id = ?;`,[account_id])

const totalEntries = tot_cnt[0].total_entries;

const cntInfo = cnt_info[0];
const calculateFraction = (workingCount, notApplicableCount) => {
    const applicableTotal = totalEntries - notApplicableCount;
    if (applicableTotal === 0) return { fraction: "0/0", percentage: "0%" };
    
    const fraction = `${workingCount}/${applicableTotal}`;
    const percentage = ((workingCount / applicableTotal) * 100).toFixed(2) + '%';
    
    return { fraction, percentage };
  };
  
  const fractions = {
    websdk_fraction: calculateFraction(
      parseInt(cntInfo.websdk_working_count),
      parseInt(cntInfo.websdk_not_applicable_count)
    ),
    ivr_fraction: calculateFraction(
      parseInt(cntInfo.ivr_working_count),
      parseInt(cntInfo.ivr_not_applicable_count)
    ),
    ms_fraction: calculateFraction(
      parseInt(cntInfo.ms_working_count),
      parseInt(cntInfo.ms_not_applicable_count)
    ),
    slack_fraction: calculateFraction(
      parseInt(cntInfo.slack_working_count),
      parseInt(cntInfo.slack_not_applicable_count)
    ),
    workbench_fraction: calculateFraction(
      parseInt(cntInfo.workbench_working_count),
      parseInt(cntInfo.workbench_not_applicable_count)
    )
  };
  
            res.json({ success: true, message: 'fetching status info successful',Sol_Username,status_info,tot_cnt,cnt_info,fractions});
        }
       


    }
    catch (error) {
        console.log(error)
        res.status(500).json({ success: false, message: 'Internal Server Error' });      
    }
}
exports.PostUsecase = async (req, res) => {
    try {
        const account_id = req.query.id;
        if (account_id) {
            const [sol_idResult] = await pool.execute("SELECT solution_id FROM reserve_demos WHERE id = ?", [account_id]);
            const sol_id = sol_idResult[0]?.solution_id; // Extract solution_id

            const usecase = req.body.usecase || null;
            const websdk_working = req.body.websdk_working || null;
            const websdk_jiralink = req.body.websdk_jiralink || null;
            const ivr_working = req.body.ivr_working || null;
            const ivr_jiralink = req.body.ivr_jiralink || null;
            const ms_working = req.body.ms_working || null;
            const ms_jiralink = req.body.ms_jiralink || null;
            const slack_working = req.body.slack_working || null;
            const slack_jiralink = req.body.slack_jiralink || null;
            const workbench_working = req.body.workbench_working || null;
            const workbench_jiralink = req.body.workbench_jiralink || null;

            const [newUsecase] = await pool.execute(`
                INSERT INTO solution_usecase (
                    usecase, websdk_working, websdk_jiralink, ivr_working, ivr_jiralink,
                    ms_working, ms_jiralink, slack_working, slack_jiralink,
                    workbench_working, workbench_jiralink, solution_id, account_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `, [
                usecase, websdk_working, websdk_jiralink, ivr_working, ivr_jiralink,
                ms_working, ms_jiralink, slack_working, slack_jiralink,
                workbench_working, workbench_jiralink, sol_id, account_id
            ]);

            res.json({ success: true, message: 'Adding use case info successful', newUsecase });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
}




exports.EditUsecase = async (req, res) => {
    try {
        const id = req.query.id;
        console.log(id);

        const [usecaseExists] = await pool.execute("SELECT * FROM solution_usecase WHERE id = ?", [id]);

        if (usecaseExists.length !== 0) {
            // Define the modified fields and their new values
            const updates = {
                usecase: req.body.usecase,
                websdk_working: req.body.websdk_working,
                websdk_jiralink: req.body.websdk_jiralink,
                ivr_working: req.body.ivr_working,
                ivr_jiralink: req.body.ivr_jiralink,
                ms_working: req.body.ms_working,
                ms_jiralink: req.body.ms_jiralink,
                slack_working: req.body.slack_working,
                slack_jiralink: req.body.slack_jiralink,
                workbench_working: req.body.workbench_working,
                workbench_jiralink: req.body.workbench_jiralink
            };

            // Filter out the fields that haven't been modified
            const setClause = [];
            const values = [];
            for (const [key, value] of Object.entries(updates)) {
                if (value !== undefined) { // Check for modified values
                    setClause.push(`${key} = ?`);
                    values.push(value);
                }
            }

            if (setClause.length > 0) {
                // Add the ID of the record to update as the last value
                values.push(id);

                // Construct the UPDATE query
                const updateQuery = `UPDATE solution_usecase SET ${setClause.join(', ')} WHERE id = ?`;

                // Execute the query
                const [data] = await pool.execute(updateQuery, values);
                console.log(updateQuery);
                console.log(values);

                // Send the response
                res.json({ success: true, message: 'Updated usecase successfully', data });
            } else {
                // No fields to update
                res.json({ success: false, message: 'No fields to update' });
            }
        } else {
            res.json({ success: false, message: 'No entry exists' });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};
exports.delUseCase = async (req, res) => {
    try {
        const id = req.query.id;

        if (!id ) {
            return res.status(400).json({ success: false, message: 'Account ID and Usecase ID are required' });
        }

        const [result] = await pool.execute(
            'DELETE FROM solution_usecase WHERE id = ? ',
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ success: false, message: 'Use case not found' });
        }

        res.json({ success: true, message: 'Use case deleted successfully', result });
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};
