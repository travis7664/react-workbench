
const express = require("express");
const connection = require("../config/sqlConnection");

const getSDKs = async (req, res) => {
    try {
      const { SearchClauses } = req.params;
      const page = parseInt(req.query.page, 10) || 1; 
      const limit = parseInt(req.query.limit, 10) || 20;
      const offset = (page - 1) * limit; 
  
      let whereClause = '';
      let queryParams = [];
  
      if (SearchClauses === '*') {
        whereClause = ''; 
      } else {
        whereClause = `WHERE UPPER(software_name) LIKE ? OR UPPER(category_name) LIKE ? `;
        const searchParam = `%${SearchClauses.toUpperCase()}%`;
        queryParams.push(searchParam, searchParam); 
      }
  
      queryParams.push(limit, offset);
  
      const sqlQuery = `SELECT * FROM softwareapi ${whereClause} ORDER BY id DESC LIMIT ? OFFSET ?`;
  
      const countQuery = `SELECT COUNT(*) as total FROM softwareapi ${whereClause}`;
  
      connection.query(sqlQuery, queryParams, (err, results) => {
        if (err) {
          console.error("Error querying database:", err);
          return res.status(500).json({ error: "Internal Server Error" });
        }
  
        const countParams = whereClause ? queryParams.slice(0, 2) : []; 
        connection.query(countQuery, countParams, (countErr, countResults) => {
          if (countErr) {
            console.error("Error querying database for count:", countErr);
            return res.status(500).json({ error: "Internal Server Error" });
          }
  
          const total = countResults[0].total;
          const totalPages = Math.ceil(total / limit);
  
          const sdks = results.map((row) => ({
            id: row.id,
            software_name: row.software_name,
            api_key: row.api_key,
            category_name: row.category_name
          }));
  
          res.json({
            page,
            offset,
            limit,
            total,
            totalPages,
            data: sdks,
          });
        });
      });
    } catch (error) {
      console.error("Error:", error.message);
      res.status(500).json({ error: "Internal Server Error" });
    }
  };
  




module.exports = {
    getSDKs
  };
  