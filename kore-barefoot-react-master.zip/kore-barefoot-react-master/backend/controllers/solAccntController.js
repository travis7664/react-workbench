const mysql = require('mysql2/promise');
const dbConfig = require('../config/dbConfig');

function createPool(config) {
    return mysql.createPool(config);
}

const pool = createPool(dbConfig);

exports.getAccnts=async (req, res) => {
    try {
        const id = req.query.id;
        if(id)
        {
            
            const [data] = await pool.execute('SELECT * FROM reserve_demos where solution_id=?;', [id]);
            res.json({ success: true, message: 'Fetching accounts details successful', data });
    
        
        }
        else
        {
        const [data] = await pool.execute('select * from reserve_demos ');
        res.json({ success: true, message: 'Fetching accounts details successful', data });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

// POST Solution (accepting empty fields)
exports.postAccnt = async (req, res) => {
    try {
        const {
            id = null,  // Default to null if not provided
            username = null,
            workbench_url = null,
            botbuilder_url = null,
            audit_Date = null,
            integration = null,
            solution_version = null,
            password = null,
            status = null,
            solution_id=null,
            env=null,
            banner_txt=null
        } = req.body;

        // Check if fields are undefined and set them to null
        const query = `
            INSERT INTO reserve_demos (id, username, workbench_url, botbuilder_url, audit_Date, integration, solution_version, password, status, solution_id, env,banner_txt)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?)
        `;

        const [result] = await pool.execute(query, [
            id, username, workbench_url, botbuilder_url, audit_Date, integration, solution_version, password, status, solution_id, env,banner_txt]);

        res.json({ success: true, message: 'Solution account added successfully', data: result });
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};



exports.putAccnt = async (req, res) => {
    try {
        const  id  = req.query.id; // Using id from the request params to identify the record

        // Define the fields that might be updated
        const updates = {
            username: req.body.username ,
            workbench_url: req.body.workbench_url ,
            botbuilder_url: req.body.botbuilder_url ,
            audit_Date: req.body.audit_Date ,
            integration: req.body.integration ,
            solution_version: req.body.solution_version ,
            password: req.body.password ,
            status: req.body.status ,
            solution_id: req.body.solution_id ,
            env: req.body.env,
            banner_txt: req.body.banner_txt
        };
        console.log(updates.audit_Date)

        // Dynamically build the SQL query based on the provided fields
        const setClause = [];
        const values = [];
        for (const [key, value] of Object.entries(updates)) {
            if (value !== undefined) {
                setClause.push(`${key} = ?`);
                values.push(value);
            }
        }

        if (setClause.length > 0) {
            // Add id as the last parameter for the WHERE clause
            values.push(id);
            const updateQuery = `UPDATE reserve_demos SET ${setClause.join(', ')} WHERE id = ?`;

            // Execute the query
            const [result] = await pool.execute(updateQuery, values);
            res.json({ success: true, message: 'Account updated successfully', data: result });
        } else {
            res.status(400).json({ success: false, message: 'No fields to update' });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

exports.deleteAccnt = async (req, res) => {
    try {
        const id  = req.query.id; // Use id from params to identify the record to delete

        // Check if the record exists
        const [accntExists] = await pool.execute('SELECT * FROM reserve_demos WHERE id = ?', [id]);
        if (accntExists.length > 0) {
            // If record exists, delete it
            const deleteQuery = 'DELETE FROM reserve_demos WHERE id = ?';
            const [result] = await pool.execute(deleteQuery, [id]);

            res.json({ success: true, message: 'Account deleted successfully', data: result });
        } else {
            res.status(404).json({ success: false, message: 'Account not found' });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};


