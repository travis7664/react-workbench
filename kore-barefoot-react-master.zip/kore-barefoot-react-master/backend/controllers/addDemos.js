const connection = require("../config/sqlConnection");
let lastDemoID;

const addDemo = async (req, res) => {
  try {
    const {
      entity_id = 1,
      project_name = "",
      internal_project_name = "",
      client_name = "",
      functional_theme = "",
      project_type = "",
      project_desc = "",
      lp_project_desc = "",
      client_domains = "",
      team_type = "",
      owner = "@",
      probability_percentage = "",
      sfdc_link = "",
      sales_closure_date = new Date(),
      native = "",
      mobweb = "",
      mobspa = "",
      tablets = "",
      tabletweb = "",
      tabletspa = "",
      desktop = "",
      hybrid = "",
      wrapper = "",
      mixedmode = "",
      wearable = "",
      orientation = "",
      other_channel = "",
      plug_ins = "",
      deliverables = "",
      project_tags = "",
      request_received = new Date(),
      start_date = new Date(),
      estimated_end_date = new Date(),
      estimated_project_duration = "",
      current_status = "",
      project_closure = 0,
      actual_end_date = new Date(),
      visualizer_passcode = "",
      visualizer_desc = "",
      visualizer_version = "",
      project_criticality = "",
      demo_end_feedback = "",
      feedback = "",
      reason = "",
      current_health = "",
      current_complexity = "",
      percentage_completed = 0,
      base_project = "",
      bot_tenant = "",
      bot_env = "",
      jira_link = "",
      milestones_schedules = "",
      ui_reviewer = "",
      code_review = "",
      issue_logging = "",
      video_labelling = "",
      tech_lead = "",
      developers = "",
      jiraLink = "",
      designers = "",
      qa = "",
      lp_user_name = "",
      lp_password = "",
      lp_demovideo_client_logo = "",
      bot_zip_files = "",
      automation_file = "",
      client_id = "",
      client_secret = "",
      automation_region = "",
      automation_project = "",
      automation_total_task = "",
      pass = "",
      failed = "",
      failed_task_name = "",
      automation_script = "",
      lp_demovideo_url = "",
      standup_time = "",
      special_character_check = 1,
      created_user = "",
      created_date = new Date(),
      updated_user = "",
      updated_date = new Date(),
      waiting_for_feedback_status_update_date = new Date(),
      waiting_for_feedback_status_update_user = "",
      completed_status_update_date = new Date(),
      completed_status_update_user = "",
      demo_search = 1,
      demo_popular = 0,
      showcase_demo_status = "",
      showcase_demo_comment = "",
      demo_label = "",
      demo_care = "",
      customer_link = "",
      bot_training = "",
      allChannels = "{}",
      allFeatures = "{}",
      newDeliverables = "-",
      project_img = "",
    } = req.body;

    const formatDate = (dateStr) => {
      if (!dateStr) return "";
      const date = new Date(dateStr);
      if (isNaN(date)) return "";
      return date.toISOString().slice(0, 19).replace("T", " ");
    };

    const sqlQuery = `
      INSERT INTO demos (
        entity_id, project_name, internal_project_name, client_name, functional_theme, project_type,
        project_desc, lp_project_desc, client_domains, team_type, owner, probability_percentage,
        sfdc_link, sales_closure_date, native, mobweb, mobspa, tablets, tabletweb, tabletspa, desktop,
        hybrid, wrapper, mixedmode, wearable, orientation, other_channel, plug_ins, deliverables,
        project_tags, request_received, start_date, estimated_end_date, estimated_project_duration,
        current_status, project_closure, actual_end_date, visualizer_passcode, visualizer_desc,
        visualizer_version, project_criticality, demo_end_feedback, feedback, reason, current_health,
        current_complexity, percentage_completed, base_project, bot_tenant, bot_env, jira_link,
        milestones_schedules, ui_reviewer, code_review, issue_logging, video_labelling, tech_lead,
        developers, jiraLink, designers, qa, lp_user_name, lp_password, lp_demovideo_client_logo,
        bot_zip_files, automation_file, client_id, client_secret, automation_region, automation_project,
        automation_total_task, pass, failed, failed_task_name, automation_script, lp_demovideo_url,
        standup_time, special_character_check, created_user, created_date, updated_user, updated_date,
        waiting_for_feedback_status_update_date, waiting_for_feedback_status_update_user,
        completed_status_update_date, completed_status_update_user, demo_search, demo_popular,
        showcase_demo_status, showcase_demo_comment, demo_label, demo_care, customer_link,bot_training,demo_Channels_Json,demo_Features_Json,project_img
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,  ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?)
    `;

    connection.query(
      sqlQuery,
      [
        entity_id,
        project_name,
        internal_project_name,
        client_name,
        functional_theme,
        project_type,
        project_desc,
        lp_project_desc,
        client_domains,
        team_type,
        owner,
        probability_percentage,
        sfdc_link,
        formatDate(sales_closure_date),
        native,
        mobweb,
        mobspa,
        tablets,
        tabletweb,
        tabletspa,
        desktop,
        hybrid,
        wrapper,
        mixedmode,
        wearable,
        orientation,
        other_channel,
        plug_ins,
        newDeliverables,
        project_tags,
        formatDate(request_received),
        formatDate(start_date),
        formatDate(estimated_end_date),
        estimated_project_duration,
        current_status,
        project_closure,
        formatDate(actual_end_date),
        visualizer_passcode,
        visualizer_desc,
        visualizer_version,
        project_criticality,
        demo_end_feedback,
        feedback,
        reason,
        current_health,
        current_complexity,
        percentage_completed,
        base_project,
        bot_tenant,
        bot_env,
        jira_link,
        milestones_schedules,
        ui_reviewer,
        code_review,
        issue_logging,
        video_labelling,
        tech_lead,
        developers,
        jiraLink,
        designers,
        qa,
        lp_user_name,
        lp_password,
        lp_demovideo_client_logo,
        bot_zip_files,
        automation_file,
        client_id,
        client_secret,
        automation_region,
        automation_project,
        automation_total_task,
        pass,
        failed,
        failed_task_name,
        automation_script,
        lp_demovideo_url,
        standup_time,
        special_character_check,
        created_user,
        formatDate(created_date),
        updated_user,
        formatDate(updated_date),
        formatDate(waiting_for_feedback_status_update_date),
        waiting_for_feedback_status_update_user,
        formatDate(completed_status_update_date),
        completed_status_update_user,
        demo_search,
        demo_popular,
        showcase_demo_status,
        showcase_demo_comment,
        demo_label,
        demo_care,
        customer_link,
        bot_training,
        allChannels,
        allFeatures,
        project_img,
      ],
      (err, results) => {
        if (err) {
          console.error("Error inserting into database:", err);
          return res.status(500).json({ error: "Internal Server Error" });
        }

        res.status(201).json({
          message: "Demo added successfully",
          demoId: results.insertId,
        });
        console.log("demoId :", results.insertId);
        lastDemoID = results.insertId;
      }
    );
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const lastDid = async () => {
  if (lastDemoID) {
    return lastDemoID;
  }

  return new Promise((resolve, reject) => {
    const sqlQuery = "SELECT MAX(did) AS last_did FROM demos";

    connection.query(sqlQuery, (err, results) => {
      if (err) {
        console.error("Error fetching the most recent demo ID:", err);
        return reject(new Error("Internal Server Error"));
      }

      if (results.length > 0 && results[0].last_did !== null) {
        resolve(results[0].last_did);
      } else {
        resolve(null);
      }
    });
  });
};

const deleteDemo = async (req, res) => {
  try {
    const { did } = req.params;

    const sqlQuery = "DELETE FROM demos WHERE did = ?";
    connection.query(sqlQuery, [did], (err, results) => {
      if (err) {
        console.error("Error deleting from database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.affectedRows === 0) {
        return res.status(404).json({ error: "demo not found" });
      }

      res.json({ message: "demo deleted successfully" });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const updateDemo = async (req, res) => {
  try {
    const { did } = req.params;
    const {
      entity_id = 1,
      project_name = "",
      internal_project_name = "",
      client_name = "",
      functional_theme = "",
      project_type = "",
      project_desc = "",
      lp_project_desc = "",
      client_domains = "",
      team_type = "",
      owner = "",
      probability_percentage = "",
      sfdc_link = "",
      sales_closure_date = new Date(),
      native = "",
      mobweb = "",
      mobspa = "",
      tablets = "",
      tabletweb = "",
      tabletspa = "",
      desktop = "",
      hybrid = "",
      wrapper = "",
      mixedmode = "",
      wearable = "",
      orientation = "",
      other_channel = "",
      plug_ins = "",
      deliverables = "",
      project_tags = "",
      request_received = new Date(),
      start_date = new Date(),
      estimated_end_date = new Date(),
      estimated_project_duration = "",
      current_status = "",
      project_closure = 0,
      actual_end_date = new Date(),
      visualizer_passcode = "",
      visualizer_desc = "",
      visualizer_version = "",
      project_criticality = "",
      demo_end_feedback = "",
      feedback = "",
      reason = "",
      current_health = "",
      current_complexity = "",
      percentage_completed = 0,
      base_project = "",
      bot_tenant = "",
      bot_env = "",
      jira_link = "",
      milestones_schedules = "",
      ui_reviewer = "",
      code_review = "",
      issue_logging = "",
      video_labelling = "",
      tech_lead = "",
      developers = "",
      jiraLink = "",
      designers = "",
      qa = "",
      lp_user_name = "",
      lp_password = "",
      lp_demovideo_client_logo = "",
      bot_zip_files = "",
      automation_file = "",
      client_id = "",
      client_secret = "",
      automation_region = "",
      automation_project = "",
      automation_total_task = "",
      pass = "",
      failed = "",
      failed_task_name = "",
      automation_script = "",
      lp_demovideo_url = "",
      standup_time = "",
      special_character_check = 1,
      created_user = "",
      created_date = new Date(),
      updated_user = "",
      updated_date = new Date(),
      waiting_for_feedback_status_update_date = new Date(),
      waiting_for_feedback_status_update_user = "",
      completed_status_update_date = new Date(),
      completed_status_update_user = "",
      demo_search = 1,
      demo_popular = 0,
      showcase_demo_status = "",
      showcase_demo_comment = "",
      demo_label = "",
      demo_care = "",
      customer_link = "",
      allChannels = "{}",
      allFeatures = "{}",
      newDeliverables = "-",
      bot_training = "",
      project_img = "",
    } = req.body;

    if (!did || isNaN(parseInt(did))) {
      return res.status(400).json({ error: "Invalid id" });
    }

    const formatDate = (dateStr) => {
      if (!dateStr || dateStr === "0000-00-00") {
        return new Date();
      }

      const date = new Date(dateStr);

      if (isNaN(date)) {
        return "";
      }

      return date.toISOString().slice(0, 19).replace("T", " ");
    };

    const sqlQuery = `
    UPDATE demos SET
        entity_id = ?, project_name = ?, internal_project_name = ?, client_name = ?, functional_theme = ?, project_type = ?,
        project_desc = ?, lp_project_desc = ?, client_domains = ?, team_type = ?, owner = ?, probability_percentage = ?,
        sfdc_link = ?, sales_closure_date = ?, native = ?, mobweb = ?, mobspa = ?, tablets = ?, tabletweb = ?, tabletspa = ?, desktop = ?,
        hybrid = ?, wrapper = ?, mixedmode = ?, wearable = ?, orientation = ?, other_channel = ?, plug_ins = ?, deliverables = ?,
        project_tags = ?, request_received = ?, start_date = ?, estimated_end_date = ?, estimated_project_duration = ?,
        current_status = ?, project_closure = ?, actual_end_date = ?, visualizer_passcode = ?, visualizer_desc = ?,
        visualizer_version = ?, project_criticality = ?, demo_end_feedback = ?, feedback = ?, reason = ?, current_health = ?,
        current_complexity = ?, percentage_completed = ?, base_project = ?, bot_tenant = ?, bot_env = ?, jira_link = ?,
        milestones_schedules = ?, ui_reviewer = ?, code_review = ?, issue_logging = ?, video_labelling = ?, tech_lead = ?,
        developers = ?, jiraLink = ?, designers = ?, qa = ?, lp_user_name = ?, lp_password = ?, lp_demovideo_client_logo = ?,
        bot_zip_files = ?, automation_file = ?, client_id = ?, client_secret = ?, automation_region = ?, automation_project = ?,
        automation_total_task = ?, pass = ?, failed = ?, failed_task_name = ?, automation_script = ?, lp_demovideo_url = ?,
        standup_time = ?, special_character_check = ?, created_user = ?, created_date = ?, updated_user = ?, updated_date = ?,
        waiting_for_feedback_status_update_date = ?, waiting_for_feedback_status_update_user = ?,
        completed_status_update_date = ?, completed_status_update_user = ?, demo_search = ?, demo_popular = ?,
        showcase_demo_status = ?, showcase_demo_comment = ?, demo_label = ?, demo_care = ?, customer_link = ?, demo_Channels_Json= ? ,demo_Features_Json= ? ,bot_training=?, project_img = ?
      WHERE did = ?
    `;

    connection.query(
      sqlQuery,
      [
        entity_id,
        project_name,
        internal_project_name,
        client_name,
        functional_theme,
        project_type,
        project_desc,
        lp_project_desc,
        client_domains,
        team_type,
        owner,
        probability_percentage,
        sfdc_link,
        formatDate(sales_closure_date),
        native,
        mobweb,
        mobspa,
        tablets,
        tabletweb,
        tabletspa,
        desktop,
        hybrid,
        wrapper,
        mixedmode,
        wearable,
        orientation,
        other_channel,
        plug_ins,
        newDeliverables,
        project_tags,
        formatDate(request_received),
        formatDate(start_date),
        formatDate(estimated_end_date),
        estimated_project_duration,
        current_status,
        project_closure,
        formatDate(actual_end_date),
        visualizer_passcode,
        visualizer_desc,
        visualizer_version,
        project_criticality,
        demo_end_feedback,
        feedback,
        reason,
        current_health,
        current_complexity,
        percentage_completed,
        base_project,
        bot_tenant,
        bot_env,
        jira_link,
        milestones_schedules,
        ui_reviewer,
        code_review,
        issue_logging,
        video_labelling,
        tech_lead,
        developers,
        jiraLink,
        designers,
        qa,
        lp_user_name,
        lp_password,
        lp_demovideo_client_logo,
        bot_zip_files,
        automation_file,
        client_id,
        client_secret,
        automation_region,
        automation_project,
        automation_total_task,
        pass,
        failed,
        failed_task_name,
        automation_script,
        lp_demovideo_url,
        standup_time,
        special_character_check,
        created_user,
        formatDate(created_date),
        updated_user,
        formatDate(updated_date),
        formatDate(waiting_for_feedback_status_update_date),
        waiting_for_feedback_status_update_user,
        formatDate(completed_status_update_date),
        completed_status_update_user,
        demo_search,
        demo_popular,
        showcase_demo_status,
        showcase_demo_comment,
        demo_label,
        demo_care,
        customer_link,
        allChannels,
        allFeatures,
        bot_training,
        project_img,
        did,
      ],
      (err, results) => {
        if (err) {
          console.error("Error updating database:", err);
          return res.status(500).json({ error: "Internal Server Error" });
        }

        if (results.affectedRows === 0) {
          return res.status(404).json({ error: "Event not found" });
        }

        res.json({ message: "Event updated successfully" });
      }
    );
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const setToTrash = async (req, res) => {
  try {
    const { did, type } = req.params;

    const sqlQuery = "UPDATE demos SET current_status = ? WHERE did = ?";
    connection.query(sqlQuery, [type, did], (err, results) => {
      if (err) {
        console.error("Error Updating the demo", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.affectedRows === 0) {
        return res.status(404).json({ error: "demo not found" });
      }

      res.json({ message: "demo updated successfully" });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const UpdateProgress = async (req, res) => {
  try {
    const { did, progress } = req.params;

    const sqlQuery = "UPDATE demos SET percentage_completed = ? WHERE did = ?";
    connection.query(sqlQuery, [progress, did], (err, results) => {
      if (err) {
        console.error("Error Updating the percentage_completed", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.affectedRows === 0) {
        return res.status(404).json({ error: "demo not found" });
      }

      res.json({ message: "demo updated successfully" });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

module.exports = {
  addDemo,
  lastDid,
  deleteDemo,
  updateDemo,
  setToTrash,
  UpdateProgress,
};
