const multer = require('multer');
const { createCanvas, loadImage } = require('canvas');
const path = require('path');
const fs = require('fs');
const util = require('util');

const unlinkAsync = util.promisify(fs.unlink);

const storage = multer.diskStorage({
    destination: 'uploads/',
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}-${file.originalname}`);
    }
});
const upload = multer({ storage: storage });

// const mergeImages = async (req, res) => {
//     const logoFile = req.files['logo'][0];
//     const stencilFile = req.files['stencil'] ? req.files['stencil'][0] : null;

//     if (!logoFile || (!stencilFile && !req.body.defaultStencil)) {
//         return res.status(400).send("Both logo and stencil images are required.");
//     }

//     const logoPath = path.resolve(logoFile.path);
//     const stencilPath = stencilFile ? path.resolve(stencilFile.path) : path.resolve(`default/${req.body.defaultStencil}`);

//     const logoPercentage = parseInt(req.body.logoPercentage);
//     const stencilPercentage = parseInt(req.body.stencilPercentage);
//     const width = parseInt(req.body.width);
//     const height = parseInt(req.body.height);
//     const logoRotation = parseInt(req.body.logoRotation) || 0; 
//     try {
//         const logo = await loadImage(logoPath);
//         const stencil = await loadImage(stencilPath);

//         const canvas = createCanvas(width, height);
//         const ctx = canvas.getContext('2d');

//         ctx.drawImage(stencil, 0, 0, width, height);

//         const logoWidth = (width * logoPercentage) / 100;
//         const logoHeight = (height * logoPercentage) / 100;
        
//         ctx.save();
        
//         ctx.translate(width / 2, height / 2);
//         ctx.rotate((logoRotation * Math.PI) / 180);
//         ctx.drawImage(logo, -logoWidth / 2, -logoHeight / 2, logoWidth, logoHeight);
        
//         ctx.restore();

//         const outputFilePath = path.resolve('output', `merged-${Date.now()}.png`);
//         const out = fs.createWriteStream(outputFilePath);
//         const stream = canvas.createPNGStream();

//         stream.pipe(out);

//         out.on('finish', async () => {
//             res.sendFile(outputFilePath, async (err) => {
//                 if (err) {
//                     console.error('Error sending file:', err);
//                     res.status(500).send('Error sending merged image.');
//                 }

//                 try {
//                     await unlinkAsync(logoPath); 
//                     if (stencilFile) await unlinkAsync(stencilPath); 
//                     await unlinkAsync(outputFilePath); 
//                     console.log('Uploaded and output files cleaned up.');
//                 } catch (cleanupError) {
//                     console.error('Error cleaning up files:', cleanupError);
//                 }
//             });
//         });
//     } catch (error) {
//         console.error('Error processing images:', error);
//         res.status(500).send('Error processing images.');
//     }
// };

const mergeImages = async (req, res) => {
    const logoFile = req.files['logo'][0];
    const stencilFile = req.files['stencil'] ? req.files['stencil'][0] : null;

    if (!logoFile || (!stencilFile && !req.body.defaultStencil)) {
        return res.status(400).send("Both logo and stencil images are required.");
    }

    const logoPath = path.resolve(logoFile.path);
    const stencilPath = stencilFile ? path.resolve(stencilFile.path) : path.resolve(`default/${req.body.defaultStencil}`);

    const logoPercentage = parseInt(req.body.logoPercentage);
    const stencilPercentage = parseInt(req.body.stencilPercentage);
    const width = parseInt(req.body.width);
    const height = parseInt(req.body.height);
    const logoRotation = parseInt(req.body.logoRotation) || 0;
    try {
        const logo = await loadImage(logoPath);
        const stencil = await loadImage(stencilPath);

        const canvas = createCanvas(width, height);
        const ctx = canvas.getContext('2d');

        ctx.drawImage(stencil, 0, 0, width, height);

        const logoWidth = (width * logoPercentage) / 100;
        const logoHeight = (height * logoPercentage) / 100;

        ctx.save();

        ctx.translate(width / 2, height / 2);
        ctx.rotate((logoRotation * Math.PI) / 180);
        ctx.drawImage(logo, -logoWidth / 2, -logoHeight / 2, logoWidth, logoHeight);

        ctx.restore();

        const outputFilePath = path.resolve('output', `merged-${Date.now()}.png`);
        const out = fs.createWriteStream(outputFilePath);
        const stream = canvas.createPNGStream();

        stream.pipe(out);

        out.on('finish', async () => {
            res.sendFile(outputFilePath, async (err) => {
                if (err) {
                    console.error('Error sending file:', err);
                    res.status(500).send('Error sending merged image.');
                }

                try {
                    // Clean up only non-txt files
                    const cleanupFile = async (filePath) => {
                        if (path.extname(filePath).toLowerCase() !== '.txt') {
                            await unlinkAsync(filePath);
                        }
                    };

                    await cleanupFile(logoPath);
                    if (stencilFile) await cleanupFile(stencilPath);
                    await cleanupFile(outputFilePath);

                    console.log('Uploaded and output files cleaned up.');
                } catch (cleanupError) {
                    console.error('Error cleaning up files:', cleanupError);
                }
            });
        });
    } catch (error) {
        console.error('Error processing images:', error);
        res.status(500).send('Error processing images.');
    }
};


module.exports = { upload, mergeImages };
