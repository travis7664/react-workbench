const mysql = require("mysql2/promise");
const dbConfig = require("../config/dbConfig");

function createPool(config) {
  return mysql.createPool(config);
}

const pool = createPool(dbConfig);

exports.GetSolInfo = async (req, res) => {
    try {
      const sol_name = req.query.name;
      console.log(sol_name);
      if (sol_name) {
        const [banner_data] = await pool.execute(
          "SELECT * FROM solution_banner where banner_category=?;",
          [sol_name]
        );
        const [sol_id] = await pool.execute(
          "SELECT id FROM solution_demo WHERE solution_name=?;",
          [sol_name]
        );
        console.log(sol_id);
        const [sol_info] = await pool.execute(
          "SELECT * FROM reserve_demos WHERE solution_id=?",
          [sol_id[0].id]
        );
        res.json({
          success: true,
          message: "fetching sol info successful",
          sol_info,
          banner_data,
        });
      } else {
        const [is_reserve]=await pool.execute("SELECT * FROM book_demos WHERE daterelease >= CURDATE();")
        const [banner_data] = await pool.execute(
          "SELECT * FROM solution_banner ;"
        );
        const [sol_info] = await pool.execute("SELECT * FROM reserve_demos ");
        const [AccIds] = await pool.execute("SELECT id FROM reserve_demos;");
        const ids = AccIds.reduce((acc, id, index) => {
          return acc + id.id + (index < AccIds.length - 1 ? "," : "");
        }, "");
        const [fractions] = await pool.execute(`SELECT
        account_id,
        SUM(CASE WHEN websdk_working = 'working' THEN 1 ELSE 0 END) AS websdk_working_count,
        SUM(CASE WHEN ivr_working = 'working' THEN 1 ELSE 0 END) AS ivr_working_count,
        SUM(CASE WHEN ms_working = 'working' THEN 1 ELSE 0 END) AS ms_working_count,
        SUM(CASE WHEN slack_working = 'working' THEN 1 ELSE 0 END) AS slack_working_count,
        SUM(CASE WHEN workbench_working = 'working' THEN 1 ELSE 0 END) AS workbench_working_count,
    
        -- Not applicable counts
        SUM(CASE WHEN websdk_working = 'not applicable' THEN 1 ELSE 0 END) AS websdk_not_applicable_count,
        SUM(CASE WHEN ivr_working = 'not applicable' THEN 1 ELSE 0 END) AS ivr_not_applicable_count,
        SUM(CASE WHEN ms_working = 'not applicable' THEN 1 ELSE 0 END) AS ms_not_applicable_count,
        SUM(CASE WHEN slack_working = 'not applicable' THEN 1 ELSE 0 END) AS slack_not_applicable_count,
        SUM(CASE WHEN workbench_working = 'not applicable' THEN 1 ELSE 0 END) AS workbench_not_applicable_count,
    
        -- Not working counts
        SUM(CASE WHEN websdk_working = 'not working' THEN 1 ELSE 0 END) AS websdk_not_working_count,
        SUM(CASE WHEN ivr_working = 'not working' THEN 1 ELSE 0 END) AS ivr_not_working_count,
        SUM(CASE WHEN ms_working = 'not working' THEN 1 ELSE 0 END) AS ms_not_working_count,
        SUM(CASE WHEN slack_working = 'not working' THEN 1 ELSE 0 END) AS slack_not_working_count,
        SUM(CASE WHEN workbench_working = 'not working' THEN 1 ELSE 0 END) AS workbench_not_working_count
    
    FROM solution_usecase
    WHERE account_id IN (${ids})
    GROUP BY account_id;
    `);
        const [tot_cnt] = await pool.execute(
          `SELECT COUNT(*) AS total_entries,account_id  FROM solution_usecase WHERE account_id IN (${ids}) GROUP BY account_id;`
        );
  
        let z = {};
        tot_cnt.forEach((item) => (z[item.account_id] = item.total_entries));
  
        const calculateFraction = (workingCount, notApplicableCount, id) => {
          const applicableTotal = z[id] - notApplicableCount;
          if (applicableTotal === 0) return { fraction: "0/0", percentage: "0%" };
  
          const fraction = `${workingCount}/${applicableTotal}`;
          const percentage =
            ((workingCount / applicableTotal) * 100).toFixed(2) + "%";
  
          return { fraction, percentage };
        };
        let fractionsArr = [];
        fractions.forEach((item) => {
          let x = {
            accID: item.account_id,
            websdk_fraction: calculateFraction(
              parseInt(item.websdk_working_count),
              parseInt(item.websdk_not_applicable_count),
              item.account_id
            ),
            ivr_fraction: calculateFraction(
              parseInt(item.ivr_working_count),
              parseInt(item.ivr_not_applicable_count),
              item.account_id
            ),
            ms_fraction: calculateFraction(
              parseInt(item.ms_working_count),
              parseInt(item.ms_not_applicable_count),
              item.account_id
            ),
            slack_fraction: calculateFraction(
              parseInt(item.slack_working_count),
              parseInt(item.slack_not_applicable_count),
              item.account_id
            ),
            workbench_fraction: calculateFraction(
              parseInt(item.workbench_working_count),
              parseInt(item.workbench_not_applicable_count),
              item.account_id
            ),
          };
          fractionsArr.push(x);
        });
        console.log("ids", ids);
        res.json({
          success: true,
          message: "fetching sol info successful",
          sol_info,
          banner_data,
          fractionsArr,
          is_reserve
        });
      }
    } catch (error) {
      console.error(error);
      res.status(500).json({ success: false, message: "Internal Server Error" });
    }
  };
exports.GetSolDetails=async (req,res) =>{
    try{  
       
            const [sol_details] = await pool.execute(
                "SELECT id, solution_name FROM solution_demo;",
            );
           
            res.json({ success: true, message: 'fetching sol details info successful', sol_details});
       
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Internal Server Error' });      
    }
}


exports.GetGlobalDoc=async(req,res)=>{
    try{
        const [global_docs]=await pool.execute(
            "SELECT * FROM all_solution_doc;"
        );
        res.json({success:true,message:'fetching global solution docs successful',global_docs});
    }
    catch{
            res.status(500).json({success:false,message:'Internal server error'});
    }
}
exports.PostGlobalDoc=async(req,res)=>{
    try{
         const doc_title=req.body.doc_title || null;
         const doc_desc=req.body.doc_desc || null;
         const doc_category=req.body.doc_category || null;
         const up_doc=req.body.up_doc || null;
         const doc_url=req.body.doc_url || null;
        const [add_docs]=await pool.execute(
            "insert into all_solution_doc ( doc_title, doc_desc, doc_category, up_doc, doc_url) values (?,?,?,?,?);",[doc_title, doc_desc, doc_category, up_doc, doc_url]
        );
        res.json({success:true,message:'fetching global solution docs successful',add_docs});

    }
    catch{
        res.status(500).json({success:false,message:'Internal server error'}); 
    }
}


exports.putGlobalDoc = async (req, res) => {
    try {
        const  id  = req.query.id; 
        const updates = {
            doc_title: req.body.doc_title || null,
            doc_desc: req.body.doc_desc || null,
            doc_category: req.body.doc_category || null,
            up_doc: req.body.up_doc || null,
            doc_url: req.body.doc_url || null,
            
        };

        // Dynamically build the SQL query based on the provided fields
        const setClause = [];
        const values = [];
        for (const [key, value] of Object.entries(updates)) {
            if (value !== undefined) {
                setClause.push(`${key} = ?`);
                values.push(value);
            }
        }

        if (setClause.length > 0) {
            // Add id as the last parameter for the WHERE clause
            values.push(id);
            const updateQuery = `UPDATE all_solution_doc SET ${setClause.join(', ')} WHERE id = ?`;

            // Execute the query
            const [result] = await pool.execute(updateQuery, values);
            res.json({ success: true, message: 'doc updated successfully', data: result });
        } else {
            res.status(400).json({ success: false, message: 'No fields to update' });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};
exports.delGlobalDoc = async (req, res) => {
    try {
        const id = req.query.id;

        if (!id) {
            return res.status(400).json({ success: false, message: 'Document ID is required' });
        }

        // Execute the delete query
        const [result] = await pool.execute(
            "DELETE FROM all_solution_doc WHERE id = ?",
            [id]
        );

        // Check if any rows were affected
        if (result.affectedRows > 0) {
            res.json({ success: true, message: 'Document deleted successfully' });
        } else {
            res.status(404).json({ success: false, message: 'Document not found' });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};


exports.putAuditDate = async (req, res) => {
    try {
        const  id  = req.query.id; 
        console.log(id)
        const date=req.body.date;
        console.log(date)
        const [result] = await pool.execute("UPDATE reserve_demos SET audit_Date = ? WHERE id = ?;", [date,id]);
        res.json({ success: true, message: 'doc updated successfully', data: result });
       
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};
