const mysql = require("mysql2/promise");
const dbConfig = require("../config/dbConfig");

// Database setup
function createPool(config) {
  return mysql.createPool(config);
}

const pool = createPool(dbConfig);

exports.GetSecret = async (req, res) => {
  try {
    const [rows] = await pool.execute("select * from softwareapi;");
    if (rows.length !== 0) {
      res.json({
        success: true,
        message: "Fetching Secret credentials successful",
        rows,
      });
    } else {
      res.json({
        success: true,
        message: "No Demo Found with the concerned demo id",
      });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};

exports.PostSecret = async (req, res) => {
  try {
    if (req.body) {
      const software_name = req.body.software_name || null;
      const api_key = req.body.api_key || null;
      const category_name = req.body.category_name || null;
      const added_by = req.body.added_by || null;
      const is_working = req.body.is_working || null;
      const comments = req.body.comments || null;

      const data = await pool.execute(
        "INSERT INTO softwareapi (software_name, api_key, category_name,added_by,is_working, comments) VALUES (?, ?, ?,?,?,?);",
        [software_name, api_key, category_name, added_by, is_working, comments]
      );
      res.json({
        success: true,
        message: "Updated API creds successfully",
        data,
      });
    } else {
      res.json({ success: true, message: "No data is being sent" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};

exports.PutSecret = async (req, res) => {
  try {
    const id = req.query.id;
    console.log(id);
    const userExists = await pool.execute(
      "select * from softwareapi where ID=?;",
      [id]
    );
    console.log(userExists[0].length);
    if (userExists[0].length != 0) {
      // Define the modified fields and their new values
      const updates = {
        software_name: req.body.software_name,
        api_key: req.body.api_key,
        category_name: req.body.category_name,
        added_by: req.body.added_by,
        is_working: req.body.is_working,
        comments: req.body.comments,
      };

      // Filter out the fields that haven't been modified
      const setClause = [];
      const values = [];
      for (const [key, value] of Object.entries(updates)) {
        if (value !== undefined) {
          // Check for modified values
          setClause.push(`${key} = ?`);
          values.push(value);
        }
      }

      if (setClause.length > 0) {
        // Add the ID of the record to update as the last value

        values.push(id);

        // Construct the UPDATE query
        const updateQuery = `UPDATE softwareapi SET ${setClause.join(
          ", "
        )} WHERE ID = ?;`;

        // Execute the query
        const data = await pool.execute(updateQuery, values);
        console.log(updateQuery);
        console.log(values);
        // Send the response
        res.json({
          success: true,
          message: "Updated API keys successfully",
          data,
        });
      } else {
        // No fields to update
        res.json({ success: false, message: "No fields to update" });
      }
    } else {
      res.json({ success: true, message: "No entry exists" });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};

exports.DelSecret = async (req, res) => {
  try {
    const id = req.query.id;

    if (!id) {
      return res
        .status(400)
        .json({ success: false, message: "id is required" });
    }

    const [userExists] = await pool.execute(
      "SELECT * FROM softwareapi WHERE ID = ?;",
      [id]
    );

    if (userExists.length) {
      const data = await pool.execute("DELETE FROM softwareapi WHERE ID = ?;", [
        id,
      ]);
      res.json({
        success: true,
        message: "Deleted API details successfully",
        data,
      });
    } else {
      res.json({ success: true, message: "No entry exists" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};
