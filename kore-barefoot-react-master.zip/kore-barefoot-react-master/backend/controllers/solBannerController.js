const mysql = require('mysql2/promise');
const dbConfig = require('../config/dbConfig');

function createPool(config) {
    return mysql.createPool(config);
}

const pool = createPool(dbConfig);

exports.GetBanner=async (req,res) =>{
    try{
        const sol_name=req.query.sol_name
        // console.log(sol_name)
        if(!sol_name){
        const [data] = await pool.execute(
            "SELECT * FROM solution_banner;"
        );
        res.json({ success: true, message: 'fetching banners successful', data});
        }
        else{
            const [data] = await pool.execute(
                "SELECT * FROM solution_banner where banner_category = ?;",[sol_name]
            );
            res.json({ success: true, message: 'fetching banners successful', data});

        }


    }
    catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });      
    }
}

exports.AddBanner= async(req,res)=>{
   
    try{
            const bannertext = req.body.bannertext || null;
            const banner_category = req.body.banner_category || null;
            const select_banner = req.body.select_banner || null;
            const banner_text_color = req.body.banner_text_color || null;
            

           const data= await pool.execute("insert into solution_banner (bannertext,banner_category,select_banner,banner_text_color) values (?,?,?,?);",
                [bannertext, banner_category, select_banner, banner_text_color]);
                res.json({ success: true, message: 'added banner successful', data});
    }
    catch (error) {
        console.log(error)
        res.status(500).json({ success: false, message: 'Internal Server Error' });
       
        
    }

}

exports.EditBanner = async (req, res) => {
    try {
        const bannerId = req.query.id;
        if (!bannerId) {
            return res.status(400).json({ success: false, message: 'Banner ID is required' });
        }

        // Define the modified fields and their new values
        const updates = {
            bannertext: req.body.bannertext,
            banner_category: req.body.banner_category,
            select_banner: req.body.select_banner,
            banner_text_color: req.body.banner_text_color
        };

        // Filter out the fields that haven't been modified
        const setClause = [];
        const values = [];
        for (const [key, value] of Object.entries(updates)) {
            if (value !== undefined) { // Check for modified values
                setClause.push(`${key} = ?`);
                values.push(value);
            }
        }

        if (setClause.length > 0) {
            // Add the ID of the record to update as the last value
            values.push(bannerId);

            // Construct the UPDATE query
            const updateQuery = `UPDATE solution_banner SET ${setClause.join(', ')} WHERE id = ?;`;

            // Execute the query
            const [data] = await pool.execute(updateQuery, values);
            console.log(updateQuery);
            console.log(values);

            // Send the response
            res.json({ success: true, message: 'Banner updated successfully', data });
        } else {
            // No fields to update
            res.json({ success: false, message: 'No fields to update' });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

exports.DeleteBanner = async (req, res) => {
    try {
        const bannerId = req.query.id;
        if (!bannerId) {
            return res.status(400).json({ success: false, message: 'Banner ID is required' });
        }

        // Execute the DELETE query
        const [result] = await pool.execute("DELETE FROM solution_banner WHERE id = ?", [bannerId]);

        if (result.affectedRows > 0) {
            res.json({ success: true, message: 'Banner deleted successfully' });
        } else {
            res.json({ success: false, message: 'No banner found with the provided ID' });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};
