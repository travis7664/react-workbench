const mysql = require('mysql2/promise');
const dbConfig = require('../config/dbConfig');

// Database setup
function createPool(config) {
    return mysql.createPool(config);
}

const pool = createPool(dbConfig);
exports.PuttIssues= async(req,res)=>{
   
    try{
        //console.log(req.body)
        const id=(req.query.id);
        console.log(id);
        const userExists = await pool.execute("select * from proj_status_bugs where id=?;", [id]);
        console.log(userExists[0].length)
        if (userExists[0].length!=0) {
                // Define the modified fields and their new values
    const updates = {
         project_id :req.body.demoid,
         status_id : req.body.status_id ,
         digite_id: req.body.digite_id,
         digite_url : req.body.digite_url,
         issue_status : req.body.issue_status,
         user : req.body.user,
         issue_description : req.body.issue_description,
         created : req.body.created,
         assigned_to : req.body.assigned_to,
         issue_closed_date : req.body.issue_closed_date
  };
  
  // Filter out the fields that haven't been modified
  const setClause = [];
  const values = [];
  for (const [key, value] of Object.entries(updates)) {
    if (value !== undefined) { // Check for modified values
      setClause.push(`${key} = ?`);
      values.push(value);
    }
  }
  
  if (setClause.length > 0) {
    // Add the ID of the record to update as the last value
   
    values.push(id);
  
    // Construct the UPDATE query
    const updateQuery = `UPDATE proj_status_bugs SET ${setClause.join(', ')} WHERE id = ?;`;
  
    // Execute the query
    const data = await pool.execute(updateQuery, values);
  
    // Send the response
    res.json({ success: true, message: 'Updated issues successfully', data });
  } else {
    // No fields to update
    res.json({ success: false, message: 'No fields to update' });
  }
  
            
        } else {
            res.json({ success: true, message: 'No Demo exists' });
        }
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Internal Server Error' });
       
        
    }

}