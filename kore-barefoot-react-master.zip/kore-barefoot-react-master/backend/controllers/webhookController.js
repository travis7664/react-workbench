const express = require("express");
const router = express.Router();
const { parse } = require("csv-parse");
const OpenAI = require("openai");
const multer = require("multer");
const axios = require("axios");
const jwt = require("jsonwebtoken");
const natural = require("natural");
const { z } = require("zod");
const upload = multer({ storage: multer.memoryStorage() });
const { StatusCodes } = require("http-status-codes");
require("dotenv").config();
const { AUTH_CLIENT_ID, AUTH_API_KEY, AUTH_APP_ID } = process.env;
const { spawn } = require("child_process");
const path = require('path');
const fs = require('fs');
const { readFileSync } = require('fs');

const openAIClient = new OpenAI({
  apiKey: "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",
});


let processStatus = {};

const processCSVData = (results) => {
  let newParsed = [];
  let genAIUsecases = [];
  for (const element of results) {
    const [key, value] = element;
    if (key) {
      const entry = {
        [key]: value,
      };
      if (element.length > 2 && element[0].trim().toLowerCase() === 'usecase' && ['genai', 'gen ai'].includes(element[2].trim().toLowerCase())) {
        genAIUsecases.push(element[1]);
      }
      newParsed.push(entry);
    }
  }

  console.log("genAi", genAIUsecases);
  console.log("parse", newParsed);

  let finalObject = {};
  let currentUseCase = null;

  for (const element of newParsed) {
    const key = Object.keys(element).map((k) => k.trim());
    if (key[0] === "UseCase") {
      currentUseCase = element["UseCase"].trim();
      // finalObject[currentUseCase] = [];
      finalObject[currentUseCase] = {
        isGenAI: genAIUsecases.includes(currentUseCase),
        script: [],
      };
    } else if (currentUseCase) {
      let trimmedItem = {};
      Object.keys(element).forEach((k) => {
        trimmedItem[k.trim()] = element[k].trim();
      });
      finalObject[currentUseCase].script.push(trimmedItem);
    }
  }
  return finalObject;
};
const restructureConversation = (data) => {
  let result = {};
  for (const [key, value] of Object.entries(data)) {
    let transformedArray = [];
    let currentUser = null;
    value.script.forEach((item) => {
      if (item.User && item.User.trim()) {
        currentUser = { User: item.User.trim() };
        transformedArray.push(currentUser);
      } else if (item.Bot && currentUser) {
        let botResponse = item.Bot.trim();
        if (!currentUser.Bot) {
          currentUser.Bot = botResponse;
        } else {
          currentUser.Bot = Array.isArray(currentUser.Bot)
            ? [...currentUser.Bot, item.Bot]
            : [currentUser.Bot, item.Bot];
        }
      }
    });
    // result[key] = transformedArray;
    result[key] = {
      isGenAI: data[key].isGenAI,
      script: transformedArray,
    };
  }
  return result;
};
const errorHandler = (res, error) => {
  console.error(error);
  res
    .status(StatusCodes.INTERNAL_SERVER_ERROR)
    .json({ message: "An error occurred", error });
};


const safeJSON = function (str) {
  try {
    const res = JSON.parse(str);
    if (typeof res === "object") {
      return res;
    } else {
      return null;
    }
  } catch (err) {
    return null;
  }
};


const preparePayload = (transformedData, body) => {
  return {
    json: transformedData,
    url: `${body.dropdownWebHook.trim()}/chatbot/hooks/${body.botId.trim()}`,
    clientId: body.clientId.trim(),
    clientSecret: body.clientSecret.trim(),
    email: body.email.trim(),
  };
};
const filterUseCases = (allUseCases, requestedUseCases) => {
  return Object.keys(allUseCases)
    .filter((key) => requestedUseCases.includes(key))
    .reduce((acc, curr) => {
      acc[curr] = allUseCases[curr];
      return acc;
    }, {});
};

const generateToken = (clientId, clientSecret) => {
  const jwt_payload = {
    sub: "1234567890",
    appId: clientId,
  };

  return jwt.sign(jwt_payload, clientSecret, {
    algorithm: "HS256",
    noTimestamp: true,
  });
};
let returnValues = (type, payload) => {
  let messageText = [];

  switch (type) {
    case "button":
      messageText.push(payload.text);

      if (payload.buttons && payload.buttons.length) {
        payload.buttons.forEach((button) => {
          messageText.push(button.title);
        });
      }
      return messageText;
    case "quick_replies":
      messageText.push(payload.text);
      if (payload.quick_replies && payload.quick_replies.length) {
        payload.quick_replies.forEach((quick_reply) => {
          messageText.push(quick_reply.title);
        });
      }
      return messageText;

    case "listView":
    case "listViewTable":
    case "dropdown_template":
    case "multi_select":
    case "Cardtemplate":
      messageText.push(payload.text || payload.heading);
      if (payload.elements && payload.elements.length) {
        payload.elements.forEach((element) => {
          messageText.push(element.title);
        });
      }
      return messageText;

    case "carousel":
      messageText.push(payload.title);
      if (payload.elements && payload.elements.length) {
        payload.elements.forEach((element) => {
          messageText.push(element.title);
        });
      }
      return messageText;

    case "quick_replies_welcome":
      messageText.push(payload.text);
      if (payload.quick_replies && payload.quick_replies.length) {
        payload.quick_replies.forEach((quick_reply) => {
          messageText.push(quick_reply.title);
        });
      }
      return messageText;

    case "listWidget":
      messageText.push(payload.title);
      if (payload.elements && payload.elements.length) {
        payload.elements.forEach((element) => {
          messageText.push(element.title);
        });
      }
      return messageText;

    default:
      console.warn(`Unhandled type: ${type}`);
      return messageText;
  }
};
const handleTemplates = (template) => {
  const parsedTemplate = JSON.parse(template);
  const templateType = parsedTemplate.payload.template_type.trim();
  switch (templateType) {
    case "button":
      return returnValues("button", parsedTemplate.payload);
    case "quick_replies":
      return returnValues("quick_replies", parsedTemplate.payload);
    case "carousel":
      return returnValues("carousel", parsedTemplate.payload);
    case "listView":
    case "listViewTable":
    case "dropdown_template":
    case "multi_select":
    case "Cardtemplate":
      return returnValues(templateType, parsedTemplate.payload);
    case "listWidget":
      return returnValues("listWidget", parsedTemplate.payload);
    default:
      console.warn(`Unhandled template type: ${templateType}`);
      return [];
  }
};

const UploadCsvSchema = z.object({
  file: z.instanceof(Buffer, "File is required and should be in Buffer format"),
  clientSecret: z.string(),
  clientId: z.string(),
  botId: z.string(),
  // botname: z.string(),
  email: z.string().email("Invalid email format"),
});
const startProcessSchema = z.object({
  id: z.string(),
  useCases: z.array(z.string()),
});
const processProgressSchema = z.object({
  id: z.string().regex(/^[a-fA-F0-9]+$/, "Invalid process ID format"),
});

exports.uploadCSV = async (req, res) => {
  try {
    const formData = {
      file: req.file?.buffer, // multer loads file as a Buffer
      clientSecret: req.body.clientSecret,
      clientId: req.body.clientId,
      botId: req.body.botId,
      // botname: req.body.botname,
      email: req.body.email,
    };
    UploadCsvSchema.parse(formData);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(StatusCodes.BAD_REQUEST).json({ errors: error.errors });
    }
    return res
      .status(StatusCodes.INTERNAL_SERVER_ERROR)
      .json({ error: "Server error" });
  }
  const results = [];
  const parser = parse({ columns: false });

  parser.write(req.file.buffer.toString());
  parser.end();

  parser.on("data", (data) => {
    results.push(data);
  });

  parser.on("end", async () => {
    const finalObject = processCSVData(results);
    try {
      const transformedData = restructureConversation(finalObject);
      const payload = preparePayload(transformedData, req.body);
      let config = {
        method: "post",
        maxBodyLength: Infinity,
        headers: {
          "Content-Type": "application/json",
        },
      };

      let result = await axios.post(
        "https://dpd.kore.ai/testing-framework",
        payload,
        config
      );
      let responseObject = {
        // useCases: Object.keys(transformedData),
        useCases: Object.keys(transformedData).map((usecase) => ({
          usecase,
          isGenAI: transformedData[usecase]["isGenAI"],
        })),
        id: result.data.id,
      };
      console.log("respnseObject", responseObject);
      res.status(StatusCodes.CREATED).json(responseObject);
    } catch (error) {
      errorHandler(res, error);
    }
  });
};

exports.startProcess = async (req, res) => {
  try {
    const requestData = {
      id: req.body.id,
      useCases: req.body.useCases,
    };
    startProcessSchema.parse(requestData);
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(StatusCodes.BAD_GATEWAY).json({ errors: error.errors });
    }
    res
      .status(StatusCodes.INTERNAL_SERVER_ERROR)
      .json({ error: "Server error" });
  }
  const { id, useCases: requestedUseCases } = req.body;

  try {
    const jsonDump = await axios.get(
      `https://dpd.kore.ai/testing-framework/${id}`
    );
    const filteredUseCases = filterUseCases(
      jsonDump.data.json,
      requestedUseCases
    );

    console.log("filteredUseCases", filteredUseCases);

    const generatedToken = generateToken(
      jsonDump.data.clientId,
      jsonDump.data.clientSecret
    );
    processStatus[id] = {
      id,
      requestedUseCases,
      progress: 0,
      finalResponse: [],
      completed: false,
    };
    setTimeout(
      () => processUseCases(id, filteredUseCases, generatedToken, jsonDump),
      0
    );

    res.json({ message: "Process started", id });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error starting process", error: error.message });
  }
};

const processUseCases = async (id, filteredUseCases, generatedToken, jsonDump) => {
  let finalResponse = [];
  let processedCount = 0;
  const totalUseCases = Object.keys(filteredUseCases).length;

  // giving the list of assistant created
  const { data } = await openAIClient.beta.assistants.list();
  // change the name of the vartual assitant here as well
  const assistant = data.filter(({ name }) => name === "Bot Tester 300");

  for (const each of Object.keys(filteredUseCases)) {
    let useCasesList = filteredUseCases[each].script.filter(
      (usecase) => typeof usecase === "object" && !Array.isArray(usecase)
    );

    const executionResponse = [];
    let totalCases = useCasesList.length;
    let passedCases = 0;
    let failedCases = 0;
    let startTime = Date.now();
    let isGenAi = filteredUseCases[each]["isGenAI"];

    const email = jsonDump.data.email;
    const webhookurl = jsonDump.data.url;
    const firstName = email.split(".")[0];
    const lastName = email.split(".")[1].split("@")[1];



    if (filteredUseCases[each]["isGenAI"]) {
      console.log("Running the GENAI UseCase")
      let message = `Test the conversation based on the conversation script given \n Conversation Script: \n Use Case Name: ${each} \n Conversations: \n ${useCasesList
        .map((usecase) => `User: ${usecase["User"]}\nBot: ${usecase["Bot"]}}`)
        .join("\n")}`;
      console.log(message);
      const thread = await openAIClient.beta.threads.create({
        messages: [
          {
            role: "user",
            content: message,
          },
          {
            role: "user",
            content: readFileSync("./prompt.txt", { encoding: "utf8" }),
          }
        ],
      });
      let i = 0;
      let result = null;
      while (true) {
        if (i > 0) {
          await openAIClient.beta.threads.messages.create(thread.id, {
            role: "user",
            content: message,
          });
        }
        const runContext = await openAIClient.beta.threads.runs.createAndPoll(
          thread.id,
          {
            assistant_id: assistant[0].id,
          }
        );
        const messages = await openAIClient.beta.threads.messages.list(
          thread.id,
          { run_id: runContext.id }
        );
        console.log("\nUser:\n", messages.data[0].content[0].text.value);
        const webhookurl = jsonDump.data.url;
        if ((result = safeJSON(messages.data[0].content[0].text.value))) {
          console.log("break", result);
          break;
        }
        try {
          const request_object = {
            method: "POST",
            headers: {
              Authorization: "bearer " + generatedToken,
              "Content-Type": "application/json",
            },
            data: {
              session: {
                new: i === 0,
              },
              message: {
                text: messages.data[0].content[0].text.value,
              },
              from: {
                id: firstName,
                userInfo: {
                  firstName,
                  lastName,
                  email,
                },
              },
            },
          };

          const response = await axios.post(webhookurl, request_object.data, {
            headers: request_object.headers,
            method: request_object.method,
          });
          message = Array.isArray(response.data.text)
            ? response.data.text.join(" ")
            : response.data.text;
          console.log("\nBot:\n", message);
          const result = {
            User: messages.data[0].content[0].text.value,
            Bot: useCasesList[i] ? useCasesList[i]["Bot"] : "No response",
            webHookResult: message,
          };
          executionResponse.push(result);
        } catch (err) {
          console.log(err);
          const result = {
            User: messages.data[0].content[0].text.value,
            Bot: useCasesList[i] ? useCasesList[i]["Bot"] : "No response",
            webHookResult:
              "Error occured while sending response to the webhook",
          };
          executionResponse.push(result);
        } finally {
          i++;
        }
      }
      let endTime = Date.now();
      let duration = (endTime - startTime) / 1000;
      finalResponse.push({
        [each]: {
          "Use cases": executionResponse,
          Result: result.status === 'fail' ? 'Failed' : "Passed",
          Duration: `${duration}s`,
          "Total Cases": totalCases,
          reason: result.reason,
          PercentagePassed: `${result.score}%`,
          isGenAi: isGenAi
        },
      });
    }
    else {
      console.log("Running the Normal usecase")


      console.log(`Processing use cases for key: ${each}`);

      for (let i = 0; i < useCasesList.length; i++) {
        try {
          console.log(`Processing use case ${i + 1}/${totalCases}`);

          const requestObject = {
            method: "POST",
            headers: {
              Authorization: "bearer " + generatedToken,
              "Content-Type": "application/json",
            },
            data: {
              session: {
                new: i === 0,
              },
              message: {
                text: useCasesList[i]["User"],
              },
              from: {
                id: firstName,
                userInfo: {
                  firstName,
                  lastName,
                  email,
                },
              },
            },
          };

          const response = await axios.post(webhookurl, requestObject.data, {
            headers: requestObject.headers,
          });

          const responseText = Array.isArray(response.data.text)
            ? response.data.text.join(" ")
            : response.data.text;

          const score = natural.JaroWinklerDistance(
            responseText,
            Array.isArray(useCasesList[i]["Bot"])
              ? useCasesList[i]["Bot"].join(" ")
              : useCasesList[i]["Bot"]
          );

          const result = {
            User: useCasesList[i]["User"],
            Bot: useCasesList[i]["Bot"],
            testResult: useCasesList[i]["Bot"],
            isJSON: isJSON(response.data.text),
            webHookResult: isJSON(response.data.text)
              ? handleTemplates(response.data.text)
              : response.data.text,
            status:
              score > 0.7 || responseText.includes(useCasesList[i]["Bot"])
                ? "Success"
                : "Failed",
            score,
          };

          executionResponse.push(result);
          console.log(`Use case ${i + 1} result:`, result);

          if (result.status === "Success") passedCases++;
          else failedCases++;
        } catch (err) {
          console.error(`Error processing use case ${i + 1}:`, err.message);

          executionResponse.push({
            User: useCasesList[i]["User"],
            Bot: useCasesList[i]["Bot"],
            testResult: useCasesList[i]["Bot"],
            webHookResult: "Error occurred while processing.",
            status: "Failed",
            errorDetails: err.message || JSON.stringify(err),
          });

          failedCases++;
        }
      }

      const endTime = Date.now();
      const duration = ((endTime - startTime) / 1000).toFixed(2);
      const percentagePassed = ((passedCases / totalCases) * 100).toFixed(2);

      finalResponse.push({
        [each]: {
          "Use cases": executionResponse,
          Result: failedCases === 0 ? "Passed" : "Failed",
          Duration: `${duration}s`,
          "Total Cases": totalCases,
          Pass: passedCases,
          Fail: failedCases,
          PercentagePassed: `${percentagePassed}%`,
          isGenAi: isGenAi
        },
      });

    }



    processedCount++;
    processStatus[id] = {
      ...processStatus[id],
      finalResponse,
      progress: Math.round((processedCount / totalUseCases) * 100),
      completed: processedCount === totalUseCases,
    };

    console.log(`Completed processing for key: ${each}`);
  }

  console.log("Final Response:", JSON.stringify(finalResponse, null, 2));
};

// Utility function to validate JSON
function isJSON(str) {
  try {
    JSON.parse(str);
    return true;
  } catch (e) {
    return false;
  }
}

exports.processProgress = async (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  console.log(req.params);
  try {
    const { id } = processProgressSchema.parse(req.params);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(StatusCodes.BAD_REQUEST).json({ errors: error.errors });
    }
    res
      .status(StatusCodes.INTERNAL_SERVER_ERROR)
      .json({ error: "Server error" });
  }
  const id = req.params.id;

  const sendProgress = () => {
    const { progress, finalResponse, completed } = processStatus[id] || {};
    res.write(
      `data: ${JSON.stringify({ progress, finalResponse, completed })}\n\n`
    );
    if (completed) {
      res.end();
    }
  };

  // Send the initial progress immediately
  sendProgress();

  // Set up an interval to send updates
  const intervalId = setInterval(() => {
    sendProgress();
    if (processStatus[id]?.completed) {
      clearInterval(intervalId);
    }
  }, 1000);

  req.on("close", () => {
    clearInterval(intervalId);
  });
};

exports.getCredentials = async (req, res) => {
  if (!AUTH_CLIENT_ID || !AUTH_API_KEY || !AUTH_APP_ID) {
    res
      .status(StatusCodes.UNAUTHORIZED)
      .json({ message: "Credentials missing in env file" });
  }
  const response = {
    CLIENT_ID: AUTH_CLIENT_ID,
    API_KEY: AUTH_API_KEY,
    APP_ID: AUTH_APP_ID,
  };
  res.status(StatusCodes.ACCEPTED).json(response);
};

// exports.getCredentials = async (req, res) => {
//   if (!AUTH_CLIENT_ID || !AUTH_API_KEY || !AUTH_APP_ID) {
//     res
//       .status(StatusCodes.UNAUTHORIZED)
//       .json({ message: "Credentials missing in env file" });
//   }
//   const response = {
//     CLIENT_ID: AUTH_CLIENT_ID,
//     API_KEY: AUTH_API_KEY,
//     APP_ID: AUTH_APP_ID,
//   };
//   res.status(StatusCodes.ACCEPTED).json(response);
// };

function getMostRecentHtmlFile(dir, fileExtension) {
  try {
    const files = fs.readdirSync(dir)
      .filter(file => file.endsWith(fileExtension))  // Only files with the given extension
      .map(file => {
        const filePath = path.join(dir, file);
        const stats = fs.statSync(filePath);  // Get stats for the file
        return { filePath, createdAt: stats.mtime };  // Return file path and last modified time (mtime)
      })
      .sort((a, b) => b.createdAt - a.createdAt);  // Sort by last modified time (descending)

    // Return the most recently modified file or null if no matching files are found
    return files.length > 0 ? files[0].filePath : null;
  } catch (err) {
    console.error('Error reading directory:', err);
    return null;  // Handle errors, e.g., directory not found
  }
}



exports.pythonNode = async (req, res) => {

  console.log('.....hi....')

  console.log("file", req.body)

  const docUrl = req.file.path;

  const { webSDKUrl } = req.body;

  const { emailWebsdk } = req.body;

  const { env } = req.body;


  if (!docUrl) {
    return res.status(400).json({ error: "docUrl is required" });
  }
  console.log("here", docUrl, webSDKUrl, emailWebsdk);

  res.send({ "result": "Email Sent" })


  // use this when raising PR
  const pythonProcess = spawn('/data/py3.9.18/venv/bin/python', ['/data/backend/new2.py', docUrl, webSDKUrl]);

  // Use this for local
  // const pythonProcess = spawn("python", ["new2.py", docUrl, webSDKUrl]);


  let result = "";
  pythonProcess.stdout.on("data", (data) => {
    // result += data.toString();'
    result += data.toString();
  });

  pythonProcess.stderr.on("data", (error) => {
    console.error("Python Error:", error.toString());
  });

  pythonProcess.on("close", async (code) => {
    if (code === 0) {
      try {

        //html file
        const outputDir = path.resolve(__dirname, '../data');
        console.log("op", outputDir);
        const recentHtmlFile = getMostRecentHtmlFile(outputDir, '.html');
        const recentJsonFile = getMostRecentHtmlFile(outputDir, '.json');
        const recentXlsxFile = getMostRecentHtmlFile(outputDir, '.xlsx');


        console.log("recentHtmlFile", recentHtmlFile, recentJsonFile, recentXlsxFile);



        let body = "<head><meta name='viewport' content='width=device-width, initial-scale=1' /><style>a{text-decoration: none;} body{background-image: url('https://images.pexels.com/photos/62693/pexels-photo-62693.jpeg');background-repeat: no-repeat;background-size: cover;} *{font-family: 'Trebuchet MS';}  i{color: white;padding-left: 0px;padding-right: 10px;} .button1{max-width:300px;margin-top:20px;width:auto;border-radius:50px;display: block;padding-top: 10px;padding-bottom: 10px;padding-left: 10px;padding-right: 10px;color: white;font-size: 12px;font-weight: bold;background-color: rgb(255, 125, 65); transition-duration: 0.3s;} .button1:hover{background-color: rgb(233, 92, 27);transition-duration: 0.5s;cursor: pointer;} .button2{max-width:300px;margin-top:20px;width:auto;border-radius:50px;display: block;padding-top: 10px;padding-bottom: 10px;padding-left: 10px;padding-right: 10px;color: white;font-size: 12px;font-weight: bold;background-color: rgb(106, 35, 248); transition-duration: 0.3s;} .button2:hover{background-color:rgb(60, 12, 192);transition-duration: 0.5s;cursor: pointer;} </style> <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css'><link rel='preconnect' href='https://fonts.googleapis.com'><link rel='preconnect' href='https://fonts.gstatic.com' crossorigin><link href='https://fonts.googleapis.com/css2?family=Sen&display=swap' rel='stylesheet'></head><body><center>Please find your execution results below: <br><br><br> HTML File: " + env + "/data/" + `${path.basename(recentHtmlFile)}` + " <br> XLSX File: " + env + "/data/" + `${path.basename(recentXlsxFile)}` + " </center></body>"

        const response = await sendMail(emailWebsdk, "Your Execution Results", body);



        // res.send({
        //   data: result,
        //   filePath: `data/${path.basename(recentHtmlFile)}`
        // });

        // Send the parsedResponse to the API
        // sendToAPI(parsedResponse);
      } catch (err) {
        console.error("Failed to parse Python response:", err);
        return res.status(500).json({ error: `Failed to process Python response: ${err.message}` });
      }
    } else {
      console.error(`Python script exited with code ${code}`);
      return res.status(500).json({ error: `Python script failed with exit code ${code}` });
    }
  });
}