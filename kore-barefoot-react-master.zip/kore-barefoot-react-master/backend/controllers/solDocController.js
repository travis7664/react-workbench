const mysql = require('mysql2/promise');
const dbConfig = require('../config/dbConfig');

function createPool(config) {
    return mysql.createPool(config);
}

const pool = createPool(dbConfig);

exports.GetSolDocs=async (req,res) =>{
    try{
        const sol_id=(req.query.id);
        console.log(sol_id);
        if(!sol_id){
        const [data] = await pool.execute(
            "SELECT * FROM solution_doc;"
        );
        res.json({ success: true, message: 'fetching documents successful', data});
        }
        else{
            const [data] = await pool.execute(
                "SELECT * FROM solution_doc where solution_id=?;",[sol_id]
                
            );
            res.json({ success: true, message: 'fetching documents successful', data});
        }
       


    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Internal Server Error' });      
    }
}

exports.AddSolDocs= async(req,res)=>{
   
    try{
            const doc_title = req.body.doc_title || null;
            const solution_id = req.body.solution_id || null;
            const doc_url = req.body.doc_url || null;
            const up_doc = req.body.up_doc || null;
            

           const data= await pool.execute("insert into solution_doc (doc_title,solution_id,doc_url,up_doc) values (?,?,?,?);",
                [doc_title, solution_id, doc_url, up_doc]);
                res.json({ success: true, message: 'added document successful', data});
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Internal Server Error' });
       
        
    }

}


exports.EditSolDocs = async (req, res) => {
    try {
        const docId = req.query.id;
        if (!docId) {
            return res.status(400).json({ success: false, message: 'Document ID is required' });
        }

        // Define the modified fields and their new values
        const updates = {
            doc_title: req.body.doc_title,
            solution_id: req.body.solution_id,
            doc_url: req.body.doc_url,
            up_doc: req.body.up_doc
        };

        // Filter out the fields that haven't been modified
        const setClause = [];
        const values = [];
        for (const [key, value] of Object.entries(updates)) {
            if (value !== undefined) { // Check for modified values
                setClause.push(`${key} = ?`);
                values.push(value);
            }
        }

        if (setClause.length > 0) {
            // Add the ID of the record to update as the last value
            values.push(docId);

            // Construct the UPDATE query
            const updateQuery = `UPDATE solution_doc SET ${setClause.join(', ')} WHERE id = ?;`;

            // Execute the query
            const [data] = await pool.execute(updateQuery, values);
            console.log(updateQuery);
            console.log(values);

            // Send the response
            res.json({ success: true, message: 'Document updated successfully', data });
        } else {
            // No fields to update
            res.json({ success: false, message: 'No fields to update' });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};


exports.DeleteSolDocs = async (req, res) => {
    try {
        const docId = req.query.id;
        if (!docId) {
            return res.status(400).json({ success: false, message: 'Document ID is required' });
        }

        // Execute the DELETE query
        const [result] = await pool.execute("DELETE FROM solution_doc WHERE id = ?", [docId]);

        if (result.affectedRows > 0) {
            res.json({ success: true, message: 'Document deleted successfully' });
        } else {
            res.json({ success: false, message: 'No document found with the provided ID' });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};
