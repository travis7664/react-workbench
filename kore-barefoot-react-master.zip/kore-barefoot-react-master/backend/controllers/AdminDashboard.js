const express = require("express");
const connection = require("../config/sqlConnection");

const showProjUsers = async (req, res) => {
  try {
    const { did } = req.params;

    if (!did) {
      return res.status(400).json({ error: "Demo ID is required" });
    }

    // SQL query to get users associated with the demo ID
    const sqlQuery = `
      SELECT
        u.uid,
        u.name AS user_name,
        r.rid,
        r.name AS role_name,
        IFNULL(upd.contributed_percentage, 0) AS contributed_percentage,
        IFNULL(upd.status, '') AS user_project_status
      FROM
        users_projects up
      JOIN
        users u ON up.uid = u.uid
      JOIN
        role r ON up.rid = r.rid
      LEFT JOIN
        users_projects_details upd ON up.uid = upd.uid AND up.did = upd.pid
      WHERE
        up.did = ?
    `;

    // Execute the query
    connection.query(sqlQuery, [did], (err, results) => {
      if (err) {
        console.error("Error querying database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.length === 0) {
        return res
          .status(404)
          .json({ error: "No users found for the given Demo ID" });
      }

      // Format and return the results
      const users = results.map((row) => ({
        uid: row.uid,
        user_name: row.user_name,
        role: {
          rid: row.rid,
          name: row.role_name,
        },
        contributed_percentage: row.contributed_percentage
          ? Number(row.contributed_percentage)
          : null,
        user_project_status: row.user_project_status,
      }));

      res.json({ demo_id: did, users });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const showProjDetailsOfUsers = async (req, res) => {
  try {
    const { uid } = req.params;

    const userQuery = `SELECT
      u.uid,
      u.name AS user_name,
      u.mail,
      d.did,
      d.project_name,
      d.current_status,
      IFNULL(upd.contributed_percentage, 0) AS contributed_percentage,
      d.actual_end_date,
      r.rid AS role_id,
      r.name AS role_name
    FROM
      users u
    LEFT JOIN
      users_projects up ON u.uid = up.uid
    LEFT JOIN
      demos d ON up.did = d.did AND d.current_status = 'progress'
    LEFT JOIN
      role r ON up.rid = r.rid
    LEFT JOIN
      users_projects_details upd ON up.uid = upd.uid AND up.did = upd.pid
    WHERE
      u.uid = ? AND u.isactive = true;`;

    connection.query(userQuery, [uid], (err, results) => {
      if (err) {
        console.error("Error querying database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.length === 0) {
        return res
          .status(201)
          .json({ error: "No project details found for the user" });
      }

      const user = {
        uid: results[0].uid,
        user_name: results[0].user_name,
        mail: results[0].mail,
        demos: [],
      };

      results.forEach((row) => {
        if (row.did && !user.demos.some((demo) => demo.did === row.did)) {
          user.demos.push({
            did: row.did,
            project_name: row.project_name,
            current_status: row.current_status,
            contributed_percentage: Number(row.contributed_percentage),
            actual_end_date: row.actual_end_date,
            role: {
              rid: row.role_id,
              name: row.role_name,
            },
          });
        }
      });

      res.json(user);
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const assignRole = async (req, res) => {
  try {
    const users = req.body;

    if (!Array.isArray(users) || users.length === 0) {
      return res
        .status(400)
        .json({ error: "Request body must be an array of user-role pairs" });
    }

    const userPromises = users.map((user) => {
      return new Promise((resolve, reject) => {
        const { uid, rid } = user;
        if (!uid || !Array.isArray(rid) || rid.length === 0) {
          return reject(
            new Error(
              "uid and rid array are required for each user, and rid must be an array with at least one role ID"
            )
          );
        }

        const deleteQuery = "DELETE FROM users_roles WHERE uid = ?";
        connection.query(deleteQuery, [uid], (deleteErr, deleteResults) => {
          if (deleteErr) {
            console.error(`Error deleting roles for uid ${uid}:`, deleteErr);
            return reject(deleteErr);
          }

          if (deleteResults.affectedRows === 0) {
            console.warn(
              `No roles found for uid ${uid}, proceeding with insertion`
            );
          }

          const insertQuery =
            "INSERT INTO users_roles (uid, rid) VALUES (?, ?)";

          const insertRolePromises = rid.map((roleId) => {
            return new Promise((roleResolve, roleReject) => {
              connection.query(
                insertQuery,
                [uid, roleId],
                (insertErr, insertResults) => {
                  if (insertErr) {
                    console.error(
                      `Error inserting role ${roleId} for uid ${uid}:`,
                      insertErr
                    );
                    return roleReject(insertErr);
                  }
                  roleResolve(insertResults.insertId);
                }
              );
            });
          });

          Promise.all(insertRolePromises)
            .then((roleInsertIds) => resolve(roleInsertIds))
            .catch((roleInsertErr) => reject(roleInsertErr));
        });
      });
    });

    Promise.all(userPromises)
      .then((allInsertIds) => {
        res.status(201).json({
          success: true,
          message: "New roles assigned successfully for user",
          insertIds: allInsertIds.flat(),
        });
      })
      .catch((error) => {
        console.error("Error processing users:", error);
        res
          .status(500)
          .json({ error: "Internal Server Error during role assignment" });
      });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const updateTeam = async (req, res) => {
  try {
    const { uid, team } = req.body;

    if (!uid) {
      return res.status(400).json({ error: "uid is required" });
    }

    const sqlQuery = "UPDATE users SET team = ? ,isactive = 1  WHERE uid = ?";
    connection.query(sqlQuery, [team, uid], (err, results) => {
      if (err) {
        console.error("Error updating database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.affectedRows === 0) {
        return res.status(404).json({ error: "user not found" });
      }

      res.json({ message: "team updated successfully" });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// const updateUsersActiveStatus = async (req, res) => {
//   try {
//     const { isactive, uid } = req.body;

//     if (!uid) {
//       return res.status(400).json({ error: "uid is required" });
//     }

//     const sqlQuery = "UPDATE users SET isactive = ?  WHERE uid = ?";
//     connection.query(sqlQuery, [isactive, uid], (err, results) => {
//       if (err) {
//         console.error("Error updating database:", err);
//         return res.status(500).json({ error: "Internal Server Error" });
//       }

//       if (results.affectedRows === 0) {
//         return res.status(404).json({ error: "user not found" });
//       }

//       res.json({ message: "status updated successfully" });
//     });
//   } catch (error) {
//     console.error("Error:", error.message);
//     res.status(500).json({ error: "Internal Server Error" });
//   }
// };

const updateUsersActiveStatus = async (req, res) => {
  try {
    const { isactive, uid } = req.body;

    // Ensure `uid` is provided
    if (!uid) {
      return res.status(400).json({ error: "uid is required" });
    }

    // Step 1: Get the user's email by `uid`
    const selectQuery = "SELECT mail FROM users WHERE uid = ?";
    connection.query(selectQuery, [uid], (err, results) => {
      if (err) {
        console.error("Error fetching email from database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.length === 0) {
        return res.status(404).json({ error: "user not found" });
      }

      const email = results[0].mail;
      console.log(email);

      // Step 2: Update the `isactive` status for the user
      const updateStatusQuery = "UPDATE users SET isactive = ? WHERE uid = ?";
      connection.query(updateStatusQuery, [isactive, uid], (err, results) => {
        if (err) {
          console.error("Error updating status in database:", err);
          return res.status(500).json({ error: "Internal Server Error" });
        }

        if (results.affectedRows === 0) {
          return res.status(404).json({ error: "user not found" });
        }

        // Step 3: Update the `is_verified` status for the user using their email
        const updateVerifiedQuery =
          "UPDATE user SET is_verified = ? WHERE email = ?";
        connection.query(
          updateVerifiedQuery,
          [isactive, email],
          (err, results) => {
            if (err) {
              console.error(
                "Error updating verification status in database:",
                err
              );
              return res.status(500).json({ error: "Internal Server Error" });
            }

            res.json({
              message: "Status and verification updated successfully",
            });
          }
        );
      });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

module.exports = {
  showProjUsers,
  showProjDetailsOfUsers,
  assignRole,
  updateTeam,
  updateUsersActiveStatus,
};
