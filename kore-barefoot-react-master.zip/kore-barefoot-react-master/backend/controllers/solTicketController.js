const mysql = require('mysql2/promise');
const dbConfig = require('../config/dbConfig');

function createPool(config) {
    return mysql.createPool(config);
}

const pool = createPool(dbConfig);

exports.GetIssues = async (req, res) => {
    try {
        const solutionname = req.query.solutionname;
        const status=req.query.status;
        if(solutionname)
        {
            if(!status)
            {
        const [data] = await pool.execute('select * from solution_issues2 where solutionname=?', [solutionname]);
        res.json({ success: true, message: 'Fetching issues successful', data });
        }
        else{
            const [data] = await pool.execute('select * from solution_issues2 where solutionname=? and issue_status=?', [solutionname,status]);
            res.json({ success: true, message: 'Fetching issues successful', data });
    
        }
        }
        else
        {
        const [data] = await pool.execute('select * from solution_issues2 ');
        res.json({ success: true, message: 'Fetching issues successful', data });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};


exports.AddIssue = async (req, res) => {
    try {
        const {
            solutionname = null,
            jiralink = null,
            issue_desc = null,
            issue_status = null,
            issue_date = null,
            assignto = null,
            created_date = null,
            user = null
        } = req.body;

        // Insert the issue into the database
        const [result] = await pool.execute(
            `INSERT INTO solution_issues2 
            (solutionname, jiralink, issue_desc, issue_status, issue_date, assignto, created_date, user) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [solutionname, jiralink, issue_desc, issue_status, issue_date, assignto, created_date, user]
        );

        res.json({
            success: true,
            message: 'Issue added successfully',
            data: result
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Internal Server Error'
        });
    }
};



exports.EditIssue = async (req, res) => {
    try {
        const issueId = req.query.id;
        if (!issueId) {
            return res.status(400).json({ success: false, message: 'Issue ID is required' });
        }

        // Define the modified fields and their new values
        const updates = {
            solutionname: req.body.solutionname,
            jiralink: req.body.jiralink,
            issue_desc: req.body.issue_desc,
            issue_status: req.body.issue_status,
            issue_date: req.body.issue_date,
            assignto: req.body.assignto,
            created_date: req.body.created_date,
            user: req.body.user
        };

        // Filter out the fields that haven't been modified
        const setClause = [];
        const values = [];
        for (const [key, value] of Object.entries(updates)) {
            if (value !== undefined) { // Check for modified values
                setClause.push(`${key} = ?`);
                values.push(value);
            }
        }

        if (setClause.length > 0) {
            // Add the ID of the record to update as the last value
            values.push(issueId);

            // Construct the UPDATE query
            const updateQuery = `UPDATE solution_issues2 SET ${setClause.join(', ')} WHERE id = ?;`;

            // Execute the query
            const [result] = await pool.execute(updateQuery, values);

            res.json({ success: true, message: 'Issue updated successfully', data: result });
        } else {
            res.json({ success: false, message: 'No fields to update' });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};


exports.DeleteIssue = async (req, res) => {
    try {
        const issueId = req.query.id;
        if (!issueId) {
            return res.status(400).json({ success: false, message: 'Issue ID is required' });
        }

        // Execute the DELETE query
        const [result] = await pool.execute("DELETE FROM solution_issues2 WHERE id = ?", [issueId]);

        if (result.affectedRows > 0) {
            res.json({ success: true, message: 'Issue deleted successfully' });
        } else {
            res.json({ success: false, message: 'No issue found with the provided ID' });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};
