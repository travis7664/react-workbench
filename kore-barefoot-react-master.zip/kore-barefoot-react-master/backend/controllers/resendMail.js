const { generateToken, verifyToken } = require("../helpers/jwtHelper"); // Import JWT token-related code
const sendMail = require("../helpers/sendMail");
const con = require("../config/dbConnection");
const connection = con.getConnection();
connection.connect();

const resendMail = (req, res) => {
  const { email } = req.query;
  console.log(email);
  connection.query(
    "SELECT * FROM user WHERE LOWER(email) = LOWER(?);",
    [email],
    (err, rows) => {
      if (err) {
        console.log(err);
        //   return res.render('error.ejs', { errorText: 'Error querying the database' });
        res
          .status(500)
          .json({ success: false, message: "Error querying the database" });
      }
      if (!rows.length) {
        //return res.render('error.ejs', { errorText: 'Email does not exist' });
        res
          .status(500)
          .json({ success: false, message: "Email is not registered" });
      }
      if (rows[0].is_verified === 0) {
        const jwtPayload = { email, uniqueIdentifier: Date.now() };
        const jwtOptions = { expiresIn: "20m" };
        const token = generateToken(jwtPayload, jwtOptions.expiresIn);
        let mailSubject = "Mail Verification";
        let content = `<p> Hi Admin, Please <a href="${process.env.APP_API_BASE_URL}/auth/mail-verification?token=${token}&email=${email}"> verify </a></p><br><p> Hi krishna, Please <a href="${process.env.APP_API_BASE_URL}/auth/resendMail?email=${email}"> Click here if the link above expired </a></p>`;
        sendMail("barefoot@kore.com", mailSubject, content);
        //   return res.render('resend_success.ejs', { names: rows[0].firstname });
        res.json({ success: true, message: "Successfully Sent" });
      } else {
        res
          .status(500)
          .json({ success: false, message: "This Email is already verified" });
      }
    }
  );
};

module.exports = {
  resendMail,
};
