const axios = require('axios');

exports.GetJira = async (req, res) => {
    try {
        const ticket = req.query.tid;
        console.log(ticket);

        const headers = {
            'Authorization': 'Basic a2lyYW4ucGF0aWxAa29yZS5jb206SzY1WlhrNE5IVmx1aXJJRVlGcDhDNjk5',
            'Content-Type': 'application/json'
        };

        // Make the GET request to the external API
        const response = await axios.get(`https://koreteam.atlassian.net/rest/api/2/issue/${ticket}?fields=description,status,duedate,assignee,created`, { headers });

        // Ensure response.data and response.data.fields exist
        if (response.data && response.data.fields) {
            const fields = response.data.fields;
            const rows = {
                description: fields.description,
                status: fields.status.name,
                duedate: fields.duedate,
                created: fields.created,
                assignee: fields.assignee.displayName
            };

            res.json({ success: true, message: 'Fetching Ticket details successful', rows });
        } else {
            res.json({ success: true, message: 'No ticket found with the concerned ticket id' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};
