const { User, Role, UserRole } = require('../model/associations');

exports.getUsersByRole = async (req, res) => {
  try {
    const roleName = req.params.roleName;
    const { name, mail } = req.query;

    const whereClause = {};
    if (name) whereClause.name = name;
    if (mail) whereClause.mail = mail;

    const users = await User.findAll({
      where: whereClause,
      include: [{
        model: Role,
        through: UserRole,
        where: { name: roleName }
      }]
    });

    const results = users.map(user => ({
      uid: user.uid,
      user_name: user.name,
      mail: user.mail,
      role_name: roleName
    }));

    res.json(results);
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};