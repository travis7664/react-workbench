const mysql = require('mysql2/promise');
const dbConfig = require('../config/dbConfig');

// Database setup
function createPool(config) {
    return mysql.createPool(config);
}

const pool = createPool(dbConfig);
exports.PosttIssues= async(req,res)=>{
   
    try{
        //console.log(req.body)
        const demoid=(req.query.id);
        console.log(demoid);
        const userExists = await pool.execute("select * from demos where did=?;", [demoid]);
        console.log(userExists[0].length)
        if (userExists[0].length!=0) {
            //console.log('hi')
            // const entity_id = demoid;
            // const current_status = req.body.current_status || "_";
            // const perc_completed = req.body.perc_completed || "_";
            // const user = req.body.user;
            // const created = req.body.created || "_";
            
            const project_id =demoid;
            const status_id = req.body.status_id ;
            const digite_id= req.body.digite_id;
            const digite_url = req.body.digite_url;
            const issue_status = req.body.issue_status;
            const user = req.body.user;
            const issue_description = req.body.issue_description;
            const created = req.body.created;
            const assigned_to = req.body.assigned_to;
            const issue_closed_date = req.body.issue_closed_date;

           const data= await pool.execute("insert into proj_status_bugs (project_id,status_id,digite_id,digite_url,issue_status,user,issue_description,created,assigned_to,issue_closed_date) values (?,?,?,?,?,?,?,?,?,?);",
                [project_id,status_id,digite_id,digite_url,issue_status,user,issue_description,created,assigned_to,issue_closed_date]);
                res.json({ success: true, message: 'Updated issues successfully', data});

            
        } else {
            res.json({ success: true, message: 'No Demo exists' });
        }
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Internal Server Error' });
       
        
    }

}