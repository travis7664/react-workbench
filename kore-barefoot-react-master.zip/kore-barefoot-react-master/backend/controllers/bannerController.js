const mysql = require('mysql2/promise');
const dbConfig = require('../config/dbConfig');

// Database setup
function createPool(config) {
    return mysql.createPool(config);
}

const pool = createPool(dbConfig);

exports.Getbanner=async (req,res) =>{
    try{
        const [updates]=await pool.execute("select * from banners ")

        if (updates.length !=0) {
            
            res.json({ success: true, message: 'Fetching updates related to banner successful', updates});
           

        } else {
            res.json({ success: true, message: 'No updates Found related to banner' });

        }


    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Internal Server Error' });
       
        
    }
}

exports.Addbanner= async(req,res)=>{
   
    try{
       
            const banner_text = req.body.banner_text || "_";
            const banner_status = req.body.banner_status || "_";
            const banner_category = req.body.banner_category || "_";
            const banner_color = req.body.banner_color || "_";
            

           const data= await pool.execute("insert into banners (banner_text,banner_status,banner_category,banner_color) values (?,?,?,?);",
                [banner_text,banner_status,banner_category,banner_color]);
                res.json({ success: true, message: 'Adding banner successful', data});

            
      
    }
    catch (error) {
        console.log(error)
        res.status(500).json({ success: false, message: 'Internal Server Error' });
       
        
    }

}


  
exports.Editbanner= async(req,res)=>{
   
    try{
        
        const uid=(req.query.uid);
        console.log(uid);
        const updateExists = await pool.execute("select * from banners where id=?;", [uid]);
        console.log(updateExists[0].length)
        if (updateExists[0].length!=0) {
             
    const updates = {
        

        banner_text : req.body.banner_text ,
        banner_status: req.body.banner_status,
        banner_category : req.body.banner_category,
        banner_color : req.body.banner_color
        
   
  };
  
  const setClause = [];
  const values = [];
  for (const [key, value] of Object.entries(updates)) {
    if (value !== undefined) { 
      setClause.push(`${key} = ?`);
      values.push(value);
    }
  }
  
  if (setClause.length > 0) {
   
    values.push(uid);
  
    const updateQuery = `UPDATE banners SET ${setClause.join(', ')} WHERE id = ?;`;
  console.log(updateQuery)
  console.log(values)
    const data = await pool.execute(updateQuery, values);
  
    res.json({ success: true, message: 'Updated the update related to banner successfully', data });
  } else {
    res.json({ success: false, message: 'No fields to update' });
  }
  
            
        } else {
            res.json({ success: true, message: 'No update related to banner exists' });
        }
    }
    catch (error) {
        console.log(error)
        res.status(500).json({ success: false, message: 'Internal Server Error' });
       
        
    }

}

exports.Deletebanner=async(req,res)=>{
    try {
        const uid=(req.query.uid);
        console.log(uid);
        const updateExists = await pool.execute("select * from banners where id=?;", [uid]);
        console.log(updateExists[0].length)
        if (updateExists[0].length!=0) {
            const data= await pool.execute("delete from banners where id=? ;",[uid]);
            res.json({ success: true, message: 'deleting banner successful', data});

        }
        else{
            res.json({ success: true, message: 'No banner found with corresponding id', updateExists});
        }
        
    } catch (error) {
        console.log(error)
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
}  
exports.GetSolReport = async (req, res) => {
    try {
        const [data] = await pool.execute('select * from solReport');
        res.json({ success: true, message: 'Fetching issues successful', data });
        }
     catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};
// exports.PutSolReport= async (req,res) => {
//     try{
        
//         const solReport=(req.body.solReport);
//         console.log(solReport);
//         const [updateExists] = await pool.execute("select * from solReport ");
//         console.log(updateExists)
//         // Step 1: Filter out only the changed rows
// const updates = updateExists.filter(row => {
//     // If sol_id exists in body and the URLs are different
//     return solReport[row.sol_id] && solReport[row.sol_id] !== row.url;
//   });
  
//   // Step 2: Generate the SQL update query
//   updates.forEach(row => {
//     const newUrl = solReport[row.sol_id]; // Get the new URL from the solReport
//     const query=`UPDATE solReport SET url = '${newUrl}' WHERE sol_id = ${row.sol_id};`;
//     const [updates1]=await pool.execute(query);

//   });
//             res.json({ success: true, message: 'Updated the update related to banner successfully', updateExists,solReport,updates1 });
// //             [0].length)
// //         if (updateExists[0].length!=0) {
             
// //     const updates = {
        

// //         banner_text : req.body.banner_text ,
// //         banner_status: req.body.banner_status,
// //         banner_category : req.body.banner_category,
// //         banner_color : req.body.banner_color
        
   
// //   };
  
// //   const setClause = [];
// //   const values = [];
// //   for (const [key, value] of Object.entries(updates)) {
// //     if (value !== undefined) { 
// //       setClause.push(`${key} = ?`);
// //       values.push(value);
// //     }
// //   }
  
// //   if (setClause.length > 0) {
   
// //     values.push(uid);
  
// //     const updateQuery = `UPDATE banners SET ${setClause.join(', ')} WHERE id = ?;`;
// //   console.log(updateQuery)
// //   console.log(values)
// //     const data = await pool.execute(updateQuery, values);
  
// //     res.json({ success: true, message: 'Updated the update related to banner successfully', data });
// //   } else {
// //     res.json({ success: false, message: 'No fields to update' });
// //   }
  
            
// //         } else {
// //             res.json({ success: true, message: 'No update related to banner exists' });
// //         }
//     }catch (error) {
//         console.log(error);
//         res.status(500).json({ success: false, message: 'Internal Server Error' });
//     }
// }
exports.PutSolReport = async (req, res) => {
    try {
        const solReport = req.body.solReport;
        const [existingReports] = await pool.execute("SELECT * FROM solReport");
        const updates = existingReports.filter(row => {
            return solReport[row.sol_id] && solReport[row.sol_id] !== row.url;
        });

        if (updates.length > 0) {
            const updateQueries = updates.map(row => {
                const newUrl = solReport[row.sol_id]; 
                return pool.execute(`UPDATE solReport SET url = ? WHERE sol_id = ?`, [newUrl, row.sol_id]);
            });
            await Promise.all(updateQueries);
        }

        res.json({ success: true, message: 'Updated the records successfully', updates });

    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};
