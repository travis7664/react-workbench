const mysql = require("mysql2/promise");
const dbConfig = require("../config/dbConfig");

// Database setup
function createPool(config) {
  return mysql.createPool(config);
}

const pool = createPool(dbConfig);

exports.GetStatus = async (req, res) => {
  try {
    const demoid = req.query.id;
    console.log(demoid);
    const [rows] = await pool.execute(
      "select * from statuslog where entity_id = ?;",
      [demoid]
    );

    const [tickets] = await pool.execute(
      "select * from proj_status_bugs where project_id=?;",
      [demoid]
    );

    if (rows.length != 0 && tickets.length != 0) {
      res.json({
        success: true,
        message: "Fetching status fields & tickets successful",
        rows,
        tickets,
      });
    } else if (rows.length != 0) {
      res.json({
        success: true,
        message: "Fetching status   successful",
        rows,
      });
    } else if (tickets.length != 0) {
      res.json({
        success: true,
        message: "Fetching   tickets successful",
        tickets,
      });
    } else {
      res.json({
        success: true,
        message: "No Demo Found with the concerned demo id",
      });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};

exports.PosttStatus = async (req, res) => {
  try {
    //console.log(req.body)
    const demoid = req.query.id;
    console.log(demoid);
    const userExists = await pool.execute("select * from demos where did=?;", [
      demoid,
    ]);
    console.log(userExists[0].length);
    if (userExists[0].length) {
      console.log("hi");
      const entity_id = demoid;
      const current_status = req.body.current_status || "_";
      const perc_completed = req.body.perc_completed || "_";
      const user = req.body.user;
      const created = req.body.created || "_";

      const data = await pool.execute(
        "insert into statuslog (entity_id,current_status,perc_completed,user,created) values (?,?,?,?,?);",
        [entity_id, current_status, perc_completed, user, created]
      );
      res.json({ success: true, message: "Updated status successful", data });
    } else {
      res.json({ success: true, message: "No Demo exists" });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};

exports.UpdateStatus = async (req, res) => {
  try {
    const demoid = req.query.id;
    const userExists = await pool.execute(
      "SELECT * FROM demos WHERE did = ?;",
      [demoid]
    );
    console.log(userExists[0].length);

    if (userExists[0].length) {
      console.log("hi");
      const entity_id = demoid;
      const current_status = req.body.current_status || "_";
      const perc_completed = req.body.perc_completed || "_";
      const user = req.body.user;
      const created = req.body.created || "_";

      const data = await pool.execute(
        "UPDATE statuslog SET current_status = ?, perc_completed = ?, user = ?, created = ? WHERE entity_id = ? AND created = ?;",
        [current_status, perc_completed, user, created, entity_id, created]
      );

      res.json({ success: true, message: "Status updated successfully", data });
    } else {
      res.json({ success: true, message: "No Demo exists" });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};
