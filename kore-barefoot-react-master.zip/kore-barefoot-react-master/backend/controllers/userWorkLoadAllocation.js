const express = require("express");
const connection = require("../config/sqlConnection");

const updateWorkload = async (req, res) => {
  try {
    const { contributed_percentage, uid, pid, updated_user } = req.body;

    if (!uid || !pid || contributed_percentage === undefined || !updated_user) {
      return res.status(400).json({
        error:
          "uid, pid, contributed_percentage, and updated_user are required",
      });
    }

    const checkQuery =
      "SELECT * FROM users_projects_details WHERE uid = ? AND pid = ?";
    connection.query(checkQuery, [uid, pid], (err, results) => {
      if (err) {
        console.error("Error querying database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.length === 0) {
        const insertQuery = `
          INSERT INTO users_projects_details 
          (uid, pid, contributed_percentage, updated_user, status) 
          VALUES (?, ?, ?, ?, 1)
        `;
        connection.query(
          insertQuery,
          [uid, pid, contributed_percentage, updated_user],
          (insertErr, insertResults) => {
            if (insertErr) {
              console.error("Error inserting into database:", insertErr);
              return res.status(500).json({ error: "Internal Server Error" });
            }

            return res
              .status(201)
              .json({ message: "Record added successfully" });
          }
        );
      } else {
        const updateQuery = `
          UPDATE users_projects_details 
          SET contributed_percentage = ?, updated_user = ?, status = 1 
          WHERE uid = ? AND pid = ?
        `;
        connection.query(
          updateQuery,
          [contributed_percentage, updated_user, uid, pid],
          (updateErr, updateResults) => {
            if (updateErr) {
              console.error("Error updating database:", updateErr);
              return res.status(500).json({ error: "Internal Server Error" });
            }

            return res.json({ message: "Record updated successfully" });
          }
        );
      }
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const ReleseUser = async (req, res) => {
  try {
    const { uid, pid } = req.body;

    if (!uid || !pid) {
      return res.status(400).json({ error: "uid and pid are required" });
    }

    const sqlQuery =
      "UPDATE users_projects_details SET contributed_percentage = 0, status = 0 WHERE uid = ? and pid = ?";
    connection.query(sqlQuery, [uid, pid], (err, results) => {
      if (err) {
        console.error("Error updating database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.affectedRows === 0) {
        return res.status(404).json({ error: "user not found" });
      }

      res.json({ message: "user relesed successfully" });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

module.exports = {
  updateWorkload,
  ReleseUser,
};
