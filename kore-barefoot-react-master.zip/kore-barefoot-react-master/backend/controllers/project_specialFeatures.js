const express = require('express');
const connection = require('../config/sqlConnection');


const showProjFeature = async (req, res) => {
    try {
      const { did } = req.params; 
      const demo_id = did;

      if (!demo_id) {
        return res.status(400).json({ error: 'Demo ID is required' });
      }
  
      const sqlQuery = `
        SELECT
          sf.id,
          sf.category_name,
          sf.feature_name,
          sf.id
        FROM
          proj_spec_features psf
        JOIN
          special_features sf ON psf.feature_id = sf.id
        WHERE
          psf.demo_id = ?
      `;
  
      connection.query(sqlQuery, [did], (err, results) => {
        if (err) {
          console.error('Error querying database:', err);
          return res.status(500).json({ error: 'Internal Server Error' });
        }
  
        if (results.length === 0) {
          return res.status(404).json({ error: 'No features found for the given Demo ID' });
        }
  
        const features = results.map(row => ({
          feature_id: row.id,
          category_name: row.category_name,
          feature_name: row.feature_name
        }));
  
        res.json({ demo_id: did, features });
      });
    } catch (error) {
      console.error('Error:', error.message);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };

  const assignFeature = async (req, res) => {
    try {
      const { did } = req.params; 
      const { feature_ids } = req.body;
      if (!Array.isArray(feature_ids) || feature_ids.length === 0) {
        return res.status(400).json({ error: 'Request body must be an array of feature IDs' });
      }
  
      if (!did) {
        return res.status(400).json({ error: 'demo_id (did) is required' });
      }
  
      const checkDemoQuery = 'SELECT COUNT(*) AS count FROM demos WHERE did = ?';
      connection.query(checkDemoQuery, [did], (checkErr, checkResults) => {
        if (checkErr) {
          console.error('Error checking demo ID in database:', checkErr);
          return res.status(500).json({ error: 'Internal Server Error' });
        }
  
        const demoExists = checkResults[0].count > 0;
        if (!demoExists) {
          return res.status(404).json({ error: `Demo ID ${did} not found` });
        }
  
        const insertFeatureQuery = 'INSERT INTO proj_spec_features (demo_id, feature_id) VALUES (?, ?)';
  
        const insertPromises = feature_ids.map(feature_id => {
          return new Promise((resolve, reject) => {
            if (!feature_id) {
              return reject(new Error('feature_id is required for each entry'));
            }
  
            connection.query(insertFeatureQuery, [did, feature_id], (err, results) => {
              if (err) {
                console.error('Error inserting into database:', err);
                return reject(err);
              }
              resolve(results.insertId);
            });
          });
        });
  
        Promise.all(insertPromises)
          .then(insertIds => {
            res.status(201).json({ message: 'Features assigned successfully', insertIds });
          })
          .catch(insertErr => {
            console.error('Error assigning features:', insertErr);
            res.status(500).json({ error: 'Internal Server Error', details: insertErr.message });
          });
      });
    } catch (error) {
      console.error('Error:', error.message);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };
  

  const deleteFeature = async (req, res) => {
    try {
      const { did } = req.params; 
      const { feature_ids } = req.body; 

      if (!Array.isArray(feature_ids) || feature_ids.length === 0) {
        return res.status(400).json({ error: 'Request body must be an array of feature IDs' });
      }
  
      if (!did) {
        return res.status(400).json({ error: 'demo_id (did) is required' });
      }
  
      const checkDemoQuery = 'SELECT COUNT(*) AS count FROM demos WHERE did = ?';
      connection.query(checkDemoQuery, [did], (checkErr, checkResults) => {
        if (checkErr) {
          console.error('Error checking demo ID in database:', checkErr);
          return res.status(500).json({ error: 'Internal Server Error' });
        }
  
        const demoExists = checkResults[0].count > 0;
        if (!demoExists) {
          return res.status(404).json({ error: `Demo ID ${did} not found` });
        }
  
        const deleteFeatureQuery = 'DELETE FROM proj_spec_features WHERE demo_id = ? AND feature_id = ?';
  
        const deletePromises = feature_ids.map(feature_id => {
          return new Promise((resolve, reject) => {
            if (!feature_id) {
              return reject(new Error('feature_id is required for each entry'));
            }
  
            connection.query(deleteFeatureQuery, [did, feature_id], (err, results) => {
              if (err) {
                console.error('Error deleting from database:', err);
                return reject(err);
              }
  
              if (results.affectedRows === 0) {
                return reject(`Feature with ID ${feature_id} not found for demo ID ${did}`);
              }
              resolve();
            });
          });
        });
  
        Promise.all(deletePromises)
          .then(() => {
            res.json({ message: 'Features removed successfully' });
          })
          .catch(deleteErr => {
            console.error('Error deleting features:', deleteErr);
            res.status(500).json({ error: 'Internal Server Error', details: deleteErr.message });
          });
      });
    } catch (error) {
      console.error('Error:', error.message);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };
  

module.exports = {
    showProjFeature,
    assignFeature,
deleteFeature
};
