const mysql = require('mysql2/promise');
const dbConfig = require('../config/dbConfig');

function createPool(config) {
    return mysql.createPool(config);
}

const pool = createPool(dbConfig);

exports.getSolutions=async (req, res) => {
    try {
        const solutionname = req.query.solutionname;
        if(solutionname)
        {
            
            const [data] = await pool.execute('SELECT * FROM solution_demo where solution_name=?;', [solutionname]);
            res.json({ success: true, message: 'Fetching solutions details successful', data });
    
        
        }
        else
        {
        const [data] = await pool.execute('select * from solution_demo ');
        res.json({ success: true, message: 'Fetching solutions details successful', data });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

// POST Solution (accepting empty fields)
exports.postSolution = async (req, res) => {
    try {
        const {
            solution_name = null,  // Default to null if not provided
            owner = null,
            solution_status = null,
            remark_text = null,
            version = null,
            health = null,
            u_status = null,
            channel = null,
            up_doc = null
        } = req.body;

        // Check if fields are undefined and set them to null
        const query = `
            INSERT INTO solution_demo (solution_name, owner, solution_status, remark_text, version, health, u_status, channel, up_doc)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;

        const [result] = await pool.execute(query, [
            solution_name, 
            owner, 
            solution_status, 
            remark_text, 
            version, 
            health, 
            u_status, 
            channel, 
            up_doc
        ]);
        const [r2]=await pool.execute(`INSERT INTO solReport (sol_id,url) VALUES (${result.insertId},'https://example.com')`);
        console.log(r2)
        res.json({ success: true, message: 'Solution added successfully', data: result,r2 });
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};



exports.putSolution = async (req, res) => {
    try {
        const id = req.query.id; // Extracting the id from the query parameters
        console.log(id);
        
        // Check if the solution exists
        const [solutionExists] = await pool.execute("SELECT * FROM solution_demo WHERE id = ?", [id]);
        if (solutionExists.length === 0) {
            return res.status(404).json({ success: false, message: 'Solution not found' });
        }

        // Define the fields and their new values from the request body
        const updates = {
            solution_name: req.body.solution_name,
            owner: req.body.owner,
            solution_status: req.body.solution_status,
            remark_text: req.body.remark_text,
            version: req.body.version,
            health: req.body.health,
            u_status: req.body.u_status,
            channel: req.body.channel,
            up_doc: req.body.up_doc
        };

        // Filter out the fields that are not provided (undefined)
        const setClause = [];
        const values = [];
        for (const [key, value] of Object.entries(updates)) {
            if (value !== undefined) {
                setClause.push(`${key} = ?`);
                values.push(value);
            }
        }

        if (setClause.length > 0) {
            // Add the id to the values array
            values.push(id);

            // Construct the dynamic UPDATE query
            const updateQuery = `UPDATE solution_demo SET ${setClause.join(', ')} WHERE id = ?;`;

            // Execute the query
            const [result] = await pool.execute(updateQuery, values);

            console.log(updateQuery);
            console.log(values);

            // Send a success response
            res.json({ success: true, message: 'Solution updated successfully', data: result });
        } else {
            // No fields to update
            res.status(400).json({ success: false, message: 'No fields provided for update' });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};


exports.deleteSolution = async (req, res) => {
    try {
        const  id = req.query.id;

        const query = 'DELETE FROM solution_demo WHERE id = ?';
        const [result] = await pool.execute(query, [id]);

        res.json({ success: true, message: 'Solution deleted successfully', data: result });
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};


