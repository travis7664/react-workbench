const express = require('express');
const connection = require('../config/sqlConnection');

const getEventsByMonth = async (req, res) => {
  try {
    const { month, year } = req.params;

    if (!month || !year) {
      return res.status(400).json({ error: 'Month and year are required' });
    }

    const monthInt = parseInt(month, 10);
    const yearInt = parseInt(year, 10);

    if (isNaN(monthInt) || isNaN(yearInt) || monthInt < 1 || monthInt > 12 || yearInt < 1000 || yearInt > 9999) {
      return res.status(400).json({ error: 'Invalid month or year' });
    }

    const sqlQuery = `
      SELECT * 
      FROM se_events 
      WHERE
       deleted = 0 and (
        (
          YEAR(demo_date) = ?
          AND MONTH(demo_date) <= ?
          AND (
            YEAR(demo_date) = ?
            AND MONTH(demo_date) >= ?
            OR YEAR(demo_date) > ?
          )
        )
        OR (
          YEAR(demo_date) < ?
          AND (
            YEAR(demo_date) = ?
            AND MONTH(demo_date) >= ?
            OR YEAR(demo_date) > ?
          )
        )
        )
      
    `;

    connection.query(sqlQuery, [
      yearInt, monthInt, yearInt, monthInt, yearInt,
      yearInt, yearInt, monthInt, yearInt
    ], (err, results) => {
      if (err) {
        console.error('Error querying database:', err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      const formatDate = (date) => {
        const parsedDate = new Date(date);
        if (isNaN(parsedDate)) {
          return null;
        }
        const year = parsedDate.getFullYear();
        const month = ('0' + (parsedDate.getMonth() + 1)).slice(-2);
        const day = ('0' + parsedDate.getDate()).slice(-2);
        return `${year}-${month}-${day}`;
      };

      const events = results.map(row => ({
        id :row.id,
        cust_name: row.cust_name,
        demo_date: row.demo_date,
        demo_end: row.demo_end,
        demo_type: row.demo_type,
        select_demos: row.select_demos,
        se_name: row.se_name,
        cust_partner: row.cust_partner,
        mycur_timezone: row.mycur_timezone,
        demo_desc: row.demo_desc,
        acc: row.acc
      }));

      res.json(events);
    });
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const getAllevents = async (req, res) => {
  try {
    const sqlQuery = `SELECT * FROM se_events  where deleted = 0`;

    connection.query(sqlQuery, (err, results) => {
      if (err) {
        console.error('Error querying database:', err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      const formatDate = (date) => {
        const parsedDate = new Date(date);
        if (isNaN(parsedDate)) {
          return null;
        }
        const year = parsedDate.getFullYear();
        const month = ('0' + (parsedDate.getMonth() + 1)).slice(-2);
        const day = ('0' + parsedDate.getDate()).slice(-2);
        return `${year}-${month}-${day}`;
      };

      const events = results.map(row => ({
        id :row.id,
        cust_name: row.cust_name,
        demo_date: row.demo_date,
        demo_end: row.demo_end,
        demo_type: row.demo_type,
        select_demos: row.select_demos,
        se_name: row.se_name,
        cust_partner: row.cust_partner,
        mycur_timezone: row.mycur_timezone,
        demo_desc: row.demo_desc,
        acc: row.acc
      }));

      res.json(events);
    });
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const addEvent = async (req, res) => {
  try {
    const {
      cust_name,
      demo_date,
      demo_end,
      demo_type,
      select_demos,
      se_name,
      cust_partner,
      mycur_timezone,
      demo_desc,
      acc
    } = req.body;

    if (!cust_name || !demo_date || !demo_end || !demo_type || !select_demos || !se_name || !cust_partner || !mycur_timezone || !demo_desc || !acc) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    const formatDate = (date) => {
      const parsedDate = new Date(date);
      if (isNaN(parsedDate)) {
        throw new Error('Invalid date format');
      }
      const year = parsedDate.getFullYear();
      const month = ('0' + (parsedDate.getMonth() + 1)).slice(-2);
      const day = ('0' + parsedDate.getDate()).slice(-2);
      const hours = ('0' + parsedDate.getHours()).slice(-2);
      const minutes = ('0' + parsedDate.getMinutes()).slice(-2);
      const seconds = ('0' + parsedDate.getSeconds()).slice(-2);
      return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    };

    const formattedDemoDate = formatDate(demo_date);

    const sqlQuery = `
      INSERT INTO se_events (
        cust_name,
        demo_date,
        demo_end,
        demo_type,
        select_demos,
        se_name,
        cust_partner,
        mycur_timezone,
        demo_desc,
        acc
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    connection.query(sqlQuery, [
      cust_name,
      formattedDemoDate,
      demo_end,
      demo_type,
      select_demos,
      se_name,
      cust_partner,
      mycur_timezone,
      demo_desc,
      acc
    ], (err, results) => {
      if (err) {
        console.error('Error inserting into database:', err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      res.status(201).json({ message: 'Event added successfully', eventId: results.insertId });
    });
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const updateEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      cust_name,
      demo_date,
      demo_end,
      demo_type,
      select_demos,
      se_name,
      cust_partner,
      mycur_timezone,
      demo_desc,
      acc
    } = req.body;

    if (!id || isNaN(parseInt(id))) {
      return res.status(400).json({ error: 'Invalid id' });
    }

    const formatDate = (date) => {
      const parsedDate = new Date(date);
      if (isNaN(parsedDate)) {
        throw new Error('Invalid date format');
      }
      const year = parsedDate.getFullYear();
      const month = ('0' + (parsedDate.getMonth() + 1)).slice(-2);
      const day = ('0' + parsedDate.getDate()).slice(-2);
      const hours = ('0' + parsedDate.getHours()).slice(-2);
      const minutes = ('0' + parsedDate.getMinutes()).slice(-2);
      const seconds = ('0' + parsedDate.getSeconds()).slice(-2);
      return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    };

    const formattedDemoDate = formatDate(demo_date);

    const sqlQuery = `
      UPDATE se_events
      SET
        cust_name = ?,
        demo_date = ?,
        demo_end = ?,
        demo_type = ?,
        select_demos = ?,
        se_name = ?,
        cust_partner = ?,
        mycur_timezone = ?,
        demo_desc = ?,
        acc = ?
      WHERE id = ?
    `;

    connection.query(sqlQuery, [
      cust_name,
      formattedDemoDate,
      demo_end,
      demo_type,
      select_demos,
      se_name,
      cust_partner,
      mycur_timezone,
      demo_desc,
      acc,
      id
    ], (err, results) => {
      if (err) {
        console.error('Error updating database:', err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      if (results.affectedRows === 0) {
        return res.status(404).json({ error: 'Event not found' });
      }

      res.json({ message: 'Event updated successfully' });
    });
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const softDeleteEvent = async (req, res) => {
  try {
    const { id } = req.params;

    if (!id || isNaN(parseInt(id))) {
      return res.status(400).json({ error: 'Invalid id' });
    }

    const sqlQuery = `
      UPDATE se_events
      SET deleted = 1
      WHERE id = ?
    `;

    connection.query(sqlQuery, [id], (err, results) => {
      if (err) {
        console.error('Error updating database:', err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      if (results.affectedRows === 0) {
        return res.status(404).json({ error: 'Event not found or already deleted' });
      }

      res.json({ message: 'Event deleted successfully' });
    });
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const getAllRemovedEvents = async (req, res) => {
  try {
    const sqlQuery = `SELECT * FROM se_events WHERE deleted = 1`;

    connection.query(sqlQuery, (err, results) => {
      if (err) {
        console.error('Error querying database:', err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      const formatDate = (date) => {
        const parsedDate = new Date(date);
        if (isNaN(parsedDate)) {
          return null;
        }
        const year = parsedDate.getFullYear();
        const month = ('0' + (parsedDate.getMonth() + 1)).slice(-2);
        const day = ('0' + parsedDate.getDate()).slice(-2);
        return `${year}-${month}-${day}`;
      };

      const events = results.map(row => ({
        cust_name: row.cust_name,
        demo_date: row.demo_date,
        demo_end: row.demo_end,
        demo_type: row.demo_type,
        select_demos: row.select_demos,
        se_name: row.se_name,
        cust_partner: row.cust_partner,
        mycur_timezone: row.mycur_timezone,
        demo_desc: row.demo_desc,
        acc: row.acc
      }));

      res.json(events);
    });
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const getRemovedEventsByMonth = async (req, res) => {
  try {
    const { month, year } = req.params;

    if (!month || !year) {
      return res.status(400).json({ error: 'Month and year are required' });
    }

    const monthInt = parseInt(month, 10);
    const yearInt = parseInt(year, 10);

    if (isNaN(monthInt) || isNaN(yearInt) || monthInt < 1 || monthInt > 12 || yearInt < 1000 || yearInt > 9999) {
      return res.status(400).json({ error: 'Invalid month or year' });
    }

    const sqlQuery = `
      SELECT * 
      FROM se_events 
      WHERE deleted = 1
      AND (
        (
          YEAR(demo_date) = ?
          AND MONTH(demo_date) = ?
        )
        OR (
          YEAR(demo_end) = ?
          AND MONTH(demo_end) = ?
        )
      )
    `;

    connection.query(sqlQuery, [yearInt, monthInt, yearInt, monthInt], (err, results) => {
      if (err) {
        console.error('Error querying database:', err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      const formatDate = (date) => {
        const parsedDate = new Date(date);
        if (isNaN(parsedDate)) {
          return null;
        }
        const year = parsedDate.getFullYear();
        const month = ('0' + (parsedDate.getMonth() + 1)).slice(-2);
        const day = ('0' + parsedDate.getDate()).slice(-2);
        return `${year}-${month}-${day}`;
      };

      const events = results.map(row => ({
        cust_name: row.cust_name,
        demo_date: row.demo_date,
        demo_end: row.demo_end,
        demo_type: row.demo_type,
        select_demos: row.select_demos,
        se_name: row.se_name,
        cust_partner: row.cust_partner,
        mycur_timezone: row.mycur_timezone,
        demo_desc: row.demo_desc,
        acc: row.acc
      }));

      res.json(events);
    });
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};



const restoreEvent = async (req, res) => {
  try {
    const { id } = req.params;

    if (!id || isNaN(parseInt(id))) {
      return res.status(400).json({ error: 'Invalid id' });
    }

    const sqlQuery = `
      UPDATE se_events
      SET deleted = 0
      WHERE id = ?
    `;

    connection.query(sqlQuery, [id], (err, results) => {
      if (err) {
        console.error('Error updating database:', err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      if (results.affectedRows === 0) {
        return res.status(404).json({ error: 'Event not found or already restored' });
      }

      res.json({ message: 'Event restored successfully' });
    });
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const hardDeleteEvent = async (req, res) => {
  try {
    const { id } = req.params;

    if (!id || isNaN(parseInt(id))) {
      return res.status(400).json({ error: 'Invalid id' });
    }

    const sqlQuery = `
      DELETE FROM se_events
      WHERE id = ?
    `;

    connection.query(sqlQuery, [id], (err, results) => {
      if (err) {
        console.error('Error deleting from database:', err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      if (results.affectedRows === 0) {
        return res.status(404).json({ error: 'Event not found' });
      }

      res.json({ message: 'Event permanently deleted successfully' });
    });
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

module.exports = {
  getEventsByMonth,
  getAllevents,
  addEvent,
  updateEvent,
  softDeleteEvent,
  getAllRemovedEvents,
  getRemovedEventsByMonth,
  restoreEvent,
  hardDeleteEvent
};






