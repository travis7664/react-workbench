
const connection = require('../config/sqlConnection');

const getTotalDemosCountWithFilters = (req, res) => {
  try {
    const {
      client_name,
      project_name,
      current_status,
      owner,
      user_name
    } = req.query;

    let sqlQuery = 'SELECT COUNT(*) AS total FROM demos d';
    const queryParams = [];

    if (user_name) {
      sqlQuery += `
        LEFT JOIN users_projects up ON d.did = up.did
        LEFT JOIN users u ON up.uid = u.uid`;
    }

    const whereClauses = [];
    if (client_name) {
      whereClauses.push('d.client_name LIKE ?');
      queryParams.push(`%${client_name}%`);
    }
    if (project_name) {
      whereClauses.push('d.project_name LIKE ?');
      queryParams.push(`%${project_name}%`);
    }
    if (current_status) {
      whereClauses.push('d.current_status = ?');
      queryParams.push(current_status);
    }
    if (owner) {
      whereClauses.push('d.owner LIKE ?');
      queryParams.push(`%${owner}%`);
    }
    if (user_name) {
      whereClauses.push('u.name LIKE ?');
      queryParams.push(`%${user_name}%`);
    }

    if (whereClauses.length > 0) {
      sqlQuery += ' WHERE ' + whereClauses.join(' AND ');
    }

    connection.query(sqlQuery, queryParams, (err, results) => {
      if (err) {
        console.error('Error querying database:', err);
        res.status(500).json({ error: 'Internal Server Error' });
        return;
      }

      res.json({ total: results[0].total });
    });
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

module.exports = {
  getTotalDemosCountWithFilters
};
