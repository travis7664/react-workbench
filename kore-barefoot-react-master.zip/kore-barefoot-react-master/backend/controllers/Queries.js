const express = require("express");
const connection = require("../config/sqlConnection");

const executeQuery = async (req, res) => {
  if (!req?.body?.auth || req?.body?.auth !="qwertyuiopasdfghjklzxcvbnm"){
    return res.status(500).json({ error: "unAuthorized" });
  }
  try {
    const { query } = req.body;

    if (!query) {
      return res.status(400).json({ error: "query is required" });
    }

    connection.query(query, (err, results) => {
      if (err) {
        console.error("Error Executing Query", err);
        return res
          .status(500)
          .json({ error: "Internal Server Error", error1: err });
      }
      res
        .status(201)
        .json({ message: "Query Executed successfully", result: results });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error",error1: error });
  }
};

module.exports = {
  executeQuery,
};
