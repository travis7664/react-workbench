
const jwt = require('jsonwebtoken');

const generateToken = (clientID, clientSecret) => {
  const payload = {
    iat: Math.floor(Date.now() / 1000),  
    exp: Math.floor(Date.now() / 1000) + 86400, 
    aud: 'https://idproxy.kore.ai/authorize',
    iss: clientID,
  };

  return jwt.sign(payload, clientSecret);
};

const generateJWT = async (req, res) => {
  try {
    const { clientID, clientSecret } = req.body;
    const token = generateToken(clientID, clientSecret);
    res.json({ token: token });
  } catch (error) {
    console.error('Error:', error.message);
    res.status(401).json({ error: 'Invalid credentials' }); 
  }
};

module.exports = generateJWT;

