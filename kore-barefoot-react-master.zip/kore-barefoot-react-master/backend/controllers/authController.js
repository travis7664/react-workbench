const jwtHelper = require("../helpers/jwtHelper");
const mysql = require("mysql2/promise");
const dbConfig = require("../config/dbConfig");

function createPool(config) {
  return mysql.createPool(config);
}

const pool = createPool(dbConfig);

exports.googleCallback = async (req, res) => {
  try {
    let email = req.user._json.email;
    console.log(email);

    const [rows] = await pool.execute(
      "SELECT id FROM user WHERE email = ? AND is_verified = 1",
      [email]
    );
    if (rows.length === 1) {
      console.log(rows[0].id);
      const jwtPayload = { email: email };
      const token = jwtHelper.generateToken(jwtPayload);
      let userinfo = req.user._json;
      res.cookie("token", token, {
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000,
      }); // 1 day
      //res.redirect('/dashboard');
      const [roles] = await pool.execute(
        "SELECT name FROM role WHERE rid IN (SELECT rid FROM users_roles WHERE uid = (SELECT uid FROM users WHERE init = ?));",
        [email]
      );
      const [uid] = await pool.execute(
        "SELECT uid FROM users WHERE init = ? ;",
        [email]
      );
      await pool.execute("UPDATE user SET last_login = now() WHERE id= ?", [
        rows[0].id,
      ]);
      await pool.execute("UPDATE user SET token = ? WHERE id= ?", [
        token,
        rows[0].id,
      ]);

      const roleNames = roles.map((role) => role.name);
      console.log(roleNames);

      const user_id = await pool.execute(
        "SELECT uid FROM users WHERE init = ?;",
        [email]
      );
      const [exist] = await pool.execute(
        "SELECT * from employee WHERE UID = ?",
        [user_id[0][0].uid]
      );
      let profile_img = "";
      if (exist[0]) {
        profile_img = exist[0].profile_img ? exist[0].profile_img : "";
      }
      if (user_id) {
        if (exist.length == 0)
          await pool.execute("INSERT INTO employee (UID, Name) VALUES (?, ?)", [
            user_id[0][0].uid,
            userinfo.name,
          ]);
      }
      userinfo.uid = uid[0]?.uid;
      res.json({
        success: true,
        message: "Authentication successful",
        token,
        roleNames,
        userinfo,
        profile_img,
      });
      // res.redirect('http://localhost:3000/demo');

      // {
      // "Success":true,
      // "message":"Authenticationsuccessful",
      // "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImtyaXNobmEua29wcHVsYUBrb3JlLmNvbSIsImlhdCI6MTcxNzQwODkzOSwiZXhwIjoxNzE3NDEyNTM5fQ.1gl0bwWRlrp5Lz26oSaLBkrwc9PUNPkd2nngx2pwDYU",
      // "roleNames":["Developer","Administrator"],
      // "Userinfo":
      // {
      // "sub":"103678714478572698739",
      // "name":"Krishna Koppula",
      // "given_name":"Krishna",
      // "family_name":"Koppula ",
      // "picture":"https://lh3.googleusercontent.com/a/ACg8ocJhTABeESEG2tLgzwtrovueSLZvA8D2I7_2OpYgdwrdg8qZwg=s96-c",
      // "email":"barefootdemo@kore.com",
      // "Email_verified":true,
      // "locale":"en","hd":"kore.com"
      // }
      // }
    } else {
      // res.redirect('/');
      res.status(201).json({
        success: true,
        registered: true,
        message: "Registration successful Wait for the Admin Approval",
        email: req.user._json.email,
      });
    }
  } catch (error) {
    console.log(`An error occurred: ${error}`);
    res
      .status(500)
      .json({ success: false, message: "Internal Server Error", error: error });
    //res.redirect('/');
  }
};

// Logout Handler
// exports.logout = (req, res) => {
//     res.clearCookie('token');
//     req.logout((err) => {git status
//         if (err) {
//             return next(err);
//         }
//         res.redirect('/');
//     });
// };
exports.logout = (req, res, next) => {
  req.logout((err) => {
    if (err) {
      return next(err);
    }

    req.session.destroy((err) => {
      if (err) {
        return next(err);
      }

      res.clearCookie("connect.sid"); // clear session cookie
      res.clearCookie("token"); // clear session
      res.json({ success: true, message: "Log Out Successful" });
    });
  });
};

exports.addUser = async (req, res) => {
  try {
    const mail = req.body.mail;
    const name = req.body.name;
    const init = req.body.mail;

    // Check if user exists in the users table
    const [exist] = await pool.execute("SELECT * from users WHERE mail = ?", [
      mail,
    ]);

    if (exist.length === 0) {
      // Insert into the users table
      var [insertion] = await pool.execute(
        "INSERT INTO users (name, mail, isactive, init) VALUES (?, ?, '1', ?);",
        [name, mail, init]
      );
    }

    // Check if user exists in the user table
    const [existance] = await pool.execute(
      "SELECT * from user WHERE email = ?",
      [mail]
    );

    if (existance.length === 0) {
      // Insert into the user table
      const [result] = await pool.execute(
        "INSERT INTO user (provider, firstname, email, is_verified) VALUES ('admin', ?, ?, '1');",
        [name, mail]
      );

      return res.json({
        success: true,
        message: "User added successfully",
        result,
        insertion,
      });
    } else {
      const [Userstatus] = await pool.execute(
        "SELECT * FROM user WHERE email= ? and is_verified=1",
        [mail]
      );
      if (Userstatus.length === 0) {
        const [result] = await pool.execute(
          "update user set is_verfied=1 where email=?",
          [mail]
        );
        return res.json({
          success: true,
          message: "User verified successfully",
          result,
        });
      } else {
        return res.json({
          success: true,
          message: "User already verified ",
          Userstatus,
        });
      }
    }

    // res.json({ success: false, message: "User already exists in the database" });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
};
