const express = require("express");
const connection = require("../config/sqlConnection");

const getUserProjectDetails = async (req, res) => {
  try {
    const { uid } = req.params;

    const query = `
      SELECT 
        up.did, 
        ur.name AS user_name,  -- Correctly retrieve the user's name
        d.client_name,
        d.internal_project_name, 
        d.project_name, 
        d.current_status,
        d.project_img,
        r.name AS role_name
      FROM 
        users_projects up
      LEFT JOIN 
        demos d ON up.did = d.did
      LEFT JOIN 
        users ur ON up.uid = ur.uid  
      LEFT JOIN 
        role r ON up.rid = r.rid
      WHERE 
        up.uid = ?
      ORDER BY 
        d.did desc;
    `;

    connection.query(query, [uid], (err, results) => {
      if (err) {
        console.error("Error querying database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.length === 0) {
        return res
          .status(201)
          .json({ error: "No project details found for the user" });
      }

      const user_name = results[0].user_name;

      const projects = results.map((row) => ({
        did: row.did,
        client_name: row.client_name,
        internal_project_name: row.internal_project_name,
        project_name: row.project_name,
        current_status: row.current_status,
        role_name: row.role_name,
        project_img:row.project_img,
      }));

      res.json({ uid, user_name, projects });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

module.exports = {
  getUserProjectDetails,
};
