const mysql = require('mysql2/promise');
const dbConfig = require('../config/dbConfig');

function createPool(config) {
    return mysql.createPool(config);
}

const pool = createPool(dbConfig);
exports.reserveDemo=async(req,res)=>{
    try{
         const sename=req.body.sename || null;
         const demoname=req.body.demoname || null;
         const datelock=req.body.datelock || null;
         const daterelease=req.body.daterelease || null;
         const comment=req.body.comment || null;
         const parent_id=req.body.parent_id || null;
         const [exist]=await pool.execute("select * from reserve_demos where id=?",[parent_id])
         if(exist.length){
        const [reserve]=await pool.execute(
            "insert into book_demos ( sename, demoname, datelock, daterelease, comment, parent_id) values (?,?,?,?,?,?);",[sename, demoname, datelock, daterelease, comment, parent_id]
        );
        res.json({success:true,message:'added to reserve demos successfully',reserve});
        }
        else{
            res.json({success:true,message:'No respective reserve demo exist with the concerned parent_id'});

        }

    }
    catch(error){
        console.log(error)
        res.status(500).json({success:false,message:'Internal server error'}); 
    }
}
exports.release=async(req,res)=>{
    try{
        const id=req.query.id;
        const[release]=await pool.execute("delete from book_demos where id=?",[id]);
        res.json({success:true,message:'deleted from book demos(released the demo successfully)',release})
    }
    catch(error){ 
        console.log(error)
        res.status(500).json({success:false,message:'Internal server error'}); 
    }
}