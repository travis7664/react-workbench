const connection = require("../config/sqlConnection");

function processDemoDetails(row) {
  const users = row.user_details
    ? row.user_details.split(";").map((detail) => {
        const [
          uid,
          user_name,
          rid,
          role_name,
          contributed_percentage,
          user_project_status,
        ] = detail.split(":");

        return {
          uid: Number(uid),
          user_name,
          role: {
            rid: Number(rid),
            name: role_name,
          },
          contributed_percentage: contributed_percentage
            ? Number(contributed_percentage)
            : null,
          user_project_status,
        };
      })
    : [];

  const features = row.feature_details
    ? row.feature_details.split(";").map((detail) => {
        const [feature_id, category_name, feature_name] = detail.split(":");
        return {
          feature_id: Number(feature_id),
          category_name,
          feature_name,
        };
      })
    : [];

  return {
    did: row.did,
    entity_id: row.entity_id,
    project_name: row.project_name,
    internal_project_name: row.internal_project_name,
    client_name: row.client_name,
    functional_theme: row.functional_theme,
    project_type: row.project_type,
    project_desc: row.project_desc,
    lp_project_desc: row.lp_project_desc,
    client_domains: row.client_domains,
    team_type: row.team_type,
    owner: row.owner,
    probability_percentage: row.probability_percentage,
    sfdc_link: row.sfdc_link,
    sales_closure_date: row.sales_closure_date,
    native: row.native,
    mobweb: row.mobweb,
    mobspa: row.mobspa,
    tablets: row.tablets,
    tabletweb: row.tabletweb,
    tabletspa: row.tabletspa,
    desktop: row.desktop,
    hybrid: row.hybrid,
    wrapper: row.wrapper,
    mixedmode: row.mixedmode,
    wearable: row.wearable,
    orientation: row.orientation,
    other_channel: row.other_channel,
    plug_ins: row.plug_ins,
    deliverables: row.deliverables,
    project_tags: row.project_tags,
    request_received: row.request_received,
    start_date: row.start_date,
    estimated_end_date: row.estimated_end_date,
    estimated_project_duration: row.estimated_project_duration,
    current_status: row.current_status,
    project_closure: row.project_closure,
    actual_end_date: row.actual_end_date,
    visualizer_passcode: row.visualizer_passcode,
    visualizer_desc: row.visualizer_desc,
    visualizer_version: row.visualizer_version,
    project_criticality: row.project_criticality,
    demo_end_feedback: row.demo_end_feedback,
    feedback: row.feedback,
    reason: row.reason,
    current_health: row.current_health,
    current_complexity: row.current_complexity,
    percentage_completed: row.percentage_completed,
    base_project: row.base_project,
    bot_tenant: row.bot_tenant,
    bot_env: row.bot_env,
    jira_link: row.jira_link,
    milestones_schedules: row.milestones_schedules,
    ui_reviewer: row.ui_reviewer,
    code_review: row.code_review,
    issue_logging: row.issue_logging,
    video_labelling: row.video_labelling,
    tech_lead: row.tech_lead,
    developers: row.developers,
    jiraLink: row.jiraLink,
    designers: row.designers,
    qa: row.qa,
    lp_user_name: row.lp_user_name,
    lp_password: row.lp_password,
    lp_demovideo_client_logo: row.lp_demovideo_client_logo,
    bot_zip_files: row.bot_zip_files,
    automation_file: row.automation_file,
    client_id: row.client_id,
    client_secret: row.client_secret,
    automation_region: row.automation_region,
    automation_project: row.automation_project,
    automation_total_task: row.automation_total_task,
    pass: row.pass,
    failed: row.failed,
    failed_task_name: row.failed_task_name,
    automation_script: row.automation_script,
    lp_demovideo_url: row.lp_demovideo_url,
    standup_time: row.standup_time,
    special_character_check: row.special_character_check,
    created_user: row.created_user,
    created_date: row.created_date,
    updated_user: row.updated_user,
    updated_date: row.updated_date,
    waiting_for_feedback_status_update_date:
      row.waiting_for_feedback_status_update_date,
    waiting_for_feedback_status_update_user:
      row.waiting_for_feedback_status_update_user,
    completed_status_update_date: row.completed_status_update_date,
    completed_status_update_user: row.completed_status_update_user,
    demo_search: row.demo_search,
    demo_popular: row.demo_popular,
    showcase_demo_status: row.showcase_demo_status,
    showcase_demo_comment: row.showcase_demo_comment,
    demo_label: row.demo_label,
    demo_care: row.demo_care,
    demo_Channels_Json: row.demo_Channels_Json,
    demo_Features_Json: row.demo_Features_Json,
    bot_training: row.bot_training,
    customer_link: row.customer_link,
    users: users,
    features: features,
  };
}

async function getTotalDemosCount(filterClauses, filterValues) {
  return new Promise((resolve, reject) => {
    const countQuery = `SELECT COUNT(DISTINCT d.did) AS total
                        FROM demos d
                        LEFT JOIN users_projects up ON d.did = up.did
                        LEFT JOIN users u ON up.uid = u.uid
                        ${filterClauses}`;
    connection.query(countQuery, filterValues, (err, results) => {
      if (err) {
        reject(err);
      } else {
        resolve(results[0].total);
      }
    });
  });
}

function buildFiltersAndSort(query) {
  const filterClauses = [];
  const filterValues = [];

  if (query.client_name) {
    filterClauses.push("d.client_name LIKE ?");
    filterValues.push(`%${query.client_name}%`);
  }
  if (query.project_name) {
    filterClauses.push("d.project_name LIKE ?");
    filterValues.push(`%${query.project_name}%`);
  }
  if (query.current_status) {
    filterClauses.push("d.current_status = ?");
    filterValues.push(query.current_status);
  }
  if (query.owner) {
    filterClauses.push("d.owner LIKE ?");
    filterValues.push(`%${query.owner}%`);
  }
  if (query.user_name) {
    filterClauses.push("u.name LIKE ?");
    filterValues.push(`%${query.user_name}%`); 
  }

  if (query.project_tags) {
    filterClauses.push("d.project_tags LIKE ?");
    filterValues.push(`%${query.project_tags}%`); 
  }

  const sortClause = query.sortBy
    ? `${query.sortBy} ${query.sortOrder === "desc" ? "DESC" : "ASC"}`
    : "d.did DESC";

  const whereClause =
    filterClauses.length > 0 ? `WHERE ${filterClauses.join(" AND ")}` : "";

  return { filterClauses: whereClause, filterValues, sortClause };
}

module.exports = {
  getDemos: async (req, res) => {
    try {
      const limit = parseInt(req.query.limit) || 10;
      const offset = parseInt(req.query.offset) || 0;

      const { filterClauses, filterValues, sortClause } = buildFiltersAndSort(
        req.query
      );

      const sqlQuery = `
      SELECT
        d.did,
        d.entity_id,
        d.project_name,
        d.internal_project_name,
        d.client_name,
        d.functional_theme,
        d.project_type,
        d.project_desc,
        d.lp_project_desc,
        d.client_domains,
        d.team_type,
        d.owner,
        d.probability_percentage,
        d.sfdc_link,
        d.sales_closure_date,
        d.native,
        d.mobweb,
        d.mobspa,
        d.tablets,
        d.tabletweb,
        d.tabletspa,
        d.desktop,
        d.hybrid,
        d.wrapper,
        d.mixedmode,
        d.wearable,
        d.orientation,
        d.other_channel,
        d.plug_ins,
        d.deliverables,
        d.project_tags,
        d.request_received,
        d.start_date,
        d.estimated_end_date,
        d.estimated_project_duration,
        d.current_status,
        d.project_closure,
        d.actual_end_date,
        d.visualizer_passcode,
        d.visualizer_desc,
        d.visualizer_version,
        d.project_criticality,
        d.demo_end_feedback,
        d.feedback,
        d.reason,
        d.current_health,
        d.current_complexity,
        d.percentage_completed,
        d.base_project,
        d.bot_tenant,
        d.bot_env,
        d.jira_link,
        d.milestones_schedules,
        d.ui_reviewer,
        d.code_review,
        d.issue_logging,
        d.video_labelling,
        d.tech_lead,
        d.developers,
        d.jiraLink,
        d.designers,
        d.qa,
        d.lp_user_name,
        d.lp_password,
        d.lp_demovideo_client_logo,
        d.bot_zip_files,
        d.automation_file,
        d.client_id,
        d.client_secret,
        d.automation_region,
        d.automation_project,
        d.automation_total_task,
        d.pass,
        d.failed,
        d.failed_task_name,
        d.automation_script,
        d.lp_demovideo_url,
        d.standup_time,
        d.special_character_check,
        d.created_user,
        d.created_date,
        d.updated_user,
        d.updated_date,
        d.waiting_for_feedback_status_update_date,
        d.waiting_for_feedback_status_update_user,
        d.completed_status_update_date,
        d.completed_status_update_user,
        d.demo_search,
        d.demo_popular,
        d.showcase_demo_status,
        d.showcase_demo_comment,
        d.demo_label,
        d.demo_care,
d.demo_Channels_Json,
     d.demo_Features_Json,
     d.bot_training,
        d.customer_link,
        GROUP_CONCAT(
          DISTINCT CONCAT(
            u.uid, ':', u.name, ':', r.rid, ':', r.name, ':', 
            IFNULL(upd.contributed_percentage, ''), ':', IFNULL(upd.status, '')
          ) SEPARATOR ';'
        ) AS user_details,
        GROUP_CONCAT(
          DISTINCT CONCAT(
            sf.id, ':', sf.category_name, ':', sf.feature_name
          ) SEPARATOR ';'
        ) AS feature_details
      FROM
        demos d
      LEFT JOIN
        users_projects up ON d.did = up.did
      LEFT JOIN
        users u ON up.uid = u.uid
      LEFT JOIN
        role r ON up.rid = r.rid
      LEFT JOIN
        users_projects_details upd ON up.uid = upd.uid AND up.did = upd.pid
      LEFT JOIN
        proj_spec_features psf ON d.did = psf.demo_id
      LEFT JOIN
        special_features sf ON psf.feature_id = sf.id
      ${filterClauses}
      GROUP BY
        d.did
      ORDER BY 
        ${sortClause}
      LIMIT ? OFFSET ?;
      `;

      connection.query(
        sqlQuery,
        [...filterValues, limit, offset],
        async (err, results) => {
          if (err) {
            console.error("Error querying database:", err);
            res.status(500).json({ error: "Internal Server Error" });
            return;
          }

          const demos = results.map(processDemoDetails);
          try {
            const totalDemos = await getTotalDemosCount(
              filterClauses,
              filterValues
            );
            res.json({
              demos,
              pagination: {
                limit,
                offset,
                total: totalDemos,
              },
            });
          } catch (countError) {
            console.error("Error querying total demos count:", countError);
            res.status(500).json({ error: "Internal Server Error" });
          }
        }
      );
    } catch (error) {
      console.error("Error:", error.message);
      res.status(500).json({ error: "Internal Server Error" });
    }
  },

};
