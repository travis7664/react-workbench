const sendMail = require("../helpers/sendMail");
const mysql = require("mysql2/promise");
const dbConfig = require("../config/dbConfig");

// Database setup
function createPool(config) {
  return mysql.createPool(config);
}

const pool = createPool(dbConfig);

exports.sendKickoff = async (req, res) => {
  try {
    const demoid = req.query.id;
    console.log(demoid);
    const [demoExists] = await pool.execute(
      "select * from demos where did=?;",
      [demoid]
    );
    console.log(demoExists.length);

    if (demoExists.length) {
      const [project] = await pool.execute(
        "SELECT project_name FROM demos WHERE did = ?;",
        [demoid]
      );
      const [BAMails] = await pool.execute(
        "SELECT mail FROM users where uid IN(SELECT uid FROM users_projects where did=? and rid=3);",
        [demoid]
      );
      const [Lead] = await pool.execute(
        "SELECT name FROM users where uid IN(SELECT uid FROM users_projects where did=? and rid=6);",
        [demoid]
      );
      const [Dev] = await pool.execute(
        "SELECT name FROM users where uid IN(SELECT uid FROM users_projects where did=? and rid=5);",
        [demoid]
      );
      const [BA] = await pool.execute(
        "SELECT name FROM users where uid IN(SELECT uid FROM users_projects where did=? and rid=3);",
        [demoid]
      );

      const Manager = "Pranay Upadhyay";

      // Convert arrays of objects to comma-separated strings of names
      const leadNames = Lead.map((person) => person.name).join(", ");
      const devNames = Dev.map((person) => person.name).join(", ");
      const baNames = BA.map((person) => person.name).join(", ");

      let mailSubject = `Project Kickoff - ${project[0].project_name}`;
      let content = `<div style="border: 1px solid #ccc; padding: 20px; max-width: 600px; margin: auto;">
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcStkqqzpDMT-lMfT9KyFHVwQ85Jsc6b-kI2kw&s" alt="Kore.ai" style="width: 150px; height: 90px; float: right;">
        <br><br><br>
        <p>Hi ${Manager},</p>
        <p>Thanks for your time to go through the requirements. Following are the team members assigned to this project:</p>
        <p><strong>Manager:</strong> ${Manager}<br>
        <strong>Lead:</strong> ${leadNames}<br>
        <strong>Developer:</strong> ${devNames}<br>
        <strong>BA:</strong> ${baNames}<br>
        <strong>Escalation Point:</strong> Curtis Swartzentruber</p>
        <p>Please note that you will be receiving a daily status email about this project through our Barefoot system and that email will provide you deeper details on each aspect of the project such as status of conversational flow, development progress, etc. You may also login into <a href="https://demo.kore.ai/barefoot/demo-tracker">https://demo.kore.ai/barefoot/demo-tracker</a> to check the status/progress of this project. Please feel free to reach out to me in case you are unclear of any of the details in the Barefoot website or the status update email.</p>
        <p>Pranay and ${baNames} will be your point of contact for all the communications.</p>
        <p>Below is our understanding of the project:-</p>
        <p>We need following clarifications on this project:-</p>
        <p><strong>Risks:</strong> Given the crunched timelines, the number of channels to be delivered and the known issues with Platform, we will have to compromise on quality and some other factors. It is strongly recommended if we could buy some more time from the prospect on this.</p>
      </div>`;

      //   const BAMailList = BAMails.map(mail => mail.mail).join(', ');
      //   BAMailList+="pranay.upadhyay@kore.com"
      //   console.log(BAMailList)
      //  // const response = await sendMail(BAMailList, mailSubject, content);
      let BAMailList = BAMails.map((mail) => mail.mail).join(", ");
      BAMailList = BAMailList + ",pranay.upadhyay@kore.com";
      console.log(BAMailList);
      //BAMailList="barefootdemo@kore.com, koppula.2076@gmail.com,lmkrishna2712@gmail.com"
      // console.log(BAMailList);
      const response = await sendMail(BAMailList, mailSubject, content);

      res.json({
        success: true,
        message: "ba mails",
        BAMails,
        Lead,
        Dev,
        BA,
        response,
      });
    } else {
      res.json({ success: true, message: "No demo exists" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};

exports.closureMail = async (req, res) => {
  try {
    const demoid = req.query.id;
    console.log(demoid);
    const [demoExists] = await pool.execute(
      "select * from demos where did=?;",
      [demoid]
    );
    console.log(demoExists.length);

    if (demoExists.length) {
      const [project] = await pool.execute(
        "SELECT project_name FROM demos WHERE did = ?;",
        [demoid]
      );
      const [BAMails] = await pool.execute(
        "SELECT mail FROM users where uid IN(SELECT uid FROM users_projects where did=? and rid=3);",
        [demoid]
      );

      const [Lead] = await pool.execute(
        "SELECT name FROM users where uid IN(SELECT uid FROM users_projects where did=? and rid=6);",
        [demoid]
      );
      const [Dev] = await pool.execute(
        "SELECT name FROM users where uid IN(SELECT uid FROM users_projects where did=? and rid=5);",
        [demoid]
      );
      const [BA] = await pool.execute(
        "SELECT name FROM users where uid IN(SELECT uid FROM users_projects where did=? and rid=3);",
        [demoid]
      );
      const [SE] = await pool.execute(
        "SELECT name FROM users where uid IN(SELECT uid FROM users_projects where did=? and rid=13);",
        [demoid]
      );
      if (!SE) {
        SE = [{ name: "Curtis" }];
      }

      const Manager = "Pranay Upadhyay";

      // Convert arrays of objects to comma-separated strings of names
      const leadNames = Lead.map((person) => person.name).join(", ");
      const devNames = Dev.map((person) => person.name).join(", ");
      const baNames = BA.map((person) => person.name).join(", ");

      let mailSubject = `Project Delivery Confirmation and Details - ${project[0].project_name}`;
      let content = `<div style="border: 1px solid #ccc; padding: 20px; max-width: 600px; margin: auto;">
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcStkqqzpDMT-lMfT9KyFHVwQ85Jsc6b-kI2kw&s" alt="Kore.ai" style="width: 150px; height: 90px; float: right;">
        <br><br><br>
        <p>Dear ${SE[0].name},</p>
               
        <p>Greetings from the Demo Team !!</p>
        <p>It was a pleasure working with you. Your collaboration and clear communication made this project a success, and we appreciate the support and insights you provided throughout the process.</p>
       
        <p>We are marking the demo <b>${project[0].project_name}</b> as complete as we have delivered the requested scope. Please share your feedback on team performance - What you liked about the team, what can be improved? :</p>
        <p>As you know, team bandwidth and infrastructure like . is shared between multiple demos. We will keep it up and running for next 2 to 3 days after that human resources as well as software infrastructure will get assigned to different demos. Please reach out to <b>${BA[0].name}</b> for any support in archival. If you want to hold the demo environment and development team a little longer please write to <b>Curtis</b>. To help you share demo deliverables with ${project[0].project_name}, We have created customer landing page, below are the details:</p>
        <p>URL:</P
        <p>Thank you for your continued trust and support.</p>
        <p>This is a system generated email.</p>
      </div>`;

      BAMailList = BAMailList;
      console.log(BAMailList);

      // BAMailList="dinesh.boda@kore.com, koppula.2076@gmail.com"
      console.log(BAMailList);
      const response = await sendMail(BAMailList, mailSubject, content);

      res.json({
        success: true,
        message: "ba mails",
        BAMails,
        Lead,
        Dev,
        BA,
        response,
      });
    } else {
      res.json({ success: true, message: "No demo exists" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};

exports.customMail = async (req, res) => {
  try {
    const mailSubject = req.body.mailSubject;
    const content = req.body.content;
    const Mails = req.body.Mails;
    const response = await sendMail(Mails, mailSubject, content);

    res.json({
      success: true,
      message: "custom mail sent successfully",
      mailSubject,
      Mails,
      content,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};

exports.statusMail = async (req, res) => {
  try {
    // Fetch status data from the database
    const demoid = req.query.id;
    console.log(demoid);
    const [BAMails] = await pool.execute(
      "SELECT mail FROM users where uid IN(SELECT uid FROM users_projects where did=? );",
      [demoid]
    );
    const today = new Date();
    const formattedDate = today.toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "2-digit",
      year: "2-digit",
    });
    console.log(formattedDate);
    console.log(
      "SELECT current_status FROM statuslog WHERE id =" +
        demoid +
        " and created=" +
        formattedDate
    );

    const [rows] = await pool.execute(
      `SELECT current_status FROM statuslog WHERE entity_id =? and created=?;`,
      [demoid, formattedDate.toString()]
    );

    const [perc] = await pool.execute(
      `SELECT perc_completed FROM statuslog WHERE entity_id = ? and created=?;`,
      [demoid, formattedDate]
    );

    const [proj_internal] = await pool.execute(
      `SELECT internal_project_name FROM demos WHERE did = ?;`,
      [demoid]
    );

    const [project] = await pool.execute(
      "SELECT project_name FROM demos WHERE did = ?;",
      [demoid]
    );

    console.log(rows);

    // Ensure `statusData` has actual newline characters, not literal `\\n`
    let statusData = rows[0]?.current_status?.replace(/\\n/g, "\n");

    if (!statusData) {
      return res
        .status(404)
        .json({ success: false, message: "Status data not found" });
    }

    // Split the status data by sections
    const statusSections = statusData
      .split("-d-")
      .map((section) => section.trim())
      .filter((section) => section.length > 0);

    console.log(statusSections); // Check the result of splitting

    // Define color codes for each section
    const statusColorCodes = {
      0: "green", // COMPLETED
      1: "blue", // IN-PROGRESS
      2: "red", // PENDING
      3: "black", // FUTURE
    };

    // Build the status content
    let statusContent = "";
    statusSections.forEach((section, index) => {
      if(section !== 'undefined'){
      const color = statusColorCodes[index];
      const lines = section
        .split("\n")
        .map((line) => line.trim())
        .filter((line) => line.length > 0);
      lines.forEach((line) => {
        statusContent += `<li>${line} <span style="color: ${color}; font-size: 20px;">●</span></li>`;
      });
    }
    });

    if (!statusContent) {
      return res
        .status(404)
        .json({ success: false, message: "No valid status data found" });
    }

    // Fetch issues dynamically from the database
    const [issues] = await pool.execute(
      `SELECT digite_id, digite_url, issue_description, issue_status, assigned_to FROM proj_status_bugs WHERE project_id = ?`,
      [demoid]
    );

    let issueRows = "";
    issues.forEach((issue) => {
      issueRows += `
        <tr>
          <td style="border: 1px solid #000; padding: 8px; text-align: left;">${issue.digite_id}</td>
          <td style="border: 1px solid #000; padding: 8px; text-align: left;">
            <a href="${issue.digite_url}" style="color: blue;">${issue.digite_url}</a>
          </td>
          <td style="border: 1px solid #000; padding: 8px; text-align: left;">${issue.issue_description}</td>
          <td style="border: 1px solid #000; padding: 8px; text-align: left;">${issue.issue_status}</td>
          <td style="border: 1px solid #000; padding: 8px; text-align: left;">${issue.assigned_to}</td>
        </tr>
      `;
    });

    // If no issues found, add a default row
    if (!issueRows) {
      issueRows = `
        <tr>
          <td colspan="5" style="border: 1px solid #000; padding: 8px; text-align: center;">No issues found</td>
        </tr>
      `;
    }

    // Build the final email content
    const mailSubject = `Status of ${project[0].project_name} : ${proj_internal[0].internal_project_name}  as on ${formattedDate}`;
    const content = `
      <div style="border: 1px solid #000; padding: 15px; max-width: 800px; margin: auto; font-family: Arial, sans-serif;">
        <div style="text-align: right; font-weight: bold; font-size: 18px;">
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcStkqqzpDMT-lMfT9KyFHVwQ85Jsc6b-kI2kw&s" alt="Kore.ai" height="80px">
        </div>
        
        <div style="margin-top: 20px; font-size: 14px;">
          Hello,<br><br>
          Current status of <b>${project[0].project_name} : ${proj_internal[0].internal_project_name} <b> as on ${formattedDate}</b><br><br>

          [Status colour codes: <b>COMPLETED:</b> <span style="color: green; font-size: 20px;">●</span>,
          <b>IN-PROGRESS:</b> <span style="color: blue; font-size: 20px;">●</span>,
          <b>PENDING:</b> <span style="color: red; font-size: 20px;">●</span>,
          <b>FUTURE:</b> <span style="color: black; font-size: 20px;">●</span>]
        </div>

        <table style="width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 14px;">
          <tr>
            <th style="border: 1px solid #000; padding: 8px; background-color: #fff; color: black; text-align: left;">Current Status</th>
            <td style="border: 1px solid #000; padding: 8px; text-align: left;">
              <ul style="margin: 0; padding-left: 20px; white-space:pre-line;">
                ${statusContent}
              </ul>
            </td>
          </tr>
          <tr>
            <th style="border: 1px solid #000; padding: 8px; background-color: #fff; color: black; text-align: left;">Percentage Completed</th>
            <td style="border: 1px solid #000; padding: 8px; text-align: left;">${perc[0].perc_completed}</td>
          </tr>
        </table>

        <div style="margin-top: 10px; font-weight: bold;">Issues:</div>

        <table style="width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 14px;">
          <tr>
            <th style="border: 1px solid #000; padding: 8px; background-color: #333; color: #fff; text-align: left;">Jira ID</th>
            <th style="border: 1px solid #000; padding: 8px; background-color: #333; color: #fff; text-align: left;">Jira URL</th>
            <th style="border: 1px solid #000; padding: 8px; background-color: #333; color: #fff; text-align: left;">Issue Description</th>
            <th style="border: 1px solid #000; padding: 8px; background-color: #333; color: #fff; text-align: left;">Issue Status</th>
            <th style="border: 1px solid #000; padding: 8px; background-color: #333; color: #fff; text-align: left;">Assigned To</th>
          </tr>
          <br>
          ${issueRows}
        </table>
      <div>This is a system generated email.</div>
      </div>
    `;
    let BAMailList = BAMails.map((mail) => mail.mail).join(", ");
    console.log(BAMailList);
    // Define recipient and send the email
    //  BAMailList = "barefootdemo@kore.com,dinesh.boda@kore.com";
    const response = await sendMail(BAMailList, mailSubject, content);

    res.json({
      success: true,
      message: "Email sent successfully",
      response,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};
