const express = require("express");
const connection = require("../config/sqlConnection");

const ValidLeave = async (userId, startDate, endDate) => {
  return new Promise((resolve, reject) => {
    const sqlQuery = `
      SELECT * 
      FROM leave_calender 
      WHERE user_id = ? AND deleted = 0 
      and (start_date >= end_date) AND
      (
        (start_date <= ? AND end_date >= ?) OR
        (start_date <= ? AND end_date >= ?)
      )
    `;
    connection.query(
      sqlQuery,
      [userId, startDate, startDate, endDate, endDate],
      (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.length === 0);
      }
    );
  });
};

const getLeavesByMonth = async (req, res) => {
  try {
    const { month, year } = req.params; 
    if (!month || !year) {
      return res.status(400).json({ error: "Month and year are required" });
    }

    const monthInt = parseInt(month, 10);
    const yearInt = parseInt(year, 10);

    if (
      isNaN(monthInt) ||
      isNaN(yearInt) ||
      monthInt < 1 ||
      monthInt > 12 ||
      yearInt < 1000 ||
      yearInt > 9999
    ) {
      return res.status(400).json({ error: "Invalid month or year" });
    }

    const sqlQuery = `
      SELECT * 
      FROM leave_calender 
      WHERE
        (
          (
            YEAR(start_date) = ?
            AND MONTH(start_date) <= ?
            AND (
              YEAR(end_date) = ?
              AND MONTH(end_date) >= ?
              OR YEAR(end_date) > ?
            )
          )
          OR (
            YEAR(start_date) < ?
            AND (
              YEAR(end_date) = ?
              AND MONTH(end_date) >= ?
              OR YEAR(end_date) > ?
            )
          )
        )
        AND deleted = 0
    `;

    connection.query(
      sqlQuery,
      [
        yearInt,
        monthInt,
        yearInt,
        monthInt,
        yearInt, 
         yearInt,
        yearInt,
        monthInt,
        yearInt,

      ],
      (err, results) => {
        if (err) {
          console.error("Error querying database:", err);
          return res.status(500).json({ error: "Internal Server Error" });
        }

        const formatDate = (date) => {
          const parsedDate = new Date(date);
          if (isNaN(parsedDate)) {
            return null;
          }
          const year = parsedDate.getFullYear();
          const month = ("0" + (parsedDate.getMonth() + 1)).slice(-2);
          const day = ("0" + parsedDate.getDate()).slice(-2);
          return `${year}-${month}-${day}`;
        };

        const leaves = results.map((row) => ({
          leave_id: row.leave_id,
          user_id: row.user_id,
          user_name: row.user_name,
          start_date: formatDate(row.start_date),
          end_date: formatDate(row.end_date),
          reason: row.reason,
          leave_type: row.leave_type,
        }));

        res.json(leaves);
      }
    );
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const getAllLeaves = async (req, res) => {
  try {
    const sqlQuery = `SELECT * FROM leave_calender where deleted = 0`;

    connection.query(sqlQuery, (err, results) => {
      if (err) {
        console.error("Error querying database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      const formatDate = (date) => {
        const parsedDate = new Date(date);
        if (isNaN(parsedDate)) {
          return null;
        }
        const year = parsedDate.getFullYear();
        const month = ("0" + (parsedDate.getMonth() + 1)).slice(-2);
        const day = ("0" + parsedDate.getDate()).slice(-2);
        return `${year}-${month}-${day}`;
      };

      const leaves = results.map((row) => ({
        leave_id: row.leave_id,
        user_id: row.user_id,
        user_name: row.user_name,
        start_date: formatDate(row.start_date),
        end_date: formatDate(row.end_date),
        reason: row.reason,
        leave_type: row.leave_type,
      }));

      res.json(leaves);
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const addLeave = async (req, res) => {
  try {
    const { user_id, user_name, start_date, end_date, reason, leave_type } =
      req.body;

    if (!user_id || !user_name || !start_date || !end_date || !leave_type) {
      return res.status(400).json({ error: "All fields are required" });
    }

    const formatDate = (date) => {
      const parsedDate = new Date(date);
      if (isNaN(parsedDate)) {
        throw new Error("Invalid date format");
      }
      const year = parsedDate.getFullYear();
      const month = ("0" + (parsedDate.getMonth() + 1)).slice(-2);
      const day = ("0" + parsedDate.getDate()).slice(-2);
      return `${year}-${month}-${day}`;
    };

    const formattedStartDate = formatDate(start_date);
    const formattedEndDate = formatDate(end_date);

    if (new Date(formattedStartDate) > new Date(formattedEndDate)) {
      return res
        .status(400)
        .json({ error: "Start date must be before end date" });
    }

    const isValid = await ValidLeave(
      user_id,
      formattedStartDate,
      formattedEndDate
    );
    if (!isValid) {
      return res
        .status(400)
        .json({ error: "Leave overlaps with an existing leave" });
    }

    const sqlQuery = `
      INSERT INTO leave_calender (
        user_id,
        user_name,
        start_date,
        end_date,
        reason,
        leave_type
      ) VALUES (?, ?, ?, ?, ?, ?)
    `;

    connection.query(
      sqlQuery,
      [
        user_id,
        user_name,
        formattedStartDate,
        formattedEndDate,
        reason || "",
        leave_type,
      ],
      (err, results) => {
        if (err) {
          console.error("Error inserting into database:", err);
          return res.status(500).json({ error: "Internal Server Error" });
        }

        res.status(201).json({
          message: "Leave added successfully",
          leaveId: results.insertId,
        });
      }
    );
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};


const updateLeave = async (req, res) => {
  try {
    const { leave_id } = req.params; 
        const { user_id, user_name, start_date, end_date, reason, leave_type } =
      req.body;

    if (!leave_id || isNaN(parseInt(leave_id))) {
      return res.status(400).json({ error: "Invalid leave_id" });
    }

    const formatDate = (date) => {
      const parsedDate = new Date(date);
      if (isNaN(parsedDate)) {
        return null;
      }
      const year = parsedDate.getFullYear();
      const month = ("0" + (parsedDate.getMonth() + 1)).slice(-2);
      const day = ("0" + parsedDate.getDate()).slice(-2);
      return `${year}-${month}-${day}`;
    };

    const formattedStartDate = formatDate(start_date);
    const formattedEndDate = formatDate(end_date);

    if (!formattedStartDate || !formattedEndDate) {
      return res
        .status(400)
        .json({ error: "Invalid date format. Please use YYYY-MM-DD." });
    }

    if (new Date(formattedStartDate) > new Date(formattedEndDate)) {
      return res
        .status(400)
        .json({ error: "Start date must be before end date" });
    }

    const sqlQuery = `
      UPDATE leave_calender
      SET
        user_id = ?,
        user_name = ?,
        start_date = ?,
        end_date = ?,
        reason = ?,
        leave_type = ?
      WHERE
        leave_id = ?
        AND deleted = 0
        and (start_date <= end_date)

    `;

    const values = [
      user_id,
      user_name,
      formattedStartDate,
      formattedEndDate,
      reason || "",
      leave_type,
      leave_id,
    ];

    connection.query(sqlQuery, values, (err, results) => {
      if (err) {
        console.error("Error updating database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }
      console.log(results)

      if (results.affectedRows === 0) {
        return res
          .status(404)
          .json({ error: "Leave not found or already deleted" });
      }

      res.json({ message: "Leave updated successfully" });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const softDeleteLeave = async (req, res) => {
  try {
    const { leave_id } = req.params;

    if (!leave_id || isNaN(parseInt(leave_id))) {
      return res.status(400).json({ error: "Invalid leave_id" });
    }

    const sqlQuery = `
      UPDATE leave_calender
      SET
        deleted = TRUE
      WHERE
        leave_id = ?
    `;

    const values = [leave_id];

    connection.query(sqlQuery, values, (err, results) => {
      if (err) {
        console.error("Error updating database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.affectedRows === 0) {
        return res
          .status(404)
          .json({ error: "Leave not found or already deleted" });
      }

      res.json({ message: "Leave removed successfully" });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const getAllRemovedLeaves = async (req, res) => {
  try {
    const sqlQuery = `SELECT * FROM leave_calender where deleted = 1`;

    connection.query(sqlQuery, (err, results) => {
      if (err) {
        console.error("Error querying database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      const formatDate = (date) => {
        const parsedDate = new Date(date);
        if (isNaN(parsedDate)) {
          return null;
        }
        const year = parsedDate.getFullYear();
        const month = ("0" + (parsedDate.getMonth() + 1)).slice(-2);
        const day = ("0" + parsedDate.getDate()).slice(-2);
        return `${year}-${month}-${day}`;
      };

      const leaves = results.map((row) => ({
        leave_id: row.leave_id,
        user_id: row.user_id,
        user_name: row.user_name,
        start_date: formatDate(row.start_date),
        end_date: formatDate(row.end_date),
        reason: row.reason,
        leave_type: row.leave_type,
      }));

      res.json(leaves);
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const getRemovedLeavesByMonth = async (req, res) => {
  try {
    const { month, year } = req.params; 
    if (!month || !year) {
      return res.status(400).json({ error: "Month and year are required" });
    }

    const monthInt = parseInt(month, 10);
    const yearInt = parseInt(year, 10);

    if (
      isNaN(monthInt) ||
      isNaN(yearInt) ||
      monthInt < 1 ||
      monthInt > 12 ||
      yearInt < 1000 ||
      yearInt > 9999
    ) {
      return res.status(400).json({ error: "Invalid month or year" });
    }

    const sqlQuery = `
      SELECT * 
      FROM leave_calender 
      WHERE
        (
          (
            YEAR(start_date) = ?
            AND MONTH(start_date) <= ?
            AND (
              YEAR(end_date) = ?
              AND MONTH(end_date) >= ?
              OR YEAR(end_date) > ?
            )
          )
          OR (
            YEAR(start_date) < ?
            AND (
              YEAR(end_date) = ?
              AND MONTH(end_date) >= ?
              OR YEAR(end_date) > ?
            )
          )
        )
        AND deleted = 1
    `;

    connection.query(
      sqlQuery,
      [
        yearInt,
        monthInt,
        yearInt,
        monthInt,
        yearInt, 
                yearInt,
        yearInt,
        monthInt,
        yearInt, 
      ],
      (err, results) => {
        if (err) {
          console.error("Error querying database:", err);
          return res.status(500).json({ error: "Internal Server Error" });
        }

        const formatDate = (date) => {
          const parsedDate = new Date(date);
          if (isNaN(parsedDate)) {
            return null;
          }
          const year = parsedDate.getFullYear();
          const month = ("0" + (parsedDate.getMonth() + 1)).slice(-2);
          const day = ("0" + parsedDate.getDate()).slice(-2);
          return `${year}-${month}-${day}`;
        };

        const leaves = results.map((row) => ({
          leave_id: row.leave_id,
          user_id: row.user_id,
          user_name: row.user_name,
          start_date: formatDate(row.start_date),
          end_date: formatDate(row.end_date),
          reason: row.reason,
          leave_type: row.leave_type,
        }));

        res.json(leaves);
      }
    );
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const restoreLeave = async (req, res) => {
  try {
    const { leave_id } = req.params; 
    if (!leave_id || isNaN(parseInt(leave_id))) {
      return res.status(400).json({ error: "Invalid leave_id" });
    }

    const sqlQuery = `
      UPDATE leave_calender
      SET
        deleted = False
      WHERE
        leave_id = ? and deleted = TRUE
    `;

    const values = [leave_id];

    connection.query(sqlQuery, values, (err, results) => {
      if (err) {
        console.error("Error updating database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.affectedRows === 0) {
        return res
          .status(404)
          .json({ error: "Leave not found or already deleted" });
      }

      res.json({ message: "Leave restored successfully" });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const hardDeleteLeave = async (req, res) => {
  try {
    const { leave_id } = req.params;

    const sqlQuery = "DELETE FROM leave_calender WHERE leave_id = ?";
    connection.query(sqlQuery, [leave_id], (err, results) => {
      if (err) {
        console.error("Error deleting from database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.affectedRows === 0) {
        return res.status(404).json({ error: "leave not found" });
      }

      res.json({ message: "leave deleted successfully" });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

module.exports = {
  getAllLeaves,
  getLeavesByMonth,
  addLeave,
  updateLeave,
  softDeleteLeave,
  getAllRemovedLeaves,
  getRemovedLeavesByMonth,
  restoreLeave,
  hardDeleteLeave,
};

