const mysql = require('mysql2/promise');
const dbConfig = require('../config/dbConfig');

function createPool(config) {
    return mysql.createPool(config);
}

const pool = createPool(dbConfig);

exports.GetProfile=async (req,res) =>{
    try{
        const userid=(req.query.uid);
        console.log(userid);
        const [rows] = await pool.execute(
            "select * from employee where UID = ?;",
            [userid]
        );
        const [rows2]=await pool.execute(
            "select * from users where UID = ?;",[userid]
        )
       

        if (rows.length !=0) {
            
            // console.log(rows);
            // console.log(tickets);
            res.json({ success: true, message: 'Fetching user profile successful', rows});
            
            

        }
        else if(rows.length==0 && rows2.length!=0){
            console.log(rows2[0].name)
            const name=rows2[0].name
            res.json({ success: true, message: 'Fetching user profile successful', name});

        } 
        else {
            // res.redirect('/');
            res.json({ success: true, message: 'No user Found with the concerned user id' });

        }


    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Internal Server Error' });
       
        
    }
}


exports.editIssues= async(req,res)=>{
   
    try{
        //console.log(req.body)
        const uid=(req.query.uid);
        console.log(uid);
        const userExists = await pool.execute("select * from employee where UID=?;", [uid]);
        console.log(userExists[0].length)
        if (userExists[0].length!=0) {
                // Define the modified fields and their new values
    const updates = {
       // Name :req.body.Name,
        Wing : req.body.Wing ,
        Phone_Number: req.body.Phone_Number,
        Designation : req.body.Designation,
        Qualification : req.body.Qualification,
        Career_Progression : req.body.Career_Progression,
        Skills : req.body.Skills,
        Date_Of_Birth : req.body.Date_Of_Birth,
        Date_Of_Joining : req.body.Date_Of_Joining,
        Hobbies : req.body.Hobbies,
        Role : req.body.Role,
        profile_img:req.body.profile_img
  };
  
  // Filter out the fields that haven't been modified
  const setClause = [];
  const values = [];
  for (const [key, value] of Object.entries(updates)) {
    if (value !== undefined) { // Check for modified values
      setClause.push(`${key} = ?`);
      values.push(value);
    }
  }
  
  if (setClause.length > 0) {
    // Add the ID of the record to update as the last value
   
    values.push(uid);
  
    // Construct the UPDATE query
    const updateQuery = `UPDATE employee SET ${setClause.join(', ')} WHERE UID = ?;`;
  console.log(updateQuery)
  console.log(values)
    // Execute the query
    const data = await pool.execute(updateQuery, values);
  
    // Send the response
    res.json({ success: true, message: 'Updated profile successfully', data });
  } else {
    // No fields to update
    res.json({ success: false, message: 'No fields to update' });
  }
  
            
        } else {
            res.json({ success: true, message: 'No User exists' });
        }
    }
    catch (error) {
        console.log(error)
        res.status(500).json({ success: false, message: 'Internal Server Error' });
       
        
    }

}
