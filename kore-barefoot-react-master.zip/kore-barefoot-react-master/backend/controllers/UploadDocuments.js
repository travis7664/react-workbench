const express = require('express');
const connection = require('../config/sqlConnection');


const getDocuments = async (req, res) => {
    try {
      const { did } = req.params; 
      const proj_id = did;
      const { user, uploaded_path, document_url, category, description, read_order } = req.body; 

      if (!proj_id) {
        return res.status(400).json({ error: 'proj_id is required' });
      }
  
      const sqlQuery = `SELECT * FROM demo_uploaded_docs WHERE proj_id = ?`;
  
      connection.query(sqlQuery, [proj_id], (err, results) => { // Pass proj_id here
        if (err) {
          console.error('Error querying database:', err);
          return res.status(500).json({ error: 'Internal Server Error' });
        }
  
        const documents = results.map(row => ({
          id: row.id,
          proj_id: row.proj_id,
          user: row.user,
          uploaded_path: row.uploaded_path,
          document_url: row.document_url,
          category: row.category,
          description: row.description,
          read_order: row.read_order
        }));
  
        res.json(documents);
      });
    } catch (error) {
      console.error('Error:', error.message);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };
  

  const addDocuments = async (req, res) => {
    try {
      const { did } = req.params; 
      const proj_id = did;
  
      const { user, uploaded_path, document_url, category, description, read_order } = req.body; 
  
      // Validation for required fields
      if (!proj_id) {
        return res.status(400).json({ error: 'proj_id is required' });
      }
  
      if (!user || !category || !description || read_order === undefined) {
        return res.status(400).json({ error: 'All document fields are required' });
      }
  
      const checkDemoQuery = 'SELECT COUNT(*) AS count FROM demos WHERE did = ?';
      connection.query(checkDemoQuery, [proj_id], (checkErr, checkResults) => {
        if (checkErr) {
          console.error('Error checking demo ID in database:', checkErr);
          return res.status(500).json({ error: 'Internal Server Error' });
        }
  
        const demoExists = checkResults[0].count > 0;
  
        if (!demoExists) {
          return res.status(404).json({ error: 'Demo ID not found' });
        }
  
        const sqlQuery = 'INSERT INTO demo_uploaded_docs (proj_id, user, uploaded_path, document_url, category, description, read_order) VALUES (?, ?, ?, ?, ?, ?, ?)';
        connection.query(sqlQuery, [proj_id, user, uploaded_path, document_url, category, description, read_order], (err, results) => {
          if (err) {
            console.error('Error inserting into database:', err);
            return res.status(500).json({ error: 'Internal Server Error' });
          }
  
          res.status(201).json({ message: 'Document added successfully', documentId: results.insertId });
        });
      });
    } catch (error) {
      console.error('Error:', error.message);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };
  

  const deleteDocument = async (req, res) => {
    try {
      const { did, id } = req.params;
      const proj_id = did;
    //   const doc_id = id;
  
      // Validate proj_id and id
      if (!proj_id) {
        return res.status(400).json({ error: 'proj_id is required' });
      }
      if (!id) {
        return res.status(400).json({ error: 'id is required' });
      }
  
      // Check if the document exists
      const checkDocQuery = 'SELECT COUNT(*) AS count FROM demo_uploaded_docs WHERE proj_id = ? AND id = ?';
      connection.query(checkDocQuery, [proj_id, id], (checkErr, checkResults) => {
        if (checkErr) {
          console.error('Error checking document ID in database:', checkErr);
          return res.status(500).json({ error: 'Internal Server Error' });
        }
  
        const docExists = checkResults[0].count > 0;
  
        if (!docExists) {
          return res.status(404).json({ error: 'Document not found' });
        }
  
        // Delete the document
        const deleteQuery = 'DELETE FROM demo_uploaded_docs WHERE proj_id = ? AND id = ?';
        connection.query(deleteQuery, [proj_id, id], (deleteErr, deleteResults) => {
          if (deleteErr) {
            console.error('Error deleting document from database:', deleteErr);
            return res.status(500).json({ error: 'Internal Server Error' });
          }
  
          res.status(200).json({ message: 'Document deleted successfully' });
        });
      });
    } catch (error) {
      console.error('Error:', error.message);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };
  

  const updateDocument = async (req, res) => {
    try {
      const { did, id } = req.params;
      const { user, uploaded_path, document_url, category, description, read_order } = req.body;
  
      if (!did) {
        return res.status(400).json({ error: 'proj_id is required' });
      }
  
      if (!id) {
        return res.status(400).json({ error: 'document_id is required' });
      }
  
      // Check if demo exists
      const checkDemoQuery = 'SELECT COUNT(*) AS count FROM demos WHERE did = ?';
      connection.query(checkDemoQuery, [did], (checkErr, checkResults) => {
        if (checkErr) {
          console.error('Error checking demo ID in database:', checkErr);
          return res.status(500).json({ error: 'Internal Server Error' });
        }
  
        const demoExists = checkResults[0].count > 0;
  
        if (!demoExists) {
          return res.status(404).json({ error: 'Demo ID not found' });
        }
  
        // Check if document exists
        const checkDocQuery = 'SELECT COUNT(*) AS count FROM demo_uploaded_docs WHERE proj_id = ? AND id = ?';
        connection.query(checkDocQuery, [did, id], (checkDocErr, checkDocResults) => {
          if (checkDocErr) {
            console.error('Error checking document ID in database:', checkDocErr);
            return res.status(500).json({ error: 'Internal Server Error' });
          }
  
          const docExists = checkDocResults[0].count > 0;
  
          if (!docExists) {
            return res.status(404).json({ error: 'Document ID not found' });
          }
  
          // Update the document
          const updateQuery = `
            UPDATE demo_uploaded_docs
            SET user = ?, uploaded_path = ?, document_url = ?, category = ?, description = ?, read_order = ?
            WHERE proj_id = ? AND id = ?
          `;
  
          connection.query(
            updateQuery,
            [user, uploaded_path, document_url, category, description, read_order, did, id],
            (updateErr, updateResults) => {
              if (updateErr) {
                console.error('Error updating document in database:', updateErr);
                return res.status(500).json({ error: 'Internal Server Error' });
              }
  
              res.status(200).json({ message: 'Document updated successfully' });
            }
          );
        });
      });
    } catch (error) {
      console.error('Error:', error.message);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };
  


module.exports = {
    getDocuments,
    addDocuments,
    deleteDocument,
    updateDocument

};
