const express = require("express");
const connection = require("../config/sqlConnection");

const getSDKwithKeyFields = async (req, res) => {
  try {
    const sqlQuery = `SELECT * FROM wp_chatbot order by id DESC`;

    connection.query(sqlQuery, (err, results) => {
      if (err) {
        console.error("Error querying database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      const sdks = results.map((row) => ({
        id: row.id,
        botname: row.botname,
        botid: row.botid,
        clientid: row.clientid,
        clientsecret: row.clientsecret,
        requester: row.requester,
        user_email: row.user_email,
      }));

      res.json(sdks);
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const getSDKs = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1; // Default to page 1 if not provided
    const limit = parseInt(req.query.limit) || 10; // Default to 10 items per page if not provided
    const offset = (page - 1) * limit; // Calculate the offset for SQL query

    const sqlQuery = `SELECT * FROM wp_chatbot ORDER BY id DESC LIMIT ? OFFSET ?`;
    const countQuery = `SELECT COUNT(*) as total FROM wp_chatbot`; // Query to count total records

    // Query for paginated results
    connection.query(sqlQuery, [limit, offset], (err, results) => {
      if (err) {
        console.error("Error querying database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      // Query for total count of records (for pagination metadata)
      connection.query(countQuery, (countErr, countResults) => {
        if (countErr) {
          console.error("Error querying database for count:", countErr);
          return res.status(500).json({ error: "Internal Server Error" });
        }

        const total = countResults[0].total;
        const totalPages = Math.ceil(total / limit);

        const sdks = results.map((row) => ({
          id: row.id,
          botname: row.botname,
          botid: row.botid,
          clientid: row.clientid,
          clientsecret: row.clientsecret,
          requester: row.requester,
          user_email: row.user_email,
          email_notify_send: row.email_notify_send,
          hide_show_connectagent: row.hide_show_connectagent,
          hide_kore_box: row.hide_kore_box,
          hide_link_section: row.hide_link_section,
          wel_msg: row.wel_msg,
          hide_pro_msg: row.hide_pro_msg,
          skip_welcome: row.skip_welcome,
          tagline: row.tagline,
          bot_lang: row.bot_lang,
          button_temp_vertcle: row.button_temp_vertcle,
          enable_speaker: row.enable_speaker,
          enable_microphone: row.enable_microphone,
          type_sdk: row.type_sdk,
          task: row.task,
          capability: row.capability,
          iswelcome: row.iswelcome,
          botusage: row.botusage,
          top_left_icon: row.top_left_icon,
          header_color: row.header_color,
          chatwindow_loading_time: row.chatwindow_loading_time,
          c_template: row.c_template,
          mic_icon: row.mic_icon,
          speaker_icon: row.speaker_icon,
          removetchbg: row.removetchbg,
          removetl: row.removetl,
          removeBG: row.removeBG,
          user_voice: row.user_voice,
          created_date: row.created_date, // Fixed from 'created_date date'
          autosubmit_user_utt: row.autosubmit_user_utt,
          upload_js: row.upload_js,
          upload_style: row.upload_style,
          attach_icon: row.attach_icon,
          ui_form: row.ui_form,
          chat_back_img: row.chat_back_img,
          typing_indicator: row.typing_indicator,
          back_img_option: row.back_img_option,
          bot_icon: row.bot_icon,
          selected_template: row.selected_template,
          temp_type: row.temp_type,
          bg_image: row.bg_image,
          created_by: row.created_by,
          koreAPIUrl: row.koreAPIUrl,
          interactive_language: row.interactive_language,
          training_utterance: row.training_utterance,
          panel: row.panel,
          window_l_c: row.window_l_c,
          load_history: row.load_history,
          random_uid: row.random_uid,
          e_email: row.e_email,
          training_script: row.training_script,
          pro_msg: row.pro_msg,
          pro_msg2: row.pro_msg2,
          text_color: row.text_color,
          extend_sdk: row.extend_sdk,
          notify_date: row.notify_date,
          open_chatwindow_direct: row.open_chatwindow_direct,
          prospect: row.prospect,
        }));

        res.json({
          page,
          limit,
          total,
          totalPages,
          data: sdks,
        });
      });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const getSDKbyID = async (req, res) => {
  try {
    const id = req.params.id;

    if (!id) {
      return res.status(400).json({ error: "id is required" });
    }

    const sqlQuery = `SELECT * FROM wp_chatbot WHERE id = ?`;

    // Ensure the id is passed as a parameter to avoid SQL injection
    connection.query(sqlQuery, [id], (err, results) => {
      if (err) {
        console.error("Error querying database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.length === 0) {
        return res.status(404).json({ error: "SDK not found" });
      }

      // Assuming you want to return more fields than just id and botname, you can expand this as needed
      const sdk = results.map((row) => ({
        id: row.id,
        botname: row.botname,
        botid: row.botid,
        clientid: row.clientid,
        clientsecret: row.clientsecret,
        requester: row.requester,
        user_email: row.user_email,
        email_notify_send: row.email_notify_send,
        hide_show_connectagent: row.hide_show_connectagent,
        hide_kore_box: row.hide_kore_box,
        hide_link_section: row.hide_link_section,
        wel_msg: row.wel_msg,
        hide_pro_msg: row.hide_pro_msg,
        skip_welcome: row.skip_welcome,
        tagline: row.tagline,
        bot_lang: row.bot_lang,
        button_temp_vertcle: row.button_temp_vertcle,
        enable_speaker: row.enable_speaker,
        enable_microphone: row.enable_microphone,
        type_sdk: row.type_sdk,
        task: row.task,
        capability: row.capability,
        iswelcome: row.iswelcome,
        botusage: row.botusage,
        top_left_icon: row.top_left_icon,
        header_color: row.header_color,
        chatwindow_loading_time: row.chatwindow_loading_time,
        c_template: row.c_template,
        mic_icon: row.mic_icon,
        speaker_icon: row.speaker_icon,
        removetchbg: row.removetchbg,
        removetl: row.removetl,
        removeBG: row.removeBG,
        user_voice: row.user_voice,
        created_date: row.created_date,
        autosubmit_user_utt: row.autosubmit_user_utt,
        upload_js: row.upload_js,
        upload_style: row.upload_style,
        attach_icon: row.attach_icon,
        ui_form: row.ui_form,
        chat_back_img: row.chat_back_img,
        typing_indicator: row.typing_indicator,
        back_img_option: row.back_img_option,
        bot_icon: row.bot_icon,
        selected_template: row.selected_template,
        temp_type: row.temp_type,
        bg_image: row.bg_image,
        created_by: row.created_by,
        koreAPIUrl: row.koreAPIUrl,
        interactive_language: row.interactive_language,
        training_utterance: row.training_utterance,
        panel: row.panel,
        window_l_c: row.window_l_c,
        load_history: row.load_history,
        random_uid: row.random_uid,
        e_email: row.e_email,
        training_script: row.training_script,
        pro_msg: row.pro_msg,
        pro_msg2: row.pro_msg2,
        text_color: row.text_color,
        extend_sdk: row.extend_sdk, // Added field
        notify_date: row.notify_date, // Added field
        open_chatwindow_direct: row.open_chatwindow_direct, // Added field
        prospect: row.prospect,
      }));

      res.json(sdk);
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const addSDK = async (req, res) => {
  try {
    // Extract data from the request body
    const {
      botname,
      botid,
      clientid,
      clientsecret,
      requester,
      user_email,
      email_notify_send,
      hide_show_connectagent,
      hide_kore_box,
      hide_link_section,
      wel_msg,
      hide_pro_msg,
      skip_welcome,
      tagline,
      bot_lang,
      button_temp_vertcle,
      enable_speaker,
      enable_microphone,
      type_sdk,
      task,
      capability,
      iswelcome,
      botusage,
      top_left_icon,
      header_color,
      chatwindow_loading_time,
      c_template,
      mic_icon,
      speaker_icon,
      removetchbg,
      removetl,
      removeBG,
      user_voice,
      created_date,
      autosubmit_user_utt,
      upload_js,
      upload_style,
      attach_icon,
      ui_form,
      chat_back_img,
      typing_indicator,
      back_img_option,
      bot_icon,
      selected_template,
      temp_type,
      bg_image,
      created_by,
      koreAPIUrl,
      interactive_language,
      training_utterance,
      panel,
      window_l_c,
      load_history,
      random_uid,
      e_email,
      training_script,
      pro_msg,
      pro_msg2,
      text_color,
      extend_sdk,
      notify_date,
      open_chatwindow_direct,
      prospect,
    } = req.body;

    if (!botname || !botid || !clientid || !clientsecret || !user_email) {
      return res.status(400).json({
        error:
          "Missing required fields: botname, botid, clientid, clientsecret, user_email",
      });
    }

    // SQL query to insert the data into the wp_chatbot table
    const sqlQuery = `
        INSERT INTO wp_chatbot (
          botname, botid, clientid, clientsecret, requester, user_email, email_notify_send, 
          hide_show_connectagent, hide_kore_box, hide_link_section, wel_msg, hide_pro_msg, skip_welcome, 
          tagline, bot_lang, button_temp_vertcle, enable_speaker, enable_microphone, type_sdk, task, 
          capability, iswelcome, botusage, top_left_icon, header_color, chatwindow_loading_time, c_template, 
          mic_icon, speaker_icon, removetchbg, removetl, removeBG, user_voice, created_date, autosubmit_user_utt, 
          upload_js, upload_style, attach_icon, ui_form, chat_back_img, typing_indicator, back_img_option, bot_icon, 
          selected_template, temp_type, bg_image, created_by, koreAPIUrl, interactive_language, training_utterance, 
          panel, window_l_c, load_history, random_uid, e_email, training_script, pro_msg, pro_msg2, text_color, extend_sdk,notify_date,open_chatwindow_direct ,prospect
        ) 
        VALUES (?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

    const values = [
      botname,
      botid,
      clientid,
      clientsecret,
      requester,
      user_email,
      email_notify_send,
      hide_show_connectagent,
      hide_kore_box,
      hide_link_section,
      wel_msg,
      hide_pro_msg,
      skip_welcome,
      tagline,
      bot_lang,
      button_temp_vertcle,
      enable_speaker,
      enable_microphone,
      type_sdk,
      task,
      capability,
      iswelcome,
      botusage,
      top_left_icon,
      header_color,
      chatwindow_loading_time,
      c_template,
      mic_icon,
      speaker_icon,
      removetchbg,
      removetl,
      removeBG,
      user_voice,
      created_date,
      autosubmit_user_utt,
      upload_js,
      upload_style,
      attach_icon,
      ui_form,
      chat_back_img,
      typing_indicator,
      back_img_option,
      bot_icon,
      selected_template,
      temp_type,
      bg_image,
      created_by,
      koreAPIUrl,
      interactive_language,
      training_utterance,
      panel,
      window_l_c,
      load_history,
      random_uid,
      e_email,
      training_script,
      pro_msg,
      pro_msg2,
      text_color,
      extend_sdk,
      notify_date,
      open_chatwindow_direct,
      prospect,
    ];

    // Execute the query
    connection.query(sqlQuery, values, (err, results) => {
      if (err) {
        console.error("Error inserting data into database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      // Return success response with the newly created SDK id
      res
        .status(201)
        .json({ message: "SDK added successfully", sdkId: results.insertId });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const updateSDK = async (req, res) => {
  try {
    const { id } = req.params;

    const {
      botname,
      botid,
      clientid,
      clientsecret,
      requester,
      user_email,
      email_notify_send,
      hide_show_connectagent,
      hide_kore_box,
      hide_link_section,
      wel_msg,
      hide_pro_msg,
      skip_welcome,
      tagline,
      bot_lang,
      button_temp_vertcle,
      enable_speaker,
      enable_microphone,
      type_sdk,
      task,
      capability,
      iswelcome,
      botusage,
      top_left_icon,
      header_color,
      chatwindow_loading_time,
      c_template,
      mic_icon,
      speaker_icon,
      removetchbg,
      removetl,
      removeBG,
      user_voice,
      created_date,
      autosubmit_user_utt,
      upload_js,
      upload_style,
      attach_icon,
      ui_form,
      chat_back_img,
      typing_indicator,
      back_img_option,
      bot_icon,
      selected_template,
      temp_type,
      bg_image,
      created_by,
      koreAPIUrl,
      interactive_language,
      training_utterance,
      panel,
      window_l_c,
      load_history,
      random_uid,
      e_email,
      training_script,
      pro_msg,
      pro_msg2,
      text_color,
      extend_sdk,
      notify_date,
      open_chatwindow_direct,
      prospect,
    } = req.body;

    // Validate that the id is provided
    if (!id) {
      return res.status(400).json({ error: "id is required to update SDK" });
    }

    // SQL query to update the record in the wp_chatbot table
    const sqlQuery = `
        UPDATE wp_chatbot
        SET 
          botname = ?, botid = ?, clientid = ?, clientsecret = ?, requester = ?, user_email = ?, email_notify_send = ?, 
          hide_show_connectagent = ?, hide_kore_box = ?, hide_link_section = ?, wel_msg = ?, hide_pro_msg = ?, skip_welcome = ?, 
          tagline = ?, bot_lang = ?, button_temp_vertcle = ?, enable_speaker = ?, enable_microphone = ?, type_sdk = ?, task = ?, 
          capability = ?, iswelcome = ?, botusage = ?, top_left_icon = ?, header_color = ?, chatwindow_loading_time = ?, c_template = ?, 
          mic_icon = ?, speaker_icon = ?, removetchbg = ?, removetl = ?, removeBG = ?, user_voice = ?, created_date = ?, autosubmit_user_utt = ?, 
          upload_js = ?, upload_style = ?, attach_icon = ?, ui_form = ?, chat_back_img = ?, typing_indicator = ?, back_img_option = ?, bot_icon = ?, 
          selected_template = ?, temp_type = ?, bg_image = ?, created_by = ?, koreAPIUrl = ?, interactive_language = ?, training_utterance = ?, 
          panel = ?, window_l_c = ?, load_history = ?, random_uid = ?, e_email = ?, training_script = ?, pro_msg = ?, pro_msg2 = ?, text_color = ?, extend_sdk= ?,notify_date= ?,open_chatwindow_direct = ? ,prospect=?
        WHERE id = ?
      `;

    const values = [
      botname,
      botid,
      clientid,
      clientsecret,
      requester,
      user_email,
      email_notify_send,
      hide_show_connectagent,
      hide_kore_box,
      hide_link_section,
      wel_msg,
      hide_pro_msg,
      skip_welcome,
      tagline,
      bot_lang,
      button_temp_vertcle,
      enable_speaker,
      enable_microphone,
      type_sdk,
      task,
      capability,
      iswelcome,
      botusage,
      top_left_icon,
      header_color,
      chatwindow_loading_time,
      c_template,
      mic_icon,
      speaker_icon,
      removetchbg,
      removetl,
      removeBG,
      user_voice,
      created_date,
      autosubmit_user_utt,
      upload_js,
      upload_style,
      attach_icon,
      ui_form,
      chat_back_img,
      typing_indicator,
      back_img_option,
      bot_icon,
      selected_template,
      temp_type,
      bg_image,
      created_by,
      koreAPIUrl,
      interactive_language,
      training_utterance,
      panel,
      window_l_c,
      load_history,
      random_uid,
      e_email,
      training_script,
      pro_msg,
      pro_msg2,
      text_color,
      extend_sdk,
      notify_date,
      open_chatwindow_direct,
      prospect,
      id,
    ];

    connection.query(sqlQuery, values, (err, results) => {
      if (err) {
        console.error("Error updating database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.affectedRows === 0) {
        return res.status(404).json({ error: `SDK with id ${id} not found` });
      }

      res.json({ message: `SDK with id ${id} updated successfully` });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const deleteSDK = async (req, res) => {
  try {
    const { id } = req.params;

    const sqlQuery = "DELETE FROM wp_chatbot WHERE id = ?";
    connection.query(sqlQuery, [id], (err, results) => {
      if (err) {
        console.error("Error deleting from database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      if (results.affectedRows === 0) {
        return res.status(404).json({ error: "WebSDK not found" });
      }

      res.json({ message: "WebSDK deleted successfully" });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

module.exports = {
  getSDKwithKeyFields,
  getSDKs,
  getSDKbyID,
  addSDK,
  updateSDK,
  deleteSDK,
};
