const sharp = require("sharp");
const FormData = require("form-data");
const crypto = require("crypto");
const { uploadFile, uploadFileWithSignedUrl, deleteFile } = require("../s3");
const { default: axios } = require("axios");

const createPost = async (req, res) => {
  try {
    const file = req.file;

    if (!file) {
      return res.status(400).json({ error: "Image file is required" });
    }

    const generateFileName = (bytes = 32) =>
      crypto.randomBytes(bytes).toString("hex");

    const imageName = generateFileName();

    const fileBuffer = await sharp(file.buffer)
      .resize({ height: 1920, width: 1080, fit: "contain" })
      .toBuffer();

    const signedUrl = await uploadFile(fileBuffer, imageName, file.mimetype);
    console.log(signedUrl);

    res.status(201).json({
      signedUrl,
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const createPostwithSignedURL = async (req, res) => {
  try {
    const file = req.file;

    if (!file) {
      return res.status(400).json({ error: "Image file is required" });
    }

    const generateFileName = (bytes = 32) =>
      crypto.randomBytes(bytes).toString("hex");

    const imageName = generateFileName();

    const fileBuffer = await sharp(file.buffer).toBuffer();

    const signedUrl = await uploadFileWithSignedUrl(
      fileBuffer,
      imageName,
      file.mimetype
    );
    console.log(signedUrl);

    res.status(201).json({
      signedUrl,
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const deleteFileFromBucket = async (req, res) => {
  try {
    const { fileName } = req.params;

    if (!fileName) {
      return res.status(400).json({ error: "File name is required" });
    }

    await deleteFile(fileName);

    res.status(200).json({ message: `File ${fileName} successfully deleted` });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const UploadToOldBarefoot = async (req, res) => {
  try {
    const file = req.file;

    if (!file) {
      return res.status(400).json({ error: "A file is required" });
    }

    const generateFileName = (bytes = 32) =>
      crypto.randomBytes(bytes).toString("hex");
    const extension = file.mimetype.split("/")[1];
    let fileName = `${generateFileName()}.${extension}`;
    fileName = fileName.replace(/\s+/g, '');
    console.log("filename",fileName)

    let fileBuffer = file.buffer;

    // If the file is an image, process it with sharp to get the buffer
    if (file.mimetype.startsWith("image/")) {
      fileBuffer = await sharp(file.buffer).toBuffer();
    }

    // Create form-data instance
    const formData = new FormData();
    formData.append("file", fileBuffer, {
      filename: fileName,
      contentType: file.mimetype,
    });

    const response = await axios.post(
      "https://demo.kore.ai/images/newbarefoot-fileupload/index.php",
      formData,
      {
        headers: {
          ...formData.getHeaders(),
          Cookie:
            "SESS83a2009fb9497b6d47966974ad24232d=aeotca9ekp864t7ei7ciuoi3fk",
        },
        maxBodyLength: Infinity,
      }
    );
    res.status(201).json({
      signedUrl: response.data,
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

module.exports = {
  createPost,
  createPostwithSignedURL,
  deleteFileFromBucket,
  UploadToOldBarefoot,
};
