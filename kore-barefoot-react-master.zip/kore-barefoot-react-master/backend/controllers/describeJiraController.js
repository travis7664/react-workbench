const axios = require('axios');

exports.GetJira = async (req, res) => {
    try {
        const tickets = req.body.tids;
        console.log(tickets);

        const headers = {
            'Authorization': 'Basic a2lyYW4ucGF0aWxAa29yZS5jb206SzY1WlhrNE5IVmx1aXJJRVlGcDhDNjk5',
            'Content-Type': 'application/json'
        };

        const promises = tickets.map(ticket => {
            return axios.get(`https://koreteam.atlassian.net/rest/api/2/issue/${ticket}?fields=description,status,duedate,assignee,created,resolutiondate`, { headers });
        });

        const responses = await Promise.all(promises);

        const allRows = responses.map(response => {
            const fields = response.data.fields;
            return {
                description: fields.description,
                status: fields.status.name,
                duedate: fields.duedate,
                assignee: fields.assignee.displayName,
                created:fields.created,
                resolutiondate:fields.resolutiondate
            };
        });

        res.json({ success: true, message: 'Fetching Ticket details successful', data: allRows });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};
