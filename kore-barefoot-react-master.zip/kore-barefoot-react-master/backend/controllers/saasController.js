const mysql = require("mysql2/promise");
const dbConfig = require("../config/dbConfig");

// Database setup
function createPool(config) {
  return mysql.createPool(config);
}

const pool = createPool(dbConfig);

exports.GetSaas = async (req, res) => {
  try {
    const [rows] = await pool.execute("select * from wp_credentials;");
    if (rows.length !== 0) {
      res.json({
        success: true,
        message: "Fetching Saas credentials successful",
        rows,
      });
    } else {
      res.json({
        success: true,
        message: "No Demo Found with the concerned demo id",
      });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};

exports.PostSaas = async (req, res) => {
  try {
    if (req.body) {
      const project = req.body.project || null;
      const url = req.body.url || null;
      const username = req.body.username || null;
      const password = req.body.password || null;
      const comments = req.body.comments || null;
      const added_name = req.body.added_name || null;
      const otp_owner_email = req.body.otp_owner_email || null;
      const otp_owner = req.body.otp_owner || null;
      const otp_owner_phn = req.body.otp_owner_phn || null
      // const last_updated = req.body.last_updated || null;
      const last_updated = new Date().toISOString();
      const isWorking =1;
      const key_reserve = req.body.key_reserve || null;
      const owner_email = req.body.owner_email || null;

      const data = await pool.execute(
        "INSERT INTO wp_credentials (project, url, username, password, comments, added_name, last_updated, key_reserve,owner_email,isWorking,otp_owner_email,otp_owner,otp_owner_phn) VALUES (?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,?);",
        [
          project,
          url,
          username,
          password,
          comments,
          added_name,
          last_updated,
          key_reserve,
          owner_email,
          isWorking,
          otp_owner_email,
          otp_owner,
          otp_owner_phn
        ]
      );
      res.json({
        success: true,
        message: "Updated Credentials successfully",
        data,
      });
    } else {
      res.json({ success: true, message: "No entry exists" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};

exports.PutSaas = async (req, res) => {
  try {
    //console.log(req.body)
    const eid = req.query.eid;
    console.log(eid);
    const userExists = await pool.execute(
      "select * from wp_credentials where ID=?;",
      [eid]
    );
    console.log(userExists[0].length);
    if (userExists[0].length != 0) {
      // Define the modified fields and their new values
      const updates = {
        project: req.body.project,
        url: req.body.url,
        username: req.body.username,
        password: req.body.password,
        comments: req.body.comments,
        added_name: req.body.added_name,
        isWorking: req.body.isWorking,
        otp_owner_email : req.body.otp_owner_email,
        otp_owner : req.body.otp_owner,
        otp_owner_phn : req.body.otp_owner_phn,
        //   last_updated : req.body.last_updated ,
        last_updated: new Date().toISOString(),
        key_reserve: req.body.key_reserve,
        owner_email: req.body.owner_email,
      };

      // Filter out the fields that haven't been modified
      const setClause = [];
      const values = [];
      for (const [key, value] of Object.entries(updates)) {
        if (value !== undefined) {
          // Check for modified values
          setClause.push(`${key} = ?`);
          values.push(value);
        }
      }

      if (setClause.length > 0) {
        // Add the ID of the record to update as the last value

        values.push(eid);

        // Construct the UPDATE query
        const updateQuery = `UPDATE wp_credentials SET ${setClause.join(
          ", "
        )} WHERE ID = ?;`;

        // Execute the query
        const data = await pool.execute(updateQuery, values);
        console.log(updateQuery);
        console.log(values);
        // Send the response
        res.json({
          success: true,
          message: "Updated credentials successfully",
          data,
        });
      } else {
        // No fields to update
        res.json({ success: false, message: "No fields to update" });
      }
    } else {
      res.json({ success: true, message: "No entry exists" });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};

// exports.DelSaas = async (req, res) => {
//     try {
//         const eid=req.body.eid
//         const [userExists] = await pool.execute("select * from wp_credentials where ID=?;", [eid]);
//         if (userExists.length) {

//             const data = await pool.execute(
//                 "DELETE  FROM wp_credentials WHERE ID=?;",
//                 [eid]
//             );
//             res.json({ success: true, message: 'Deleted Credentials successfully', data });
//         } else {
//             res.json({ success: true, message: 'No entry exists' });
//         }
//     } catch (error) {
//         console.log(error);
//         res.status(500).json({ success: false, message: 'Internal Server Error' });
//     }
// }

exports.DelSaas = async (req, res) => {
  try {
    const eid = req.query.eid;

    if (!eid) {
      return res
        .status(400)
        .json({ success: false, message: "eid is required" });
    }

    const [userExists] = await pool.execute(
      "SELECT * FROM wp_credentials WHERE ID = ?;",
      [eid]
    );

    if (userExists.length) {
      const data = await pool.execute(
        "DELETE FROM wp_credentials WHERE ID = ?;",
        [eid]
      );
      res.json({
        success: true,
        message: "Deleted Credentials successfully",
        data,
      });
    } else {
      res.json({ success: true, message: "No entry exists" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};
