const express = require("express");
const connection = require("../config/sqlConnection");

const getSDKs = async (req, res) => {
  try {
    const { SearchClauses } = req.params;
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const offset = (page - 1) * limit;

    let whereClause = "";
    let queryParams = [];

    if (SearchClauses !== "*") {
      const searchParam = `%${SearchClauses.toUpperCase()}%`;
      whereClause = `WHERE UPPER(botname) LIKE ? OR UPPER(botid) LIKE ? OR UPPER(requester) LIKE ? OR UPPER(prospect) LIKE ?`;
      queryParams.push(searchParam, searchParam, searchParam, searchParam);
    }

    queryParams.push(limit, offset);

    const sqlQuery = `SELECT * FROM wp_chatbot ${whereClause} ORDER BY id DESC LIMIT ? OFFSET ?`;

    const countQuery = `SELECT COUNT(*) as total FROM wp_chatbot ${whereClause}`;

    connection.query(sqlQuery, queryParams, (err, results) => {
      if (err) {
        console.error("Error querying database:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }

      connection.query(countQuery, queryParams.slice(0, -2), (countErr, countResults) => {
        if (countErr) {
          console.error("Error querying database for count:", countErr);
          return res.status(500).json({ error: "Internal Server Error" });
        }

        const total = countResults[0].total;
        const totalPages = Math.ceil(total / limit);

        const sdks = results.map((row) => ({
          id: row.id,
          botname: row.botname,
          botid: row.botid,
          clientid: row.clientid,
          clientsecret: row.clientsecret,
          requester: row.requester,
          user_email: row.user_email,
          email_notify_send: row.email_notify_send,
          hide_show_connectagent: row.hide_show_connectagent,
          hide_kore_box: row.hide_kore_box,
          hide_link_section: row.hide_link_section,
          wel_msg: row.wel_msg,
          hide_pro_msg: row.hide_pro_msg,
          skip_welcome: row.skip_welcome,
          tagline: row.tagline,
          bot_lang: row.bot_lang,
          button_temp_vertcle: row.button_temp_vertcle,
          enable_speaker: row.enable_speaker,
          enable_microphone: row.enable_microphone,
          type_sdk: row.type_sdk,
          task: row.task,
          capability: row.capability,
          iswelcome: row.iswelcome,
          botusage: row.botusage,
          top_left_icon: row.top_left_icon,
          header_color: row.header_color,
          chatwindow_loading_time: row.chatwindow_loading_time,
          c_template: row.c_template,
          mic_icon: row.mic_icon,
          speaker_icon: row.speaker_icon,
          removetchbg: row.removetchbg,
          removetl: row.removetl,
          removeBG: row.removeBG,
          user_voice: row.user_voice,
          created_date: row.created_date,
          autosubmit_user_utt: row.autosubmit_user_utt,
          upload_js: row.upload_js,
          upload_style: row.upload_style,
          attach_icon: row.attach_icon,
          ui_form: row.ui_form,
          chat_back_img: row.chat_back_img,
          typing_indicator: row.typing_indicator,
          back_img_option: row.back_img_option,
          bot_icon: row.bot_icon,
          selected_template: row.selected_template,
          temp_type: row.temp_type,
          bg_image: row.bg_image,
          created_by: row.created_by,
          koreAPIUrl: row.koreAPIUrl,
          interactive_language: row.interactive_language,
          training_utterance: row.training_utterance,
          panel: row.panel,
          window_l_c: row.window_l_c,
          load_history: row.load_history,
          random_uid: row.random_uid,
          e_email: row.e_email,
          training_script: row.training_script,
          pro_msg: row.pro_msg,
          pro_msg2: row.pro_msg2,
          text_color: row.text_color,
          extend_sdk: row.extend_sdk,
          notify_date: row.notify_date,
          open_chatwindow_direct: row.open_chatwindow_direct,
          prospect: row.prospect,
        }));

        res.json({
          page,
          limit,
          total,
          totalPages,
          data: sdks,
        });
      });
    });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

module.exports = {
  getSDKs,
};
