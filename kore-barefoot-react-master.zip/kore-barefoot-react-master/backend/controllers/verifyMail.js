const { generateToken, verifyToken } = require('../helpers/jwtHelper');
const con = require('../config/dbConnection');
const connection = con.getConnection();
sendMail=require("..//helpers/sendMail");

try {
    connection.connect();
} catch (error) {
    throw new Error("An error occurred during database connection: ", error);
}

const verifyMail = (req, res) => {
    const token = req.query.token;
    const email = req.query.email;
    const decodedToken = verifyToken(token);

    if (!decodedToken) {
        return res.status(500).json({ success: false, message: 'Token Expired' });
    }

    const userEmail = decodedToken.email;

    connection.query('select firstname from user WHERE email=?', [userEmail], (err, result) => {
        if (err) {
            console.log(err.message);
            return res.status(500).json({ success: false, message: 'Error fetching name' });
        }

        const name = result[0].firstname; 
       

        connection.query('insert into users (mail, name, init) values (?, ?, ?)', [userEmail, name, userEmail], (err) => {
            if (err) {
                console.log(err.message);
                return res.status(500).json({ success: false, message: 'Error inserting into users' });
            }

            connection.query('select uid from users where mail=?', [userEmail], (err, result) => {
                if (err) {
                    console.log(err.message);
                    return res.status(500).json({ success: false, message: 'Error fetching uid' });
                }

                const uid = result[0].uid;

                connection.query('insert into users_roles (uid, rid) values (?, ?)', [uid, 2], (err) => {
                    if (err) {
                        console.log(err.message);
                        return res.status(500).json({ success: false, message: 'Error inserting into users_roles' });
                    }

                    connection.query('update user set token = NULL, is_verified = 1 where email = ?', [userEmail], (err) => {
                        if (err) {
                            console.log(err.message);
                            return res.status(500).json({success:false,message:'error occured',erroroccured:err}); // Render an error page for database update failure
                        }
                        let mailSubject = "User access granted";
                        let content = `<p> Hi ${name},Your access to barefoot has been granted by the admin visit and explore <a href="${process.env.GOOGLE_SUCCESS_URL}"> Barefoot </a></p>`;
                        sendMail(`${userEmail}`, mailSubject, content);
                        res.json({ success: true, message: 'User is verified by Admin Successfully' });
                    });
                });
            });
        });
    });
};

module.exports = {
    verifyMail,
};
