const express = require('express');
const connection = require('../config/sqlConnection');

const getRoles = async (req, res) => {
  try {
    const sqlQuery = `SELECT * FROM role order by rid`;

    connection.query(sqlQuery, (err, results) => {
      if (err) {
        console.error('Error querying database:', err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      const roles = results.map(row => ({
        rid: row.rid,
        role_name: row.name
      }));

      res.json(roles);
    });
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const addRole = async (req, res) => {
  try {
    const { role_name } = req.body;

    if (!role_name) {
      return res.status(400).json({ error: 'role_name is required' });
    }

    const sqlQuery = 'INSERT INTO role (name) VALUES (?)';
    connection.query(sqlQuery, [role_name], (err, results) => {
      if (err) {
        console.error('Error inserting into database:', err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      res.status(201).json({ message: 'Role added successfully', roleId: results.insertId });
    });
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const updateRole = async (req, res) => {
  try {
    const { rid } = req.params;
    const { role_name } = req.body;

    if (!role_name) {
      return res.status(400).json({ error: 'role_name is required' });
    }

    const sqlQuery = 'UPDATE role SET name = ? WHERE rid = ?';
    connection.query(sqlQuery, [role_name, rid], (err, results) => {
      if (err) {
        console.error('Error updating database:', err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      if (results.affectedRows === 0) {
        return res.status(404).json({ error: 'Role not found' });
      }

      res.json({ message: 'Role updated successfully' });
    });
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const deleteRole = async (req, res) => {
  try {
    const { rid } = req.params;

    const sqlQuery = 'DELETE FROM role WHERE rid = ?';
    connection.query(sqlQuery, [rid], (err, results) => {
      if (err) {
        console.error('Error deleting from database:', err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      if (results.affectedRows === 0) {
        return res.status(404).json({ error: 'Role not found' });
      }

      res.json({ message: 'Role deleted successfully' });
    });
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

module.exports = {
  getRoles,
  addRole,
  updateRole,
  deleteRole
};