const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/connection');

const User = sequelize.define('User', {
  uid: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  mail: {
    type: DataTypes.STRING,
    allowNull: false
  },
  team:{
    type: DataTypes.STRING,
    allowNull: true
  },
  isactive:{
    type: DataTypes.INTEGER,
    allowNull: true
  }

}, {
  tableName: 'users',
  timestamps: false
});

module.exports = User;
