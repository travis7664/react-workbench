const { DataTypes } = require('sequelize');
const sequelize = require('../config/connection');

const UserProject = sequelize.define('UserProject', {
  uid: {
    type: DataTypes.INTEGER,
    references: {
      model: 'users',
      key: 'uid'
    }
  },
  did: {
    type: DataTypes.INTEGER,
    references: {
      model: 'demos',
      key: 'did'
    }
  },
  rid: {
    type: DataTypes.INTEGER,
    references: {
      model: 'roles',
      key: 'rid'
    }
  }
}, {
  tableName: 'users_projects',
  timestamps: false
});

module.exports = UserProject;
