const { DataTypes } = require('sequelize');
const sequelize = require('../config/connection');
const User = require('./User');
const Role = require('./Role');

const UserRole = sequelize.define('UserRole', {
  uid: {
    type: DataTypes.INTEGER,
    references: {
      model: User,
      key: 'uid'
    }
  },
  rid: {
    type: DataTypes.INTEGER,
    references: {
      model: Role,
      key: 'rid'
    }
  }
}, {
  tableName: 'users_roles',
  timestamps: false
});

// User.belongsToMany(Role, { through: UserRole, foreignKey: 'uid' });
// Role.belongsToMany(User, { through: UserRole, foreignKey: 'rid' });

module.exports = UserRole;
