const { DataTypes } = require('sequelize');
const sequelize = require('../config/connection');

const UserProjectDetails = sequelize.define('UserProjectDetails', {
  uid: {
    type: DataTypes.INTEGER,
    references: {
      model: 'users',
      key: 'uid'
    }
  },
  pid: {
    type: DataTypes.INTEGER,
    references: {
      model: 'demos',
      key: 'did'
    }
  },
  contributed_percentage: {
    type: DataTypes.FLOAT,
    allowNull: true
  },
  status: {
    type: DataTypes.STRING,
    allowNull: true
  }
}, {
  tableName: 'users_projects_details',
  timestamps: false
});

module.exports = UserProjectDetails;
