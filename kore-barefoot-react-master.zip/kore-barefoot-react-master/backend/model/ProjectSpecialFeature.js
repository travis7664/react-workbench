const { DataTypes } = require('sequelize');
const sequelize = require('../config/connection');

const ProjectSpecialFeature = sequelize.define('ProjectSpecialFeature', {
  demo_id: {
    type: DataTypes.INTEGER,
    references: {
      model: 'demos',
      key: 'did'
    }
  },
  feature_id: {
    type: DataTypes.INTEGER,
    references: {
      model: 'special_features',
      key: 'id'
    }
  }
}, {
  tableName: 'proj_spec_features',
  timestamps: false
});

module.exports = ProjectSpecialFeature;
