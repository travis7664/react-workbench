const User = require('./User');
const Role = require('./Role');
const UserRole = require('./UserRole');
const UserProject = require('./UserProject');
const UserProjectDetails = require('./UserProjectDetails');
const Demo = require('./Demo');
const SpecialFeature = require('./SpecialFeature');
const ProjectSpecialFeature = require('./ProjectSpecialFeature');



User.belongsToMany(Role, { through: UserRole, foreignKey: 'uid' });
Role.belongsToMany(User, { through: UserRole, foreignKey: 'rid' });

User.hasMany(UserProjectDetails, { as: 'UserProjectDetails', foreignKey: 'uid' });
UserProjectDetails.belongsTo(User, { foreignKey: 'uid' });

Demo.belongsToMany(User, { through: UserProject, as: 'Users', foreignKey: 'did' });
User.belongsToMany(Demo, { through: UserProject, as: 'Demos', foreignKey: 'uid' });

Demo.belongsToMany(SpecialFeature, { through: ProjectSpecialFeature, as: 'SpecialFeatures', foreignKey: 'demo_id' });
SpecialFeature.belongsToMany(Demo, { through: ProjectSpecialFeature, as: 'Demos', foreignKey: 'feature_id' });

module.exports = { User, Role, Demo, UserRole, UserProject, UserProjectDetails, ProjectSpecialFeature, SpecialFeature };
