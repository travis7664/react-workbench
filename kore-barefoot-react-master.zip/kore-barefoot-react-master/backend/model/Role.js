const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/connection');

const Role = sequelize.define('Role', {
  rid: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  }
}, {
  tableName: 'role',
  timestamps: false
});

module.exports = Role;
