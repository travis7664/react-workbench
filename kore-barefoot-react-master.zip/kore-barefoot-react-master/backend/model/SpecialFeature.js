const { DataTypes } = require('sequelize');
const sequelize = require('../config/connection');

const SpecialFeature = sequelize.define('SpecialFeature', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  category_name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  feature_name: {
    type: DataTypes.STRING,
    allowNull: false
  }
}, {
  tableName: 'special_features',
  timestamps: false
});

module.exports = SpecialFeature;
