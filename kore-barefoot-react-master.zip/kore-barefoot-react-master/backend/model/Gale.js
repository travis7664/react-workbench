const { DataTypes } = require('sequelize');
const sequelize = require('../config/connection');

const Gale = sequelize.define('Gale', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    title: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    agentId: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    owner: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    uuid: {
        type: DataTypes.STRING(36),
        allowNull: false
    },
    config: {
        type: DataTypes.JSON(),
        allowNull: false
    },
    // CONFIG JSON
    //
    //  version: "0.1.0"
    //  agentDescription: {
    //     type: DataTypes.TEXT("medium"),
    //     allowNull: false
    // },
    //  uuid: {
    //      type: String
    //  },
    // apiKey: {
    //     type: DataTypes.STRING(255),
    //     allowNull: false
    // },
    // input: {
    //     type: DataTypes.JSON(),
    //     allowNull: false
    // },
    // primaryColor: {
    //     type: DataTypes.STRING(255),
    //     allowNull: false
    // },
    // backgroundColor: {
    //     type: DataTypes.STRING(255),
    //     allowNull: false
    // },
    // secondaryBackgroundColor: {
    //     type: DataTypes.STRING(255),
    //     allowNull: false
    // },
    // textColor: {
    //     type: DataTypes.STRING(255),
    //     allowNull: false
    // },
    // isActive: {
    //     type: DataTypes.BOOLEAN(),
    //     allowNull: false
    // },
}, {
    createdAt: true,
    updatedAt: true,
    tableName: "gale_agents",
});

module.exports = Gale;
