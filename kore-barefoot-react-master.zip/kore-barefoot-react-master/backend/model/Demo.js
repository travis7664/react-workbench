const { DataTypes } = require('sequelize');
const sequelize = require('../config/connection');

const Demo = sequelize.define('Demo', {
  did: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  entity_id: {
    type: DataTypes.TINYINT,
    allowNull: false,
    defaultValue: 0
  },
  project_name: {
    type: DataTypes.STRING(225),
    allowNull: false
  },
  internal_project_name: {
    type: DataTypes.STRING(225),
    allowNull: false
  },
  client_name: {
    type: DataTypes.STRING(225),
    allowNull: false
  },
  functional_theme: {
    type: DataTypes.STRING(225),
    allowNull: false
  },
  project_type: {
    type: DataTypes.STRING(50),
    allowNull: false,
    defaultValue: ''
  },
  project_desc: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  lp_project_desc: {
    type: DataTypes.TEXT('long'),
    allowNull: false
  },
  client_domains: {
    type: DataTypes.STRING(225),
    allowNull: false
  },
  team_type: {
    type: DataTypes.STRING(10),
    allowNull: false,
    defaultValue: ''
  },
  owner: {
    type: DataTypes.STRING(255),
    allowNull: false,
    defaultValue: ''
  },
  probability_percentage: {
    type: DataTypes.STRING(50),
    allowNull: false
  },
  sfdc_link: {
    type: DataTypes.TEXT('long'),
    allowNull: false
  },
  sales_closure_date: {
    type: DataTypes.DATE,
    allowNull: false
  },
  native: {
    type: DataTypes.STRING(255),
    allowNull: false,
    defaultValue: ''
  },
  mobweb: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  mobspa: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  tablets: {
    type: DataTypes.STRING(255),
    allowNull: false,
    defaultValue: ''
  },
  tabletweb: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  tabletspa: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  desktop: {
    type: DataTypes.STRING(255),
    allowNull: false,
    defaultValue: ''
  },
  hybrid: {
    type: DataTypes.STRING(255),
    allowNull: false,
    defaultValue: ''
  },
  wrapper: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  mixedmode: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  wearable: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  orientation: {
    type: DataTypes.TEXT('long'),
    allowNull: false
  },
  other_channel: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  plug_ins: {
    type: DataTypes.STRING(225),
    allowNull: false
  },
  deliverables: {
    type: DataTypes.STRING(255),
    allowNull: false,
    defaultValue: ''
  },
  project_tags: {
    type: DataTypes.TEXT('long'),
    allowNull: false
  },
  request_received: {
    type: DataTypes.DATE,
    allowNull: false
  },
  start_date: {
    type: DataTypes.DATE,
    allowNull: false
  },
  estimated_end_date: {
    type: DataTypes.DATE,
    allowNull: false
  },
  estimated_project_duration: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  current_status: {
    type: DataTypes.STRING(255),
    allowNull: false,
    defaultValue: ''
  },
  project_closure: {
    type: DataTypes.TINYINT,
    allowNull: false,
    defaultValue: 0
  },
  actual_end_date: {
    type: DataTypes.DATE,
    allowNull: false
  },
  visualizer_passcode: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  visualizer_desc: {
    type: DataTypes.TEXT('long'),
    allowNull: false
  },
  visualizer_version: {
    type: DataTypes.STRING(20),
    allowNull: false
  },
  project_criticality: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  demo_end_feedback: {
    type: DataTypes.TEXT('long'),
    allowNull: false
  },
  feedback: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  reason: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  current_health: {
    type: DataTypes.STRING(255),
    allowNull: false,
    defaultValue: ''
  },
  current_complexity: {
    type: DataTypes.STRING(255),
    allowNull: false,
    defaultValue: ''
  },
  percentage_completed: {
    type: DataTypes.TINYINT,
    allowNull: false,
    defaultValue: 0
  },
  base_project: {
    type: DataTypes.STRING(255),
    allowNull: false,
    defaultValue: ''
  },
  bot_tenant: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  bot_env: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  jira_link: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  milestones_schedules: {
    type: DataTypes.TEXT('long'),
    allowNull: false
  },
  ui_reviewer: {
    type: DataTypes.STRING(225),
    allowNull: false
  },
  code_review: {
    type: DataTypes.STRING(225),
    allowNull: false
  },
  issue_logging: {
    type: DataTypes.STRING(225),
    allowNull: false
  },
  video_labelling: {
    type: DataTypes.STRING(225),
    allowNull: false
  },
  tech_lead: {
    type: DataTypes.STRING(255),
    allowNull: false,
    defaultValue: ''
  },
  developers: {
    type: DataTypes.STRING(255),
    allowNull: false,
    defaultValue: ''
  },
  jiraLink: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  designers: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  qa: {
    type: DataTypes.STRING(255),
    allowNull: false,
    defaultValue: ''
  },
  lp_user_name: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  lp_password: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  lp_demovideo_client_logo: {
    type: DataTypes.STRING(225),
    allowNull: false
  },
  bot_zip_files: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  automation_file: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  client_id: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  client_secret: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  automation_region: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  automation_project: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  automation_total_task: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  pass: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  failed: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  failed_task_name: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  automation_script: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  lp_demovideo_url: {
    type: DataTypes.TEXT('long'),
    allowNull: false
  },
  standup_time: {
    type: DataTypes.STRING(50),
    allowNull: false
  },
  special_character_check: {
    type: DataTypes.TINYINT,
    allowNull: false
  },
  created_user: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  created_date: {
    type: DataTypes.DATE,
    allowNull: false
  },
  updated_user: {
    type: DataTypes.STRING(100),
    allowNull: false,
    defaultValue: '0'
  },
  updated_date: {
    type: DataTypes.DATE,
    allowNull: false
  },
  waiting_for_feedback_status_update_date: {
    type: DataTypes.DATE,
    allowNull: false
  },
  waiting_for_feedback_status_update_user: {
    type: DataTypes.STRING(100),
    allowNull: false,
    defaultValue: '0'
  },
  completed_status_update_date: {
    type: DataTypes.DATE,
    allowNull: true
  },
  completed_status_update_user: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  demo_search: {
    type: DataTypes.TINYINT,
    allowNull: false,
    defaultValue: 1
  },
  demo_popular: {
    type: DataTypes.TINYINT,
    allowNull: false,
    defaultValue: 0
  },
  showcase_demo_status: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  showcase_demo_comment: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  demo_label: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  demo_care: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  customer_link: {
    type: DataTypes.TEXT,
    allowNull: true
  }
}, {
  tableName: 'demos',
  timestamps: false
});

module.exports = Demo;
