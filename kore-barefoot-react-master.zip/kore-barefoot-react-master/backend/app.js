require("dotenv").config();
const express = require("express");
const session = require("express-session");
const cookieParser = require("cookie-parser");
const passport = require("passport");
const path = require("path");
const authRoutes = require("./routes/authRoutes");
const bodyParser = require("body-parser");
const usersApiRouter = require("./routes/routes");
const s3Routes = require("./routes/s3Routes");
const streamlitRouter = require("./routes/streamlit");
const statusRoutes = require("./routes/statusRoutes");
const kickOffRoutes = require("./routes/KickOffRoutes");
const tokenRoutes = require("./middleware/tokenAPI");

const profileRoutes = require("./routes/profileRoutes");
const saasRoutes = require("./routes/saasRoutes");
const queryRoutes = require("./routes/queryRoutes");

const manageSecretRoutes = require("./routes/ManageSecretRoutes");

const bannerRoutes = require("./routes/bannerRoutes");
const solRoutes = require("./routes/solutionRoutes");
const mergeRoutes = require("./routes/mergeRoutes");
const webhookRoutes = require("./routes/webhookRoutes");

const app = express();
app.use(bodyParser.json());
const cors = require("cors");

// const allowedOrigins = [
//   "http://localhost:3000",
//   "https://barefoot-dev.kore.ai",
//   "http://127.0.0.1:5500/",
//   "*"
// ];

// const corsOptions = {
//   origin: function (origin, callback) {
//     if (!origin || allowedOrigins.indexOf(origin) !== -1) {
//       callback(null, true);
//     } else {
//       callback(new Error("Not allowed by CORS"));
//     }
//   },
//   credentials: true,
// };

// app.use(cors(corsOptions));

const corsOptions = {
  origin: true,
  credentials: true,
  credentials: true,
};

app.use(cors(corsOptions));

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

app.use(
  session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 }, // 1 day
  })
);

app.use(passport.initialize());
app.use(passport.session());

require("./helpers/passportConfig");
app.use(express.static(path.join(__dirname, "public")));

app.use("/backend/webhook", webhookRoutes);

app.use("/backend/data", express.static(path.join(__dirname, "data")));

app.use("/backend/auth", authRoutes);

app.use("/backend/streamlit", streamlitRouter);
app.use("/backend/status", statusRoutes);
app.use("/backend/kickoff", kickOffRoutes);
app.use("/backend/query", queryRoutes);
app.use("/backend/s3", s3Routes);
app.use("/backend/profile", profileRoutes);
app.use("/backend/saas", saasRoutes);
app.use("/backend/manageSecretRoutes", manageSecretRoutes);
app.use("/backend/bannerRoutes", bannerRoutes);
app.use("/backend/solRoutes", solRoutes);

app.use("/backend/controllers", express.static(path.join(__dirname, "data")));

app.get("/backend/dashboard", (req, res) => {
  if (req.isAuthenticated()) {
    res.sendFile(path.join(__dirname, "public", "dashboard.html"));
  } else {
    res.redirect("/");
  }
});

app.use("/backend/api", usersApiRouter);
app.use("/backend/VA", tokenRoutes);

app.use("/backend/WebSDK", express.static(path.join(__dirname, "./webSDK")));
app.use(
  "/backend/retail-SDK",
  express.static(path.join(__dirname, "./webSDK/retail-assist-SDK"))
);
app.use(
  "/backend/logo",
  express.static(path.join(__dirname, "./webSDK/custom-editor/public"))
);
app.use(
  "/backend/default",
  express.static(path.join(__dirname, "./webSDK/custom-editor/default"))
);
app.use(
  "/backend/retail-SDK",
  express.static(path.join(__dirname, "./webSDK/retail-assist-SDK"))
);
app.use(
  "/backend/logo",
  express.static(path.join(__dirname, "./webSDK/custom-editor/public"))
);
app.use(
  "/backend/default",
  express.static(path.join(__dirname, "./webSDK/custom-editor/default"))
);

// Use the merge routes
app.use("/backend/custom", mergeRoutes);
app.listen(5000, () => {
  console.log("Server is running on port 5000");
});
