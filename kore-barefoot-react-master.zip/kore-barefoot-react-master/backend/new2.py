from sentence_transformers import SentenceTransformer # type: ignore
from sklearn.metrics.pairwise import cosine_similarity
import pandas as pd
import os
import time
import logging
from datetime import datetime
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium import webdriver as wd
from selenium.webdriver.chrome.options import Options
import sys 
import json
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service  # Import Service
from selenium.webdriver.chrome.options import Options  # Import Options


os.system("clear")
# Configure headless mode for Chrome
chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument("--disable-gpu")  # Optional for compatibility
chrome_options.add_argument("--no-sandbox")  # Optional for Linux servers
chrome_options.add_argument('--disable-software-rasterizer')
#chrome_options.add_argument('--remote-debugging-port=9222')
chrome_options.binary_location = "/usr/bin/google-chrome"
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
output_directory = "./data"
log_directory = "./data/Logs"
log_file_name = f"Execution_{timestamp}.log"
log_path = os.path.join(output_directory, log_file_name)
logging.basicConfig(
    filename=log_path,  # Log file name
    level=logging.INFO,        # Log level (INFO, DEBUG, WARNING, etc.)
    format='%(asctime)s - %(levelname)s - %(message)s'  # Log format
)

logging.info("Logging started")
#Read the file
# df=pd.read_excel("E:\pythonwithenvironment\env03Oct\Data\DemoScript_BankAssist_SAMPLE.xlsx")
df=pd.read_excel(str(sys.argv[1]))
# df=pd.read_excel("./DemoScript_NSWDemo.xlsx")
#print(df.head(50))
va_rows = []
user_rows = []
is_VA_first_run = True

# Initialize the pre-trained model
model = SentenceTransformer('all-MiniLM-L6-v2')

def compute_semantic_similarity(sentence1, sentence2):
    # Convert sentences to embeddings
    embedding1 = model.encode([sentence1])
    embedding2 = model.encode([sentence2])

    # Compute the cosine similarity between the embeddings
    similarity_score = cosine_similarity(embedding1, embedding2)[0][0]
    return similarity_score

# Example sentences
#sentence1 = "The quick brown fox jumps over the lazy dog."
#sentence2 = "A fast dark-colored fox leaps over a sleepy dog."

# Calculate similarity score
#similarity = compute_semantic_similarity(sentence1, sentence2)
#similarity*=100
#print(f"Semantic Similarity Score: {similarity}")
#if similarity > 65:
 #   print ("PASS")
#else:
 #   print("FAIL")

combined_dfwithvauser=[]
# Iterate over each row in the DataFrame
for index, row in df.iterrows():
    
    if row[0] == 'start':
        Usecase=row[1]
        #print("Here is the row1")
        #print(row[1])
        combined_dfwithvauser.append({"Role": "UseCase", "Message": "Started","Use Case Name":Usecase})
    if row[0] == 'VA' or row[0] == 'VA_3':  # Check if the first cell is 'VA'
        va_rows.append(row[1])  # Add the next cell's value to VA rows
        combined_dfwithvauser.append({"Role": row[0], "Message": row[1],"Use Case Name":Usecase})
    elif row[0] == 'User':  # Check if the first cell is 'User'
        user_rows.append(row[1])  # Add the next cell's value to User rows
        combined_dfwithvauser.append({"Role": row[0], "Message": row[1],"Use Case Name":Usecase})
    elif row[0] == 'End':
        #print(Usecase,": is completed")
        combined_dfwithvauser.append({"Role": "UseCase", "Message": "Ends here","Use Case Name":Usecase})
    elif row[0] == 'VA_button':
        combined_dfwithvauser.append({"Role": row[0], "Message": row[1],"Use Case Name":Usecase})
    elif row[0] == 'DigitalForm':
        combined_dfwithvauser.append({"Role": row[0], "Message": row[1],"Use Case Name":Usecase})
    elif row[0] == 'DigitalForm_text':
        combined_dfwithvauser.append({"Role": row[0], "Message": row[1],"Use Case Name":Usecase})
    elif row[0] == 'DigitalForm_submit':
        combined_dfwithvauser.append({"Role": row[0], "Message": row[1],"Use Case Name":Usecase})
    

# Optionally, convert the lists to DataFrames if you want to save or process them
va_df = pd.DataFrame(va_rows, columns=["VA Values"])
user_df = pd.DataFrame(user_rows, columns=["User Values"])

# Print or save the results
#print("VA Rows:")
#print(va_df)
#print("\nUser Rows:")
#print(user_df)
#combined_data = {
    #'Role': ['VA'] * len(va_rows) + ['User'] * len(user_rows),
  #  'Message': va_rows + user_rows
#}

#combined_df1 = pd.DataFrame(combined_data)
combined_df=pd.DataFrame(combined_dfwithvauser)
# Print the combined DataFrame
logging.info("Combined DataFrame:")
print("###########Here is the Refreshed RAG sheet with VA and Users#########")
print("PLEASE DOUBLE CHECK ALL THE ROWS IN THE RAG ARE APPEARING HERE OR NOT ELSE LET KNOW")
logging.info("PLEASE DOUBLE CHECK ALL THE ROWS IN THE RAG ARE APPEARING HERE OR NOT ELSE LET KNOW")
#print(combined_df1)
print(combined_df)
logging.info(combined_df)

 
file_name = f"Execution_{timestamp}.xlsx"
html_file_name = f"Execution_{timestamp}.html"
json_file_name = f"Execution_{timestamp}.json"
output_path = os.path.join(output_directory, file_name)
html_output_path = os.path.join(output_directory, html_file_name)
json_output_path = os.path.join(output_directory, json_file_name)
os.makedirs(output_directory, exist_ok=True)
combined_df.to_excel(output_path, index=False)
outputexcelPD=pd.read_excel(output_path)
outputexcelPD["Status"]=""
outputexcelPD["Actual Message"]=""
outputexcelPD["Actual Last Bot Message"]=""
outputexcelPD["Actual Previous to Last Bot Message"]=""
outputexcelPD["Actual Previous to Previous Last Bot Message"]=""
outputexcelPD["Semantic Score"]=""
outputexcelPD.to_excel(output_path,index=False)
outputexcelPDtoedit=pd.read_excel(output_path)
service = Service(ChromeDriverManager().install())
driver = wd.Chrome(service=service, options=chrome_options)
# driver = wd.Chrome(options=chrome_options)
# driver.get("https://demo.kore.ai/demo/template/newsdk10/UI/index.php?botid=st-30fdb8f1-6036-50fb-bf9a-1d539bab7493&id=1395")
driver.get(str(sys.argv[2]))
time.sleep(10)
driver.maximize_window()

send_message_button = driver.find_element(By.XPATH, "//button[@class='primary-button' and text()='Send Message']")

# Click the button
send_message_button.click()
time.sleep(10)
bot_actual_last_message = driver.find_element(By.XPATH, "(//div[@class='bubble-msg'])[last()]")

textarea = driver.find_element(By.XPATH, "//textarea[@id='typing-text-area' and @class='typing-text-area']")

# Clear the existing text (optional)
textarea.clear()

# Loop through each row in the DataFrame
for index, row in combined_df.iterrows():
    condition = ((outputexcelPDtoedit["Role"] == row['Role']) &
                    (outputexcelPDtoedit["Message"] == row['Message']) &
                    (outputexcelPDtoedit["Use Case Name"] == row["Use Case Name"]))
    if row['Role'] == 'VA' or row['Role'] == 'VA_3' :  # If the role is 'VA'
        # Find the last message from the bot (VA)        
        time.sleep(5)
        last_message_element = driver.find_element(By.XPATH, "(//div[@class='bubble-msg'])[last()]")
        if not is_VA_first_run:
            prev_last_message_element = driver.find_element(By.XPATH, "(//div[@class='bubble-msg'])[last()-1]")
        else:
            is_VA_first_run = False 
            prev_last_message_element =driver.find_element(By.XPATH, "(//div[@class='bubble-msg'])[last()]")     
        last_message_text = last_message_element.text
        prev_message_text = prev_last_message_element.text
        
        similarity1=compute_semantic_similarity(last_message_text, row['Message'])
        similarity2=compute_semantic_similarity(prev_message_text, row['Message'])
        
        print("Last 2 message from the bot are:")
        logging.info("Last 2 message from the bot are:")
        print(prev_message_text)
        logging.info(prev_message_text)
        print(last_message_text)
        logging.info(last_message_text)
        print("The expected message from the bot is")
        logging.info("The expected message from the bot is")
        print(row['Message'])
        logging.info(row['Message'])
        similarity1*=100
        similarity2*=100
        
        similarity=max(similarity1,similarity2)
        if(similarity==similarity1):
            outputexcelPDtoedit.loc[condition,"Actual Message"]=last_message_text
        else:
            outputexcelPDtoedit.loc[condition,"Actual Message"]=prev_message_text
        if row['Role'] == 'VA_3':
            prev_prev_last_message_element = driver.find_element(By.XPATH, "(//div[@class='bubble-msg'])[last()-2]")
            prev_prev_message_text = prev_prev_last_message_element.text
            similarity3=compute_semantic_similarity(prev_prev_message_text, row['Message'])
            similarity3*=100
            print("The 3rd message in the Bot from the bottom is:")
            logging.info("The 3rd message in the Bot from the bottom is:")
            print(prev_prev_message_text)
            logging.info(prev_prev_message_text)
            similarity=max(similarity1,similarity2,similarity3)
            if(similarity==similarity1):
                outputexcelPDtoedit.loc[condition,"Actual Message"]=last_message_text
            elif(similarity==similarity2):
                outputexcelPDtoedit.loc[condition,"Actual Message"]=prev_message_text
            else:
                outputexcelPDtoedit.loc[condition,"Actual Message"]=prev_prev_message_text
            outputexcelPDtoedit.loc[condition, "Actual Last Bot Message"] = last_message_text
            outputexcelPDtoedit.loc[condition, "Actual Previous to Last Bot Message"] = prev_message_text
            outputexcelPDtoedit.loc[condition, "Actual Previous to Previous Last Bot Message"] = prev_prev_message_text
        print(f"Semantic Similarity Score of these is: {similarity}")
        logging.info(f"Semantic Similarity Score of these is: {similarity}")
        if similarity > 65:
            print ("PASS")
            logging.info("PASS")
            status="PASS"
            print(f"VA message matches the last message: {last_message_text}")
            logging.info(f"VA message matches the last message: {last_message_text}")
        else:
            print("FAIL")
            status="FAIL"
            print(f"VA message does NOT match the last message. Expected: {row['Message']} - Found: {last_message_text}")
            logging.info(f"VA message does NOT match the last message. Expected: {row['Message']} - Found: {last_message_text}")

        
        outputexcelPDtoedit.loc[condition, "Status"] = status
        outputexcelPDtoedit.loc[condition, "Semantic Score"] = similarity
        outputexcelPDtoedit.loc[condition, "Actual Last Bot Message"] = last_message_text
        outputexcelPDtoedit.loc[condition, "Actual Previous to Last Bot Message"] = prev_message_text
        # Compare the VA's message with the last message in the conversation
        #if last_message_text == row['Message']:
         #   print(f"VA message matches the last message: {last_message_text}")
        #else:
         #   print(f"VA message does NOT match the last message. Expected: {row['Message']} - Found: {last_message_text}")
    elif row['Role'] == 'User':  # If the role is 'User'
        # Find the text area and send the message from the User
        time.sleep(5)
        textarea = driver.find_element(By.XPATH, "//textarea[@id='typing-text-area' and @class='typing-text-area']")
        textarea.clear()  # Clear any existing text
        textarea.send_keys(row['Message'])
        textarea.send_keys(Keys.RETURN)  # Simulate pressing Enter to send the message
        driver.implicitly_wait(5)  # Wait for the response from the bot
        print(f"User message sent: {row['Message']}")
        logging.info(f"User message sent: {row['Message']}")
        time.sleep(3)
        outputexcelPDtoedit.loc[condition, "Status"] = "PASS"
        outputexcelPDtoedit.loc[condition,"Actual Message"]=row['Message']
        outputexcelPDtoedit.loc[condition, "Semantic Score"] = 100
    elif row['Role'] == 'UseCase' and row['Message'] == 'Started' :  # If the role is 'User'
        # Find the text area and send the message from the User
        time.sleep(3)
        print(row["Use Case Name"],end=" ")
        logging.info(row["Use Case Name"])
        print(": Use Case Execution started")
        logging.info(": Use Case Execution started")
        outputexcelPDtoedit.loc[condition, "Status"] = "-"
        outputexcelPDtoedit.loc[condition,"Actual Message"]="-"
        outputexcelPDtoedit.loc[condition, "Semantic Score"] = "-"
    elif row['Role'] == 'UseCase' and row['Message'] == 'Ends here' :  # If the role is 'User'
        # Find the text area and send the message from the User
        time.sleep(3)
        print(row["Use Case Name"],end=" ")
        logging.info(row["Use Case Name"])
        print(": Use Case Execution Completed")
        logging.info(": Use Case Execution Completed")
        outputexcelPDtoedit.loc[condition, "Status"] = "-"
        outputexcelPDtoedit.loc[condition,"Actual Message"]="-"
        outputexcelPDtoedit.loc[condition, "Semantic Score"] = "-"
    elif row['Role'] == 'DigitalForm_text':
        time.sleep(3)        
        xpath=f"//span[text()='{row['Message'].split(',')[0].strip()}']/following::input[1]"
        textfield = driver.find_element(By.XPATH, xpath)
        textfield.clear()
        textfield.send_keys(row['Message'].split(',')[1].strip())
        #//span[text()='Full Name']/following::input[1]
        outputexcelPDtoedit.loc[condition, "Status"] = "-"
        outputexcelPDtoedit.loc[condition,"Actual Message"]="-"
        outputexcelPDtoedit.loc[condition, "Semantic Score"] = "-"
    elif row['Role'] == 'DigitalForm_submit':
        time.sleep(3)
        #iframe = driver.find_element(By.TAG_NAME, "iframe") 
        #driver.switch_to.frame(iframe)
        xpath=f"//button[text()='{row['Message']}']"
        button = driver.find_elements(By.XPATH, xpath)
        if len(button) >0:
            print(row["Message"],end=" ")
            print("Digital Form Button exists in the UI")
            status="PASS"
            driver.switch_to.default_content()
        else:
            print(row["Message"],end=" ")
            logging.info(row["Message"])
            print("Digital Form Button DOES NOT exists in the UI")
            logging.info(("Digital Form Button DOES NOT exists in the UI"))
            status="FAIL"
            driver.switch_to.default_content()
        outputexcelPDtoedit.loc[condition, "Status"] = status
    elif row['Role'] == 'DigitalForm':        
        time.sleep(3)
        xpath=f"//button[text()='{row['Message']}']"
        button = driver.find_elements(By.XPATH, xpath)
        if len(button) >0:
            print(row["Message"],end=" ")
            print("Digital Form exists in the UI")
            button[0].click()
            #button.click()
            time.sleep(3)
            status="PASS"
            print(status)
            logging.info(status)
            iframe = driver.find_element(By.TAG_NAME, "iframe") 
            driver.switch_to.frame(iframe)
        else:
            print(row["Message"],end=" ")
            logging.info(row["Message"])
            print("Digital Form DOES NOT exists in the UI")
            logging.info("Digital Form DOES NOT exists in the UI")
            status="FAIL"
        outputexcelPDtoedit.loc[condition, "Status"] = status
    elif row['Role'] == 'VA_button':
        time.sleep(3)
        xpath=f"//button[text()='{row['Message']}']"
        button = driver.find_elements(By.XPATH, xpath)
        if len(button) >0:
            print(row["Message"],end=" ")
            logging.info(row["Message"])
            print("Button exists in the UI")
            logging.info("Button exists in the UI")
            status="PASS"
        else:
            print(row["Message"],end=" ")
            logging.info(row["Message"])
            print("Button DOES NOT exists in the UI")
            logging.info("Button DOES NOT exists in the UI")
            status="FAIL"
        outputexcelPDtoedit.loc[condition, "Status"] = status


outputexcelPDtoedit.to_excel(output_path,index=False)
outputexcelPDtoedit.to_html(html_output_path,index=False)
finalDF=outputexcelPDtoedit[['Use Case Name','Role','Message','Actual Message','Status','Semantic Score']]
finalDF.to_excel(output_path,index=False)
finalDF.to_html(html_output_path,index=False)
# finalDF.to_json(json_output_path,orient='records', lines=True)
finalDF.to_json(json_output_path,orient='records', lines=False)

json_output = finalDF.to_json(orient='records')
print(json.dumps(json.loads(json_output), indent=4))

#finalDF.to_json