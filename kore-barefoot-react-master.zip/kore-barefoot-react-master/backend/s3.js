const { S3Client, PutObjectCommand, DeleteObjectCommand, ListObjectsV2Command,GetObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl  } = require("@aws-sdk/s3-request-presigner");
const dotenv = require('dotenv');

// Load environment variables
dotenv.config();

const bucketName = process.env.AWS_BUCKET_NAME;
const region = process.env.AWS_BUCKET_REGION;
const accessKeyId = process.env.AWS_ACCESS_KEY;
const secretAccessKey = process.env.AWS_SECRET_ACCESS_KEY;

// Initialize S3 client
const s3Client = new S3Client({
  region,
  credentials: {
    accessKeyId,
    secretAccessKey,
  },
});


async function uploadFile(fileBuffer, fileName, mimetype) {
    const uploadParams = {
      Bucket: bucketName,
      Body: fileBuffer,
      Key: fileName,
      ContentType: mimetype,
      // ACL: 'public-read',  // Set the file to be publicly accessible

    };
  
    await s3Client.send(new PutObjectCommand(uploadParams));
  
    const fileUrl = `https://${bucketName}.s3.${region}.amazonaws.com/${fileName}`;
  
    return fileUrl; 
  }

// Function to delete a file from S3
function deleteFile(fileName) {
  const deleteParams = {
    Bucket: bucketName,
    Key: fileName,
  };

  return s3Client.send(new DeleteObjectCommand(deleteParams));
}


async function uploadFileWithSignedUrl(fileBuffer, fileName, mimetype) {
  // First, upload the file to S3
  const uploadParams = {
    Bucket: bucketName,
    Body: fileBuffer,
    Key: fileName,
    ContentType: mimetype,
  };
  
  await s3Client.send(new PutObjectCommand(uploadParams));

  // Now generate a signed URL for the uploaded file
  const signedUrl = await getObjectSignedUrl(fileName);

  return signedUrl;
}


// Function to get a signed URL for a file in S3
async function getObjectSignedUrl(key) {
  const params = {
    Bucket: bucketName,
    Key: key,
  };

  const command = new GetObjectCommand(params);
  const expiresIn = 604800 ; 
  const url = await getSignedUrl(s3Client, command, { expiresIn });

  return url;
}

async function getAllFiles() {
  const listParams = {
    Bucket: bucketName,
  };

  // Fetch list of objects from the bucket
  const command = new ListObjectsV2Command(listParams);
  const { Contents } = await s3Client.send(command);

  if (!Contents || Contents.length === 0) {
    return [];
  }

  // Generate signed URLs for each object
  const fileUrls = await Promise.all(
    Contents.map(async (file) => {
      const signedUrl = await getObjectSignedUrl(file.Key);
      return {
        fileName: file.Key,
        url: signedUrl,
      };
    })
  );

  return fileUrls;
}
module.exports = {
  uploadFile,
  deleteFile,
  uploadFileWithSignedUrl,
  getObjectSignedUrl,
  getAllFiles
};
