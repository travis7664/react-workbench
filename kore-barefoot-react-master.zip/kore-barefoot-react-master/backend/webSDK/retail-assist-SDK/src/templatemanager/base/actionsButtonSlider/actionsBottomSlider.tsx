

import './actionsBottomSlider.scss';
import { h } from 'preact';

export function ActionsBottomSlider(props: any) {
    return (
        <div className="chat-actions-bottom-wraper" aria-label="chat widget body">
            <div className="actions-contnet-data"></div>
        </div>
    );
}

