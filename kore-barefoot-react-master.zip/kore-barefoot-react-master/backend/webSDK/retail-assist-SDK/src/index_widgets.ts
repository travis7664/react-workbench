// declare global {
//     interface Window {
//         KoreSDK:any;
//     }
// }
// import $ from 'jquery';
// console.log("index.js");
// import '../UI/libs/kore-no-conflict-start';
// import requireKr from '../kore-bot-sdk-client'
// import '../UI/libs/jquery'
// import '../UI/libs/jquery.tmpl.min.js';
// import '../UI/libs/jquery-ui.min';
// import '../UI/../libs/lodash.min.js';
// import '../UI/../libs/d3.v4.min.js';
// import '../UI/../libs/KoreGraphAdapter.js';
// import '../UI/../libs/anonymousassertion.js';
// import '../kore-bot-sdk-client.js';
// import '../UI/../libs/perfect-scrollbar.js';
// import '../UI/../libs/emoji.js';
// import '../UI/../libs/purejscarousel.js';
// import chatWindow from "imports-loader?imports=window!../UI/chatWindow.js";
// import chatWindow from './index.js';
// import '../UI/custom/customTemplate.js';
// import '../UI/../libs/ie11CustomProperties.js';
// import '../UI/../libs/recorder.js';
// import '../UI/../libs/recorderWorker.js';
// import '../UI/../libs/speech/app.js';
// import '../UI/../libs/speech/key.js';
// import '../UI/../libs/client_api.js';
// import chatConfig from './index.js';
// import '../UI/kore-main.js';
// import '../UI/libs/kore-no-conflict-end.js';

//import '../UI/libs/kore-no-conflict-start';
// import chatWindow from './components/chatwindow/chatWindow';
// import chatConfig from './components/chatwindow/config/kore-config';
// import Korei18nPlugin from './plugins/i18n';
// import KoreFileUploaderPlugin from './plugins/fileUploader';

import KoreWidgetSDK from './components/widgets/kore-widgets'//'./components/widgets/kore-widgets';
import widgetsConfig from './components/widgets/config/kore-widgets-config';
// import KorePickersPlugin from './plugins/korePickers';


// import KRSearch from './components/search/findly-sdk';
// import KRSearchConfig from './components/search/config/findly-config';


export {
  widgetsConfig,
  KoreWidgetSDK
};
