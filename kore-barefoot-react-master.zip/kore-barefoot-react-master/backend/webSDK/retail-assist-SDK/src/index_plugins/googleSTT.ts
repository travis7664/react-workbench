
import GoogleSTT from '../plugins/speechToText/GoogleSTT/GoogleSTT';

export {
    GoogleSTT
};