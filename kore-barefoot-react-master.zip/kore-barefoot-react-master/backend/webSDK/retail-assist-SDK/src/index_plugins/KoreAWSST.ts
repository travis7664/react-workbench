
import SpeakTextWithAWSPolly from '../plugins/textToSpeech/KoreAWSPolly/kore-aws-polly';

export {
    SpeakTextWithAWSPolly
};