
import RetailAssistTemplatePlugin from '../plugins/retailAssistPlugin';

export {
    RetailAssistTemplatePlugin
};