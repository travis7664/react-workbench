
import GoogleTTS from '../plugins/textToSpeech/GoogleTTS/GoogleTTS';

export {
    GoogleTTS
};