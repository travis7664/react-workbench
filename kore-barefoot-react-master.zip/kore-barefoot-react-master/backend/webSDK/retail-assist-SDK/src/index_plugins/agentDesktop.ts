import AgentDesktopPlugin from '../plugins/agentDesktop/agentdesktop';

export {
    AgentDesktopPlugin
};