import SearchSuggestionsPlugin from '../plugins/searchSuggestions/searchSuggestions';

export {
    SearchSuggestionsPlugin
};