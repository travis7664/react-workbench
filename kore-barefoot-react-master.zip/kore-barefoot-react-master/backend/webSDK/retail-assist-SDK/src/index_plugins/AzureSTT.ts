
import AzureSTT from '../plugins/speechToText/AzureSTT/AzureSTT';

export {
    AzureSTT
};