import KoreMultiFileUploaderPlugin from "../plugins/fileUploader/multiFileUploader";

export {
    KoreMultiFileUploaderPlugin
};