import KoreDesktopNotificationPlugin from "../plugins/desktopNotifications/desktopnotifications";

export {
    KoreDesktopNotificationPlugin
};
