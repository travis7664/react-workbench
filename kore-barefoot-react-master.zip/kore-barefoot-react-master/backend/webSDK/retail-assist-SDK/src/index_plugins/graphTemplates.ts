
import GraphTemplatesPlugin from '../plugins/graphTemplatesPlugin';

export {
  GraphTemplatesPlugin
};
