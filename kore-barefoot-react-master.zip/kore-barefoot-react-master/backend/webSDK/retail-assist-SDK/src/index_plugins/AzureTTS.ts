
import AzureTTS from '../plugins/textToSpeech/AzureTTS/AzureTTS';

export {
    AzureTTS
};