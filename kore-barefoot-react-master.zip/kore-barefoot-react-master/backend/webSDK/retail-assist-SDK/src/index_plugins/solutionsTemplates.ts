
import SolutionsTemplatesPlugin from '../plugins/solutions/solutionsPlugin';

export {
    SolutionsTemplatesPlugin
};