
import BrowserTTS from '../plugins/textToSpeech/BrowserTTS/BrowserTTS';

export {
    BrowserTTS
};