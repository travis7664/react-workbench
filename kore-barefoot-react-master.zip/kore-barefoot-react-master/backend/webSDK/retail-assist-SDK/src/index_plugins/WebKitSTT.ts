
import WebKitSTT from '../plugins/speechToText/WebKitSTT/WebKitSTT';

export {
    WebKitSTT
};