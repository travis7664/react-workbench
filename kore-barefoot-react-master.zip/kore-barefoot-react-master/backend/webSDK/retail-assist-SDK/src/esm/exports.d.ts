// @ts-ignore
export{chatWindow}from "./kore-web-sdk-chat.min.js";
// @ts-ignore
export{chatConfig}from"./kore-web-sdk-chat.min.js";
// @ts-ignore
export{KoreWidgetSDK}from"./kore-web-sdk-widgets.js";
// @ts-ignore
export{widgetsConfig}from"./kore-web-sdk-widgets.js";
// @ts-ignore
export{KorePickersPlugin}from"./plugins/kore-picker-plugin.js";
// @ts-ignore
export{GraphTemplatesPlugin}from"./plugins/kore-graph-templates-plugin.js";
// @ts-ignore
export {SolutionsTemplatesPlugin} from './plugins/kore-solutions-plugin.js'
// @ts-ignore
export{WebKitSTT}from"./plugins/webapi-stt-plugin.js";
// @ts-ignore
export{BrowserTTS}from"./plugins/browser-tts-plugin.js";
// @ts-ignore
export{AgentDesktopPlugin}from"./plugins/agent-desktop.js";
// @ts-ignore
export{GoogleSTT}from"./plugins/google-stt-plugin.js";
// @ts-ignore
export{GoogleTTS}from"./plugins/google-tts-plugin.js";
// @ts-ignore
export{AzureSTT}from"./plugins/azure-stt-plugin.js";
// @ts-ignore
export{AzureTTS}from"./plugins/azure-tts-plugin.js";
// @ts-ignore
export{SpeakTextWithAWSPolly}from"./plugins/koreawspolly-st-plugin.js";
// @ts-ignore
export{KoreDesktopNotificationPlugin}from"./plugins/kore-desktop-notification.js";
// @ts-ignore
export{SearchSuggestionsPlugin}from"./plugins/search-suggestions.js";
// @ts-ignore
export {KoreFileUploaderPlugin} from './plugins/file-upload.js';
// @ts-ignore
export {KoreMultiFileUploaderPlugin} from './plugins/multi-file-upload.js';