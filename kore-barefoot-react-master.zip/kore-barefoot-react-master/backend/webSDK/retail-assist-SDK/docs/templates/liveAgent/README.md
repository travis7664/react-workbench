## Live Agent

###### Preview

![liveAgent](https://user-images.githubusercontent.com/58174664/148946379-7989b197-44d0-4df1-9571-2fa1152c8e5a.PNG)


###### Message Payload
```js
var message={
    "type": "template",
    "payload": {
    "template_type":"live_agent",
    "text":"Please choose",
    }
};

print(JSON.stringify(message));

```

