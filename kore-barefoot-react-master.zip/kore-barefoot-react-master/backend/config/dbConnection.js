var prop = require('./dbConfig');

var mysql = require('mysql2');

module.exports = {
    getConnection: () => {
        try {
            return mysql.createConnection(prop);
        } catch (error) {
            console.log("An error occured getting connection: ", error)
        }
    }
}
