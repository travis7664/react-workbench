const express = require('express');
const bannerController = require('../controllers/bannerController');

const verification=require('../helpers/apiAuth')

const router = express.Router();



router.get('/getbanner', bannerController.Getbanner);
router.post('/postbanner',verification.verifyToken,bannerController.Addbanner);
router.put('/putbanner',verification.verifyToken,bannerController.Editbanner);
router.delete('/delbanner',verification.verifyToken,bannerController.Deletebanner);

router.get('/getSolReports',verification.verifyToken,bannerController.GetSolReport)
router.put('/putSolReports',bannerController.PutSolReport)


module.exports = router;