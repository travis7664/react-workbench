const express = require('express');
const router = express.Router();
// const authenticateToken = require('../middleware/authenticateToken');
const UserRoles = require('../controllers/usersRoles_api');


// const Roles = require('../controllers/Roles');
const rolesController = require('../controllers/Roles'); 

// Define API endpoint to retrieve users by role name  updateRole
router.get('/', rolesController.getRoles);
router.post('/',  rolesController.addRole);
router.put('/:rid',  rolesController.updateRole);
router.delete('/:rid', rolesController.deleteRole);
router.get('/:roleName?', UserRoles.getUsersByRole);

module.exports = router;
