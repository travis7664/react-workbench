const express = require('express');
const saasController = require('../controllers/saasController');
const verification=require('../helpers/apiAuth')

const router = express.Router();



router.get('/getsaas',verification.verifyToken, saasController.GetSaas);
router.post('/postsaas',verification.verifyToken,saasController.PostSaas)
router.put('/putsaas',verification.verifyToken,saasController.PutSaas)
router.delete('/delsaas',verification.verifyToken,saasController.DelSaas)


module.exports = router;
