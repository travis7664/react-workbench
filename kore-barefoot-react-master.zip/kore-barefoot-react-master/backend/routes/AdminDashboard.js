const express = require('express');
const router = express.Router();
const UserRoles = require('../controllers/AdminDashboard');



router.put('/assignRole',  UserRoles.assignRole);
router.put('/updateTeam',  UserRoles.updateTeam);
router.put('/updateStatus',  UserRoles.updateUsersActiveStatus);
router.get('/showProjDetailsOfUsers/:uid',UserRoles.showProjDetailsOfUsers);

module.exports = router;
