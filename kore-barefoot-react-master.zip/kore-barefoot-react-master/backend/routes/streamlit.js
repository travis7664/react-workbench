const express = require('express');
const Gale = require('../model/Gale');
const router = express.Router();
require("dotenv").config();

const { decryptData } = require('../utils/crypto');

router.get("/applications", async (req, res) => {
    try {

        const reqApiKey = req.headers?.["x-api-key"];
        if (!reqApiKey) {
            res.status(401);
            res.send({ error: "No api key in header" });
            return;
        }

        if (reqApiKey !== process.env.STREAMLIT_API_KEY) {
            res.status(403);
            res.send({ error: "Invalid API Key" });
        }

        const appUUID = req.query.uuid;

        if (!appUUID) {
            const records = await Gale.findAll();
            return res.status(200).send({ data: records });
        }
        const record = await Gale.findOne({ where: { uuid: appUUID } });

        if (!record) {
            const records = await Gale.findAll();
            return res.status(200).send({ data: records });
        }

        record.dataValues.config.appData.request.apiKey = decryptData(record.dataValues.config.appData.request.apiKey);
        return res.status(200).send({ data: record });

    } catch (error) {
        const message = `An error occurred : ${error}`;
        console.log(message);

        return res.status(500).send({ error: message });
    }
});

router.post("/coffee", (req, res) => {
    try {
        const brewCoffee = (coffee, method) => {
            if (method === "teapot") {
                return res.status(418).send({ error: "The server refuses the attempt to brew coffee with a teapot." });
            }
            return res.status(200).send({ success: `Brewing ${coffee} coffee with a ${method}` });
        }

        if (!req.body.coffee || !req.body.coffeeMethod) {
            return res.status(400).send({ error: `Need some 'coffee' and the 'coffeeMethod' in which you are brewing it.` });
        }
        brewCoffee(req.body.coffee, req.body.coffeeMethod);

    } catch (error) {
        return res.status(500).send({ error: `Error brewing coffee: ${error}` })
    }
});
module.exports = router;
