const express = require('express');
const router = express.Router();
const multer = require('multer');
const upload = multer({ storage: multer.memoryStorage() });
// const authenticateToken = require('../middleware/authenticateToken'); 
const { getAllFiles } = require('../s3'); // Import the new function
const S3Controller = require('../controllers/S3Controller');


router.post('/upload',upload.single('file'),S3Controller.UploadToOldBarefoot);
router.post('/upload-signed-url',upload.single('image'),S3Controller.createPostwithSignedURL);
router.delete('/delete/:fileName', S3Controller.deleteFileFromBucket);


router.get('/files', async (req, res) => {
    try {
      const files = await getAllFiles();
      
      if (files.length === 0) {
        return res.status(200).json({ message: 'No files found in the bucket' });
      }
  
      res.status(200).json({
        files,
      });
    } catch (error) {
      console.error('Error:', error.message); 
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });
module.exports = router;
