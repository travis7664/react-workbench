const express = require('express');
const connection = require('../config/sqlConnection');

const router = express.Router();

// Define API endpoint to retrieve all demo details
router.get('/roles', async (req, res) => {
  try {
    const sqlQuery = `
      SELECT
        d.rid,
        d.name
        
        FROM
        role d
    `;

    connection.query(sqlQuery, (err, results) => {
      if (err) {
        console.error('Error querying database:', err);
        res.status(500).json({ error: 'Internal Server Error' });
        return;
      }

      // Process the results to format users and features as objects
      const demos = results.map(row => {
        

        
        return {
          rid: row.rid,
          role_name: row.name
          
          
        };
      });

      // Return the demo details as JSON response
      res.json(demos);
    });
  } catch (error) {
    // Handle any errors
    console.error('Error:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

module.exports = router;
