const express = require("express");
const router = express.Router();
const webhookController = require("../controllers/webhookController");
const multer = require("multer");

const upload = multer({ storage: multer.memoryStorage() });

router.post(
  "/v1/upload-csv",
  upload.single("file"),
  webhookController.uploadCSV
);

router.post("/v1/start-process", webhookController.startProcess);

router.get("/v1/process-progress/:id", webhookController.processProgress);

router.get("/v1/get-credentials", webhookController.getCredentials);

const multerUpload = multer({ dest: 'uploads/' });


router.post("/python-node", multerUpload.single('file'), webhookController.pythonNode);

module.exports = router;
