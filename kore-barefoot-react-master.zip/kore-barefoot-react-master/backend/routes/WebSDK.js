const express = require("express");
const router = express.Router();
// const authenticateToken = require('../middleware/authenticateToken');
const verification = require("../helpers/apiAuth");
const UserRoles = require("../controllers/ManageWebSDK");

router.get("/", verification.verifyToken, UserRoles.getSDKs);
router.get(
  "/key_fields",
  verification.verifyToken,
  UserRoles.getSDKwithKeyFields
);
router.get("/:id", UserRoles.getSDKbyID);
router.post("/", verification.verifyToken, UserRoles.addSDK);
router.put("/:id", verification.verifyToken, UserRoles.updateSDK);
router.delete("/:id", UserRoles.deleteSDK);

// router.get('/:roleName?', UserRoles.getUsersByRole);

module.exports = router;
