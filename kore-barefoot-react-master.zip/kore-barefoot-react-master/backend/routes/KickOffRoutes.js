const express = require("express");
const router = express.Router();
const verification = require("../helpers/apiAuth");

const kickoff = require("../controllers/KickOffMailController");

router.get("/sendmail", verification.verifyToken, kickoff.sendKickoff);
router.get("/closuremail", verification.verifyToken, kickoff.closureMail);
router.post("/customMail", kickoff.customMail);
router.post("/statusmail",kickoff.statusMail)

module.exports = router;
