const express = require('express');
const router = express.Router();


const LeavesController = require('../controllers/UserLeaveManagement'); 

router.get('/', LeavesController.getAllLeaves);
router.get('/:year/:month', LeavesController.getLeavesByMonth);

router.post('/',  LeavesController.addLeave);
router.put('/:leave_id',  LeavesController.updateLeave);
router.delete('/:leave_id',  LeavesController.softDeleteLeave);

router.get('/removedLeaves', LeavesController.getAllRemovedLeaves);
router.get('/removedLeaves/:year/:month', LeavesController.getRemovedLeavesByMonth);

router.put('/restore/:leave_id',  LeavesController.restoreLeave);

router.delete('/hardDelete/:leave_id',  LeavesController.hardDeleteLeave);



module.exports = router;
