const express = require("express");
const router = express.Router();
const verification = require("../helpers/apiAuth");
const UserController = require("../controllers/users_api");
const demos = require("./demos");
const activeDemos = require("../controllers/ActiveDemos_api");
const DemosList = require("../controllers/demoList_keyFields");
const features = require("../controllers/special_features_api");
const demosAPI_with_Filters = require("../controllers/demosAPI_with_Filters");
const showProjDetailsOfUsers = require("../controllers/showProjDetailsOfUser");
const searchSAASSecrets = require("../controllers/searchSAASSecrets")
const generateJWT = require('../controllers/GenerateJWT')
const updateWorkload = require("../controllers/userWorkLoadAllocation")
const authenticateToken = require('../middleware/authenticateToken');


const Roles = require("./roles");
const Admin = require("./AdminDashboard");

const leaves = require("./leaves");
const se_events = require("./se_events");
const userProj = require("../controllers/User_ProjectDetails");
const galeRouter = require("./galeAgents");
const WebSDKSearch = require("../controllers/SearchBarWebSDK");
const searchSecrets = require("../controllers/searchSecrets");
const search = require("../controllers/SearchBar");
const WebSDK = require('./WebSDK');


router.use('/roles',verification.verifyToken, Roles);
router.use('/WebSDK', WebSDK);
router.use('/Admin',verification.verifyToken, Admin);
router.use('/se_events',  verification.verifyToken, se_events);
router.use('/demo',verification.verifyToken, demos);
router.get('/showDemos',verification.verifyToken, demosAPI_with_Filters.getDemos);
router.get('/advSearch',verification.verifyToken, demosAPI_with_Filters.getDemos);
router.use('/leaves',verification.verifyToken, leaves);
router.use('/se_events', verification.verifyToken, se_events);
router.get('/users',verification.verifyToken, UserController.getAllUsers);
router.get('/users/:uid',verification.verifyToken, UserController.getUserById);
router.get('/demoList',verification.verifyToken, DemosList.getDemos);
router.get('/activeDemo',verification.verifyToken, activeDemos.getActiveDemos);
router.get('/spec_features', verification.verifyToken,features.getFeatures);
router.get('/UserProjectDetails', verification.verifyToken, userProj.showProjDetailsOfUsers);
router.get('/search/:SearchClauses/:status/:project_type',verification.verifyToken, search.getDemos);
router.get('/searchSDK/:SearchClauses',verification.verifyToken, WebSDKSearch.getSDKs );
router.get('/searchSecrets/:SearchClauses',verification.verifyToken, searchSecrets.getSDKs );
router.get('/searchSAASSecrets/:SearchClauses',verification.verifyToken, searchSAASSecrets.getSDKs );
router.get('/searchAll/:SearchClauses/',verification.verifyToken, search.getAllDemos);
// router.get('/searchAllbyFilters',verification.verifyToken, search.getAllDemosbyFilters);
router.post('/updateWorkload', updateWorkload.updateWorkload);
router.put('/ReleseUser', updateWorkload.ReleseUser);

router.get('/showProjDetailsOfUsers/:uid',showProjDetailsOfUsers.getUserProjectDetails);



// router.use('/VAdemo',verification.verifyToken, demos);
router.use('/VAdemo',authenticateToken, demos);
router.get('/VAsearchAll/:SearchClauses/',authenticateToken, search.getAllDemos);
router.get('/GetUid/', userProj.getUserUID);

// router.get('/GetUid/:SearchClauses/',authenticateToken, getUserUID);


// router.get('/ViewSDK/:ID', WebSDKRouter.ViewSDKbyID);
// router.use('/ViewSDK',  WebSDKRouter); getAllDemos


// router.use('/gale', verification.verifyToken, galeRouter);


// router.use('/roles',  Roles);
// router.use('/WebSDK',  WebSDK);
// router.use('/se_events',    se_events);
// router.use('/demo',  demos);
// router.get('/advSearch',  demosAPI_with_Filters.getDemos);
// router.use('/leaves',  leaves);
// router.use('/se_events',   se_events);
// router.get('/users',  UserController.getAllUsers);
// router.get('/users/:uid',  UserController.getUserById);
// router.get('/UserProjectDetails', userProj.showProjDetailsOfUsers);
// router.get('/demoList',  DemosList.getDemos);
// router.get('/activeDemo',  activeDemos.getActiveDemos);
// router.get('/spec_features',  features.getFeatures);
// router.get('/UserProjectDetails',   userProj.showProjDetailsOfUsers);
// router.get('/search/:SearchClauses/:status',  search.getDemos);
router.use('/gale',   galeRouter);


router.post('/generateJWT', generateJWT);



module.exports = router;