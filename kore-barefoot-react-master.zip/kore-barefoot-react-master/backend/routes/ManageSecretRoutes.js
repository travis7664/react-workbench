const express = require('express');
const SecretController = require('../controllers/ManageSecretController.js');

const verification=require('../helpers/apiAuth')

const router = express.Router();



router.get('/getsecret',verification.verifyToken, SecretController.GetSecret);
router.post('/postsecret',verification.verifyToken,SecretController.PostSecret)
router.put('/putsecret',verification.verifyToken,SecretController.PutSecret)
router.delete('/delsecret',verification.verifyToken,SecretController.DelSecret)

module.exports = router;
