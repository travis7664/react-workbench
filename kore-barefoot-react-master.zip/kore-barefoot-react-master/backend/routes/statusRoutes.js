const express = require('express');
const statusContoller = require('../controllers/statusController');
const issueController=require('../controllers/createIssuesController')
const verification=require('../helpers/apiAuth')
const issueModify=require('../controllers/editIssuesController')
const jiraController=require('../controllers/JiraController')

const router = express.Router();



router.get('/getstatus',verification.verifyToken, statusContoller.GetStatus);
router.post('/poststatus',verification.verifyToken,statusContoller.PosttStatus)
router.put('/updatestatus',verification.verifyToken,statusContoller.UpdateStatus)
router.post('/postissues',verification.verifyToken,issueController.PosttIssues)
router.put('/putissues',verification.verifyToken,issueModify.PuttIssues)
router.get('/jiraDetails',jiraController.GetJira)

module.exports = router;
