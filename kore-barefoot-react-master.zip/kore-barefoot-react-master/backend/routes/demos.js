const express = require("express");
const router = express.Router();
// const authenticateToken = require('../middleware/authenticateToken');    getDemosCount
// const UserRoles = require('../controllers/usersRoles_api');
const demos = require("../controllers/demos_api");

const Adddemos = require("../controllers/addDemos");
const userProj = require("../controllers/User_ProjectDetails");
const demosCount = require("../controllers/demosCount");
const spec_features = require("../controllers/project_specialFeatures");
const documents = require("../controllers/UploadDocuments");


router.get('/', demos.getDemos);
router.get('/getDemosCount', demosCount.getTotalDemosCountWithFilters);
router.get('/:did', demos.getDemoById);
router.post('/', Adddemos.addDemo);
router.put('/:did', Adddemos.updateDemo); 
router.put('/update/:did/:type',Adddemos.setToTrash)
router.put('/progress/:did/:progress',Adddemos.UpdateProgress)
router.delete('/:did', Adddemos.deleteDemo);

router.get('/:did/userProj', userProj.showProjUsers);
router.post('/:did/userProj', userProj.assignProj);
router.put('/:did/userProj', userProj.updateRoles); 
router.delete('/:did/userProj', userProj.deleteProj);
router.put('/:did/editUser', userProj.editUser);

router.get("/:did/specialFeature", spec_features.showProjFeature);
router.post("/:did/specialFeature", spec_features.assignFeature);
router.delete("/:did/specialFeature", spec_features.deleteFeature);

router.get("/:did/documents", documents.getDocuments);
router.post("/:did/documents", documents.addDocuments);
router.delete("/:did/documents/:id", documents.deleteDocument);
router.put("/:did/documents/:id", documents.updateDocument);

// router.get('/GetUid/', userProj.getUserUID);


module.exports = router;
