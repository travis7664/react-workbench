const express = require('express');
const docController = require('../controllers/solDocController');
const bannerController = require('../controllers/solBannerController');
const solController = require('../controllers/solController');
const describeJira = require('../controllers/describeJiraController');
const sol_Status = require('../controllers/sol_Status');
const sol_Ticket=require('../controllers/solTicketController');
const solDetails=require('../controllers/solDetails')
const solAccnt=require('../controllers/solAccntController')
const reserve=require('../controllers/reserveSolController')
const verification=require('../helpers/apiAuth')

const router = express.Router();

router.get('/getSolDetails',verification.verifyToken,solDetails.getSolutions);
router.post('/postSolDetails',verification.verifyToken,solDetails.postSolution)
router.put('/putSolDetails',verification.verifyToken,solDetails.putSolution)
router.delete('/delSolDetails',verification.verifyToken,solDetails.deleteSolution)


router.get('/getaccounts',verification.verifyToken,solAccnt.getAccnts)
router.post('/postaccounts',verification.verifyToken,solAccnt.postAccnt)
router.put('/putaccounts',verification.verifyToken,solAccnt.putAccnt)
router.delete('/delaccounts',verification.verifyToken,solAccnt.deleteAccnt)



router.get('/getdocs', verification.verifyToken,docController.GetSolDocs);
router.post('/postdocs',verification.verifyToken, docController.AddSolDocs);
router.put('/putdocs',verification.verifyToken,docController.EditSolDocs);
router.delete('/deldocs',verification.verifyToken,docController.DeleteSolDocs);


router.get('/getBanner',verification.verifyToken,bannerController.GetBanner);
router.post('/postBanner',verification.verifyToken,bannerController.AddBanner);
router.put('/putBanner',verification.verifyToken,bannerController.EditBanner)
router.delete('/delBanner',verification.verifyToken,bannerController.DeleteBanner)

router.get('/getsol',verification.verifyToken, solController.GetSolInfo);
router.get('/describeJira', verification.verifyToken,describeJira.GetJira);
router.get('/getsolId',verification.verifyToken,solController.GetSolDetails);
router.get('/getGlobalDoc',verification.verifyToken,solController.GetGlobalDoc);
router.post('/postGlobalDoc',verification.verifyToken,solController.PostGlobalDoc);
router.put('/putGlobalDoc',verification.verifyToken,solController.putGlobalDoc);
router.delete('/delGlobalDoc',verification.verifyToken,solController.delGlobalDoc);
router.put('/putAuditDate',verification.verifyToken,solController.putAuditDate);


router.get('/getSolTickets',verification.verifyToken,sol_Ticket.GetIssues)
router.post('/postsolTickets',verification.verifyToken,sol_Ticket.AddIssue)
router.put('/putsolTickets',verification.verifyToken,sol_Ticket.EditIssue)
router.delete('/delsolTickets',verification.verifyToken,sol_Ticket.DeleteIssue)


router.get('/solStatus',verification.verifyToken, sol_Status.GetStatusCnt);
router.post('/PostUsecase',verification.verifyToken, sol_Status.PostUsecase);
router.put('/editUseCase', verification.verifyToken,sol_Status.EditUsecase);
router.delete('/delUseCase',verification.verifyToken,sol_Status.delUseCase);


router.post('/reserveDemo',verification.verifyToken,reserve.reserveDemo)
router.delete('/releaseDemo',verification.verifyToken,reserve.release)

// Uncomment and add other routes as necessary
// router.put('/updatestatus', verification.verifyToken, statusContoller.UpdateStatus);
// router.post('/postissues', verification.verifyToken, issueController.PosttIssues);
// router.put('/putissues', verification.verifyToken, issueModify.PuttIssues);
// router.get('/jiraDetails', jiraController.GetJira);

module.exports = router;
