const express = require('express');
const Gale = require('../model/Gale');
const { v4 } = require('uuid');
const { encryptData, decryptData } = require("../utils/crypto");
const { Op } = require('sequelize');
const router = express.Router();
require("dotenv").config();
router.use(express.json())

const createTable = async () => {

    //  Add { force: true } to remove Table and create new
    await Gale.sync();
}

const formatInputData = (input) => {
    const formattedInputs = [];
    for (const [key, value] of Object.entries(input)) {
        console.log(`key; ${key}, value: ${JSON.stringify(value)}\nTypeof value : ${typeof value}`);
        const input = { key, label: key };
        if (typeof value === "object") {
            input.sub = {};
            for (const [subKey, subVal] of Object.entries(value)) {
                input.type = "object";
                input.sub[subKey] = {
                    label: subKey,
                    placeholder: subVal,
                    type: "text"
                };

            }
        } else {
            input.type = "text";
            input.placeholder = value;
        }
        formattedInputs.push(input);
    }
    return formattedInputs;
}

router.post("/agent", async (req, res) => {
    try {

        await createTable();

        const requiredKeys = [
            "title",
            "agentId",
            "owner",
            "agentDescription",
            "isPublished",
            "input",
            "apiKey",
            "isAsync"
        ];

        const requestKeys = Object.keys(req.body);

        for (const required of requiredKeys) {
            if (!requestKeys.includes(required)) {
                return res.status(400).send({ error: "Required Key not found: " + required });
            }
        }

        // FORMAT input into APP DATA FIELD that matches current appData sent to streamlit 
        const { title, agentId, owner, apiKey, isAsync, agentDescription, isPublished, input } = req.body;
        const uniqueId = v4();
        const formattedData = {
            inputs: [],
            rawInput: input,
            isPublished,
            request: {
                url: `https://gale.kore.ai/api/v1/process/${agentId}`,
                apiKey: encryptData(apiKey),
                method: "POST",
                isAsync
            }
        };
        formattedData.inputs = formatInputData(input.input);

        const record = new Gale({
            title,
            agentId,
            owner,
            uuid: uniqueId,
            config: {
                version: "0.1.0",
                description: agentDescription,
                appData: formattedData
            }
        });
        await record.save();

        return res.status(201).send({ data: record });

    } catch (error) {
        console.log("An error occurred creating a record: ", error);
        res.status(500).send({ error: "Error creating a record: " + error });
        return;
    }

});
// READ ALL
router.get("/agents", async (req, res) => {
    try {
        await createTable();
        const { limit, offset, search } = req.query;
        if (!search) {
            const { count, rows } = await Gale.findAndCountAll({
                limit: limit ? parseInt(limit, 10) : 10, offset: offset ? parseInt(offset, 10) : 0
            });

            res.status(200).send({ data: rows, pagination: { total: count, limit } })
            return;
        }

        console.log(search);
        console.log(typeof search);
        const agents = await Gale.findAll({
            where: {
                [Op.or]: [
                    { title: { [Op.substring]: search } },
                    { agentId: { [Op.substring]: search } },
                    { owner: { [Op.substring]: search } },
                    { uuid: { [Op.substring]: search } }
                ]
            }
        });
        res.status(200).send({ data: agents })
        return;
    } catch (error) {
        console.log("An error occurred: ", error);
        res.status(500).send({ error: "An error occurred: " + error });
        return;
    }
});
// READ ONE
router.get("/agent/:id", async (req, res) => {
    try {
        const id = req.params.id;
        const agent = await Gale.findOne({ where: { id } });
        if (!agent) {
            res.status(404).send({ error: "Agent not found" });
            return;
        }
        agent.config.appData.request.apiKey = decryptData(agent.config.appData.request.apiKey);
        agent.config.appData.request.apiKey = "kg-****" + agent.config.appData.request.apiKey.substring(64)
        res.status(200).send({ data: agent });
        return;

    } catch (error) {
        res.status(500).send({ error });
        return;
    }
});
// UPDATE
router.put("/agent/:id", async (req, res) => {
    try {
        const validatedKeys = [
            "title",
            "agentId",
            "owner",
            "agentDescription",
            "isPublished",
            "input",
            "apiKey",
            "isAsync"
        ];
        // validate keys with 

        const requestKeys = Object.keys(req.body);

        for (key of requestKeys) {
            if (!validatedKeys.includes(key)) {
                return res.status(400).send({ error: `Bad request: key '${key}' not a valid update field` });
            }
        }

        const updated = await Gale.findOne({ where: { id: req.params.id } });

        if (!updated) {
            return res.status(404).send({ error: "No item found with id: " + req.params.id });
        }
        const { title, input, apiKey, isAsync, isPublished, agentId, owner, agentDescription } = req.body;

        console.log("req.body")
        console.log(req.body)
        if (title) {
            updated.set({ title });
        }
        if (owner) {
            updated.set({ owner })
        }
        const config = updated.dataValues.config;
        console.log(config);
        if (agentId) {
            updated.set({ agentId });
            config.appData.request.url = `https://gale.kore.ai/api/v1/process/${agentId}`;
            console.log(`Updated request url with agentId: ${agentId}`)
        }
        if (input) {
            config.appData.rawInput = input;
            config.appData.inputs = formatInputData(input.input);
        }
        if (isAsync != null) {
            config.appData.request.isAsync = isAsync;
        }
        if (apiKey) {
            config.appData.request.apiKey = encryptData(apiKey);
        }
        if (isPublished != null) {
            console.log("is published: ", isPublished);
            config.appData.isPublished = isPublished;
        }
        if (agentDescription) {
            config.description = agentDescription;
        }
        await updated.update({ config: {} });
        updated.set({ config });
        await updated.save();

        res.status(200).send({ data: { success: true } });
    } catch (error) {
        console.log(error)
        res.status(500).send({ error: "" + error });
        return;
    }
});
// DELETE
router.delete("/agent/:id", async (req, res) => {
    try {
        const id = req.params.id;
        const rowsDel = await Gale.destroy({
            where: {
                id,
            },
        });
        if (!rowsDel) {
            res.status(404).send({ error: "Agent not found" })
            return;
        }
        res.status(200).send({ success: `Deleted ${rowsDel} rows` });
        return;

    } catch (error) {
        res.status(500).send({ error });
        return;
    }
});
module.exports = router;
