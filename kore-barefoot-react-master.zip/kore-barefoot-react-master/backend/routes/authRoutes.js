const express = require("express");
const passport = require("passport");
const authController = require("../controllers/authController");
const verification = require("../controllers/verifyMail");
const resend = require("../controllers/resendMail");
const ensureAuthenticated = require("../helpers/ensureAuthenticated");
// const verifyUsers=require('../helpers/apiAuth')

const router = express.Router();

router.get(
  "/google",
  passport.authenticate("google", {
    scope: ["profile", "email"],
    prompt: "select_account",
  })
);

// router.get('/google/callback', passport.authenticate('google', { failureRedirect: '/' }), authController.googleCallback);

router.get("/mail-verification", verification.verifyMail);

router.get("/resendMail", resend.resendMail);

router.get(
  "/google/callback",
  passport.authenticate("google", {
    failureRedirect: "/",
    successRedirect: `${process.env.GOOGLE_SUCCESS_URL}`,
  })
);
router.get(
  "/google/success",
  ensureAuthenticated,
  authController.googleCallback
);

router.get("/logout", authController.logout);
router.post("/addUser",authController.addUser)


module.exports = router;
