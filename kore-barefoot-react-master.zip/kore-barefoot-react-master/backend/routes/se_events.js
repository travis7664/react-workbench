const express = require('express');
const router = express.Router();


const SeController = require('../controllers/SE_Calender'); 

router.get('/', SeController.getAllevents); 
router.get('/:year/:month', SeController.getEventsByMonth);

router.post('/', SeController.addEvent); 
router.put('/:id',  SeController.updateEvent);
router.delete('/:id',  SeController.softDeleteEvent);
router.get('/removedEvents', SeController.getAllRemovedEvents);
router.get('/removedEvents/:year/:month', SeController.getRemovedEventsByMonth);
router.put('/restore/:id',  SeController.restoreEvent);

router.delete('/hardDelete/:id',  SeController.hardDeleteEvent);




module.exports = router;

// getEventsByMonth,
//   getAllevents,
//   addEvent,
//   updateEvent,
//   softDeleteEvent,
//   getAllRemovedEvents,
//   getRemovedEventsByMonth,
//   restoreEvent,
//   hardDeleteEvent