const express = require('express');
const profileController = require('../controllers/profileController');

const verification=require('../helpers/apiAuth')

const router = express.Router();



router.get('/getprofile',verification.verifyToken, profileController.GetProfile);
// router.post('/poststatus',verification.verifyToken,statusContoller.PosttStatus)
// router.post('/postissues',verification.verifyToken,issueController.PosttIssues)
router.put('/putissues/',verification.verifyToken,profileController.editIssues)

module.exports = router;
