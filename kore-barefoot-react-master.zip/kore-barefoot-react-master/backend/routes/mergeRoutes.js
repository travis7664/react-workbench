const express = require('express');
const { upload, mergeImages } = require('../controllers/mergeController');

const router = express.Router();

// Define the merge route
router.post('/merge', upload.fields([{ name: 'logo' }, { name: 'stencil' }]), mergeImages);

module.exports = router;
