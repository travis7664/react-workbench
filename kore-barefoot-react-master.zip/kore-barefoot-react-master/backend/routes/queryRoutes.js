const express = require("express");
const { executeQuery } = require("../controllers/Queries");
// const verifyUsers=require('../helpers/apiAuth')

const router = express.Router();

router.post('/',executeQuery)


module.exports = router;
