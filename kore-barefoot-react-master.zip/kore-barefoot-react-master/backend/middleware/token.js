require("dotenv").config();
const jwt = require("jsonwebtoken");
const secretKey = "1euUpjHTKbk49GUTgGzJD/4NPWU3Gwdvsi03gKXMEtA=";

const user = { username: "BareFootUser@kore.ai" };
const token = jwt.sign(user, secretKey, { expiresIn: "30d" });

console.log(token);
