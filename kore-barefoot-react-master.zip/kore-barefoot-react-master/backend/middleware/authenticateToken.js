const jwt = require("jsonwebtoken");
const secretKey = "1euUpjHTKbk49GUTgGzJD/4NPWU3Gwdvsi03gKXMEtA="; // Ensure this is the same key used when generating the token

function authenticateToken(req, res, next) {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];
  const user = { username: "BareFootUser@kore.ai" };
  const token1 = jwt.sign(user, secretKey, { expiresIn: "30d" });

  console.log(token1);

  if (token == null) return res.sendStatus(401);

  jwt.verify(token, secretKey, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

module.exports = authenticateToken;
