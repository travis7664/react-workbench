const express = require("express");
const jwt = require("jsonwebtoken");

const router = express.Router();
const secretKey = "1euUpjHTKbk49GUTgGzJD/4NPWU3Gwdvsi03gKXMEtA=";

router.post("/generateToken", (req, res) => {
  const { username, secret } = req.body;

  if (!username || !secret) {
    return res
      .status(400)
      .json({ message: "Username and secret are required." });
  }

  if (secret !== secretKey) {
    return res.status(403).json({ message: "Invalid secret key." });
  }

  const token = jwt.sign({ username }, secretKey, { expiresIn: "30d" });

  return res.status(200).json({ token });
});

module.exports = router;
