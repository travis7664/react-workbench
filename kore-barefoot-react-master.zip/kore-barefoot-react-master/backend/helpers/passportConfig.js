const passport = require("passport");
const GoogleStrategy = require("passport-google-oauth20").Strategy;
const jwt = require("jsonwebtoken");
const { generateToken, verifyToken } = require("../helpers/jwtHelper"); // Import JWT token-related code
const sendMail = require("../helpers/sendMail");

const insertProftoDB = require("../utils/insertProfileDB");
const mysql = require("mysql2/promise"); // Add this line

const dbConfig = require("../config/dbConfig"); // Assuming you have dbConfig with your database configuration

const pool = mysql.createPool(dbConfig); // Use pool for connections

passport.serializeUser((user, done) => {
  done(null, user);
});

passport.deserializeUser((obj, done) => {
  done(null, obj);
});

passport.use(
  new GoogleStrategy(
    {
      clientID: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      callbackURL: process.env.GOOGLE_CALLBACK_URL,
      prompt: "consent",
      accessType: "offline",
    },
    async (accessToken, refreshToken, profile, done) => {
      try {
        const [rows] = await pool.execute(
          "SELECT id FROM user WHERE email = ?",
          [profile._json.email]
        );
        console.log(rows);
        let email = profile._json.email;

        if (rows.length === 0) {
          await insertProftoDB(profile);
          const [previoususer] = await pool.execute(
            "SELECT * FROM users WHERE mail=?",
            [email]
          );
          if (previoususer.length == 0) {
            // Generate a verification token using JWT with the user's email as payload
            const jwtPayload = { email };
            const jwtOptions = { expiresIn: "20m" }; // Set token expiration time (2 minutes)

            const token = generateToken(jwtPayload, jwtOptions.expiresIn);
            // Send the verification email with the JWT token as a query parameter
            let mailSubject = `User Registration Mail Verification for the mail-id ${email}`;
            let content = `<p> Hi Admin, Please <a href="${process.env.APP_API_BASE_URL}/auth/mail-verification?token=${token}&email=${email}"> verify </a></p><br><p> Hi krishna, Please <a href="${process.env.APP_API_BASE_URL}/auth/resendMail?email=${email}"> Click here if the link above expired </a></p>`;
            sendMail("barefoot@kore.com", mailSubject, content);
          }
          return done(null, profile);
        } else {
          return done(null, profile);
        }

        // return done(null, profile);
      } catch (error) {
        console.error("Database error:", error);
        return done(error, null);
      }
    }
  )
);

module.exports = passport; // Export passport to use in your application
