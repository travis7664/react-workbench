require('dotenv').config(); // Load environment variables from .env file

const jwt = require('jsonwebtoken');

const secretKey = process.env.JWT_SECRET; // Fetch secret key from environment variable

const generateToken = (payload, expiresIn = '30d') => {
  return jwt.sign(payload, secretKey, { expiresIn });
};

const verifyToken = (token) => {
  try {
    const decoded = jwt.verify(token, secretKey);
    return decoded;
  } catch (err) {
    return null;
  }
};

module.exports = {
  generateToken,
  verifyToken,
};
