const { Sequelize } = require("sequelize");
require("dotenv").config();

const {
    DB_HOST,//=127.0.0.1
    DB_USER,//=barefoot_app_local
    DB_PASS,//=barefoot_app_local
    DB_NAME,//=barefoot_localDB
    DB_DIALECT,//=mysql
} = process.env;

const sequelize = new Sequelize(DB_NAME, DB_USER, DB_PASS, {
    host: DB_HOST,
    dialect: DB_DIALECT,
    logging: false,
});

module.exports = sequelize;
