require("dotenv").config();
const crypto = require("crypto");

const { CRYPTO_SECRET, CRYPTO_IV } = process.env;

if (!CRYPTO_SECRET || !CRYPTO_IV) {
    throw new Error("Yo! You forgot to set the crypto secret or crypto IV in your env vars!");
}
const key = crypto
    .createHash('sha512')
    .update(CRYPTO_SECRET)
    .digest('hex')
    .substring(0, 32)

const encryptionIV = crypto
    .createHash('sha512')
    .update(CRYPTO_IV)
    .digest('hex')
    .substring(0, 16)

const encryptData = (data) => {
    try {

        const cipher = crypto.createCipheriv("aes-256-cbc", key, encryptionIV);

        return Buffer.from(
            cipher.update(data, 'utf8', 'hex') + cipher.final('hex')
        ).toString('base64'); // Encrypts data and converts to hex and base64

    } catch (error) {

        throw new Error("Unable to encrypt: Error: " + error);
    }
};

const decryptData = (encryptedData) => {
    try {

        const buff = Buffer.from(encryptedData, 'base64');

        const decipher = crypto.createDecipheriv("aes-256-cbc", key, encryptionIV);

        return (
            decipher.update(buff.toString('utf8'), 'hex', 'utf8') +
            decipher.final('utf8')
        ); // Decrypts data and converts to utf8

    } catch (error) {

        throw new Error("Unable to encrypt: Error: " + error);
    }
};


module.exports = { encryptData, decryptData };
