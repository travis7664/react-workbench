const mysql = require('mysql2');
require("dotenv").config();

const localConfig = {
    host : process.env.DB_HOST,
    user : process.env.DB_USER,
    password : process.env.DB_PASS,
    database : process.env.DB_NAME,
};

class Database{
    constructor(config){
        this.connection = mysql.createPool(config); // Use `mysql.createPool()` instead of `Pool` from `pg`
    }
    getConnection(){
        return this.connection;
    }
}

module.exports = new Database(localConfig).getConnection();
