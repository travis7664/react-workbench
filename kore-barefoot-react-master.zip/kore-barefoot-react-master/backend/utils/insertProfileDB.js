const connection = require('./dbInstance');
const bcrypt = require('bcrypt');
const util = require('util');

const queryAsync = util.promisify(connection.query).bind(connection);
module.exports = function (profile) {
  return new Promise(async (resolve, reject) => {
      try {
          const [userExists] = await queryAsync("SELECT * FROM user WHERE email=? OR user_id=?", [profile['_json'].email, profile.id]);
          console.log(userExists)
          if (!userExists || userExists.length <= 0) {
              const [previoususer]=await queryAsync("SELECT * FROM users WHERE mail=?",[profile['_json'].email]);
              const user_id = profile.id;
              const firstName = profile.displayName || null;
              const lastName = profile.username || null;
              const provider = profile.provider;
              const email = profile['_json'].email || null;
              const image = profile['_json'].picture;
              if(previoususer && previoususer.length!=0){
                  console.log("1")
              await queryAsync("INSERT INTO user (user_id, provider, firstname, lastname, email, image, is_verified) VALUES (?, ?, ?, ?, ?, ?, ?)",
                  [user_id, provider, firstName, lastName, email, image, '1']);
              }
              else{
                  console.log("0")

                  await queryAsync("INSERT INTO user (user_id, provider, firstname, lastname, email, image, is_verified) VALUES (?, ?, ?, ?, ?, ?, ?)",
                  [user_id, provider, firstName, lastName, email, image, '0']);
              }

              return resolve();
          } else {
              return reject(new Error("User already  in db"));
          }
      } catch (error) {
          return reject(error);
      }
  });
};




