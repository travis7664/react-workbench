module.exports = {
  apps: [
    {
      name: "frontend",
      script: "npx",
      args: "serve -s build",
      env: {
        NODE_ENV: "production",
      },
      env_development: {
        NODE_ENV: "development",
      },
    },
  ],
};
